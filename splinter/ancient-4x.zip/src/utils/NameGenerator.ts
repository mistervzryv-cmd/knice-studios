// Procedural Ancient Name Generator for non-historical factions, cities, cultures and rulers

export type PhoneticFlavor = 'MESOPOTAMIAN' | 'ELAMITE' | 'LEVANTINE' | 'STEPPE';

export class NameGenerator {
  private static FLAVORS: Record<PhoneticFlavor, {
    roots: string[];
    suffixes: string[];
    citySuffixes: string[];
    leaderPrefixes: string[];
    leaderSuffixes: string[];
  }> = {
    MESOPOTAMIAN: {
      roots: ['Ур', 'Лаг', 'Киш', 'Нип', 'Эри', 'Аш', 'Шад', 'Зу', 'Мар', 'Нин', 'Бор', 'Сар', 'Луг', 'Эн', 'Тел'],
      suffixes: ['ур', 'аш', 'пур', 'дук', 'сар', 'гар', 'лат', 'ким', 'бад', 'нун', 'рид', 'тум'],
      citySuffixes: ['ур', 'пур', 'аш', 'иш', 'дук', 'ра'],
      leaderPrefixes: ['Лугаль-', 'Эн-', 'Шар-', 'Ур-', 'Нин-', 'Агум-'],
      leaderSuffixes: ['бани', 'пал', 'син', 'амур', 'касир', 'насир', 'тукул']
    },
    ELAMITE: {
      roots: ['Анш', 'Суз', 'Аван', 'Шил', 'Хут', 'Теп', 'Пир', 'Сир', 'Унт', 'Халь', 'Марх', 'Симаш'],
      suffixes: ['ан', 'ак', 'ти', 'нап', 'лу', 'ик', 'риш', 'ун', 'аш', 'тур'],
      citySuffixes: ['ан', 'шар', 'ван', 'ак', 'ти'],
      leaderPrefixes: ['Тепти-', 'Шилхак-', 'Хутран-', 'Унташ-', 'Кутик-'],
      leaderSuffixes: ['напириша', 'иншушинак', 'халь', 'темти', 'ахар']
    },
    LEVANTINE: {
      roots: ['Геб', 'Тир', 'Сид', 'Угар', 'Хац', 'Мег', 'Эбл', 'Карк', 'Тад', 'Ям', 'Дам', 'Арва'],
      suffixes: ['ал', 'он', 'ит', 'ар', 'от', 'им', 'ур', 'ат', 'ах'],
      citySuffixes: ['он', 'ит', 'ат', 'им', 'рос'],
      leaderPrefixes: ['Аби-', 'Малк-', 'Яхдун-', 'Хирам-', 'Баал-'],
      leaderSuffixes: ['милк', 'седег', 'шамаш', 'рим', 'лим']
    },
    STEPPE: {
      roots: ['Сарм', 'Сак', 'Дах', 'Таур', 'Ким', 'Хор', 'Скиф', 'Алан', 'Масс', 'Аракс', 'Борис'],
      suffixes: ['ат', 'ай', 'ин', 'ур', 'ак', 'ей', 'ор', 'да', 'ар', 'кан'],
      citySuffixes: ['таш', 'кент', 'юрт', 'орда', 'коль'],
      leaderPrefixes: ['Тарги-', 'Колок-', 'Спар-', 'Ари-', 'Идан-'],
      leaderSuffixes: ['тай', 'саис', 'пиф', 'вида', 'фарн']
    }
  };

  private static FACTION_TYPES = [
    'Царство', 'Держава', 'Союз', 'Конфедерация', 'Орда', 'Княжество', 'Гегемония'
  ];

  private static CULTURAL_PREFIXES = [
    'Прото-', 'Верхне-', 'Нижне-', 'Заречная ', 'Степная ', 'Горная ', 'Вольная ', 'Солнечная ', 'Речная '
  ];

  static generateCityName(flavor?: PhoneticFlavor): string {
    const fl = flavor || this.getRandomFlavor();
    const config = this.FLAVORS[fl];
    const root = config.roots[Math.floor(Math.random() * config.roots.length)];
    const suffix = config.citySuffixes[Math.floor(Math.random() * config.citySuffixes.length)];
    return `${root}${suffix}`;
  }

  static generateFactionName(baseCityOrRoot?: string, flavor?: PhoneticFlavor): string {
    const type = this.FACTION_TYPES[Math.floor(Math.random() * this.FACTION_TYPES.length)];
    const base = baseCityOrRoot || this.generateCityName(flavor);
    // Adjective form
    const adj = base.endsWith('а') || base.endsWith('я') 
      ? base.slice(0, -1) + 'ское' 
      : base.endsWith('ь') 
      ? base.slice(0, -1) + 'ское'
      : base + 'ское';
    return `${type} ${base}`;
  }

  static generateCultureName(parentCultureName?: string, flavor?: PhoneticFlavor): string {
    if (!parentCultureName) {
      const fl = flavor || this.getRandomFlavor();
      const root = this.FLAVORS[fl].roots[Math.floor(Math.random() * this.FLAVORS[fl].roots.length)];
      return `${root}ская культура`;
    }

    const cleanParent = parentCultureName.replace(/Прото-/, '').replace(/ культура/, '');
    const prefix = this.CULTURAL_PREFIXES[Math.floor(Math.random() * this.CULTURAL_PREFIXES.length)];
    return `${prefix}${cleanParent}`;
  }

  static generateLeaderName(flavor?: PhoneticFlavor): string {
    const fl = flavor || this.getRandomFlavor();
    const config = this.FLAVORS[fl];
    const prefix = config.leaderPrefixes[Math.floor(Math.random() * config.leaderPrefixes.length)];
    const suffix = config.leaderSuffixes[Math.floor(Math.random() * config.leaderSuffixes.length)];
    return `${prefix}${suffix}`;
  }

  private static getRandomFlavor(): PhoneticFlavor {
    const flavors: PhoneticFlavor[] = ['MESOPOTAMIAN', 'ELAMITE', 'LEVANTINE', 'STEPPE'];
    return flavors[Math.floor(Math.random() * flavors.length)];
  }
}
