// src/simulation/QuestSystem.ts - Historical Quests, Dilemmas and Initiatives
import { GameState } from '../core/GameState.ts';
import { BiomeType } from '../entities/Types.ts';

export interface QuestChoice {
  id: string;
  text: string;
  costDesc?: string;
  effectDesc: string;
  canAfford: (state: GameState) => boolean;
  apply: (state: GameState) => string;
}

export interface QuestEvent {
  id: string;
  title: string;
  icon: string;
  description: string;
  choices: QuestChoice[];
}

export const HISTORICAL_QUESTS: QuestEvent[] = [
  {
    id: 'QUEST_GREAT_FLOOD',
    title: 'Наводнение на Великой Реке',
    icon: '🌊',
    description: 'Весеннее таяние снегов вызвало колоссальный паводок. Бурные воды великих рек грозят смыть дамбы, затопить поля и смести поселения земледельцев.',
    choices: [
      {
        id: 'build_dams',
        text: 'Выделить средства на возведение грандиозных дамб и каналов',
        costDesc: '💰 50 Золота',
        effectDesc: '+20% к сплоченности (Cohesion) во всех речных провинциях, +30 еды в запасы',
        canAfford: (state) => (state.getPlayerFaction()?.gold ?? 0) >= 50,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.gold -= 50;
          player.grain += 30;
          let count = 0;
          for (const prov of state.provinces.values()) {
            if (prov.ownerFactionId === player.id && prov.biome === BiomeType.RIVER_VALLEY) {
              prov.authority = Math.min(100, prov.authority + 20);
              count++;
            }
          }
          return `🏛️ ВЕЛИКИЕ ДАМБЫ: Царь вложил 50 золота в ирригацию. Сплоченность ${count} речных провинций выросла на 20%, спасено 30 зерна!`;
        }
      },
      {
        id: 'ignore_flood',
        text: 'Пусть стихия идет своим чередом, казна важнее',
        costDesc: 'Бесплатно',
        effectDesc: '-15% к сплоченности речных земель, потеря 35 еды, угроза бегства крестьян',
        canAfford: () => true,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.grain = Math.max(0, player.grain - 35);
          for (const prov of state.provinces.values()) {
            if (prov.ownerFactionId === player.id && prov.biome === BiomeType.RIVER_VALLEY) {
              prov.authority = Math.max(10, prov.authority - 15);
            }
          }
          return `🌊 БЕДСТВИЕ ПАВОДКА: Отказ от помощи разорил поймы рек. Потеряно 35 зерна, власть в долинах упала на 15%.`;
        }
      }
    ]
  },
  {
    id: 'QUEST_LANGUAGE_REFORM',
    title: 'Языковая Реформа и Унификация Сводов',
    icon: '📜',
    description: 'Окраинные наместники и дочерние племена все сильнее отдаляются в речи и обычаях. Верховные жрецы предлагают единый царский словарь и канонизацию клинописи.',
    choices: [
      {
        id: 'standardize_script',
        text: 'Утвердить единую царскую грамматику и разослать писцов',
        costDesc: '📜 40 Очков Культуры',
        effectDesc: '-20% к текущему дрейфу (Drift) у всех суб-культур, укрепление единства',
        canAfford: (state) => (state.getPlayerFaction()?.culturePoints ?? 0) >= 40,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.culturePoints = Math.max(0, player.culturePoints - 40);
          for (const cult of state.cultures.values()) {
            if (cult.parentId === player.rootCultureId && cult.drift !== undefined) {
              cult.drift = Math.max(0, cult.drift - 20);
            }
          }
          return `📖 ЯЗЫКОВОЙ КАНОН: Писцы объединили диалекты империи. Дрейф всех отколотых суб-культур снижен на 20%!`;
        }
      },
      {
        id: 'local_autonomy',
        text: 'Позволить провинциям писать на местных наречиях',
        costDesc: '+35 💰 в казну (экономия)',
        effectDesc: '+10% к дрейфу суб-культур, но казна пополнена на 35 золота',
        canAfford: () => true,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.gold += 35;
          for (const cult of state.cultures.values()) {
            if (cult.parentId === player.rootCultureId && cult.drift !== undefined) {
              cult.drift = Math.min(95, cult.drift + 10);
            }
          }
          return `🗣️ МЕСТНЫЕ ДИАЛЕКТЫ: Отказ от реформы сберег 35 золота, но ускорил культурное обособление провинций на 10%.`;
        }
      }
    ]
  },
  {
    id: 'QUEST_FOREIGN_MERCHANTS',
    title: 'Караван Заморских Купцов',
    icon: '🐪',
    description: 'К вратам столицы прибыло пышное посольство из далеких земель с диковинными тканями, свитками и образцами неизвестных металлов.',
    choices: [
      {
        id: 'open_market',
        text: 'Учредить заморскую факторию и открыть царский базар',
        costDesc: '💰 40 Золота',
        effectDesc: '+35 Очков Исследований 🔬, +20 к дипломатическому мнению всех соседей',
        canAfford: (state) => (state.getPlayerFaction()?.gold ?? 0) >= 40,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.gold -= 40;
          player.sciencePoints = (player.sciencePoints ?? 0) + 35;
          if (player.diplomacy) {
            for (const rel of Object.values(player.diplomacy)) {
              rel.opinion = Math.min(100, rel.opinion + 20);
            }
          }
          return `🌐 ШЕЛКОВЫЙ ПУТЬ: Открыта международная фактория! Получено 35 очков Науки, отношение соседей выросло на +20.`;
        }
      },
      {
        id: 'ban_foreigners',
        text: 'Прогнать чужеземцев, защищая чистоту веры предков',
        costDesc: 'Бесплатно',
        effectDesc: '+25 Очков Культуры 📜, +15% к сплоченности столицы',
        canAfford: () => true,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.culturePoints = (player.culturePoints ?? 0) + 25;
          if (player.capitalCityId) {
            const cap = state.cities.get(player.capitalCityId);
            if (cap) cap.authority = Math.min(100, cap.authority + 15);
          }
          return `🛡️ ЗАЩИТА ТРАДИЦИЙ: Иноземцы изгнаны! Народ восславил преданность предкам: +25 очков Культуры.`;
        }
      }
    ]
  },
  {
    id: 'QUEST_SOLAR_ECLIPSE',
    title: 'Великое Солнечное Затмение',
    icon: '🌑',
    description: 'Черная тень поглотила дневное светило в полдень. Птицы смолкли, а народ в ужасе пал на колени, видя в небе гнев божеств.',
    choices: [
      {
        id: 'grand_ritual',
        text: 'Принести обильные жертвы в верховном зиккурате',
        costDesc: '🌾 35 Зерна',
        effectDesc: '+25% к Легитимности монарха, подавление смут и волнений во всех городах',
        canAfford: (state) => (state.getPlayerFaction()?.grain ?? 0) >= 35,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.grain -= 35;
          if (player.ruler) {
            player.ruler.legitimacy = Math.min(100, player.ruler.legitimacy + 25);
          }
          for (const city of state.cities.values()) {
            if (city.factionId === player.id) {
              city.authority = Math.min(100, city.authority + 10);
            }
          }
          return `☀️ МИЛОСТЬ БОГОВ: Верховный ритуал рассеял тьму! Легитимность царя возросла до небес (+25%), мятежи подавлены.`;
        }
      },
      {
        id: 'rational_approach',
        text: 'Объявить затмение естественным небесным циклом',
        costDesc: 'Бесплатно',
        effectDesc: '-10% к авторитету правителя среди простолюдинов, но +20 Науки 🔬',
        canAfford: () => true,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.sciencePoints = (player.sciencePoints ?? 0) + 20;
          if (player.ruler) {
            player.ruler.legitimacy = Math.max(15, player.ruler.legitimacy - 10);
          }
          return `🔭 ЗНАМЕНИЕ АСТРОНОМОВ: Жрецы составили карту небесных светил (+20 Науки), хотя суеверная чернь возроптала.`;
        }
      }
    ]
  },
  {
    id: 'QUEST_RICH_VEIN',
    title: 'Богатая Медная Жила в Горах',
    icon: '⛏️',
    description: 'Горные пастухи наткнулись на гигантские самородные жилы красной меди и олова в скалистых ущельях.',
    choices: [
      {
        id: 'mobilize_miners',
        text: 'Снарядить царскую горную экспедицию',
        costDesc: '🌾 30 Зерна, 💰 20 Золота',
        effectDesc: '+3 Меди 🪨, +2 Олова ⛏️, +40 Золота в царскую казну',
        canAfford: (state) => {
          const p = state.getPlayerFaction();
          return (p?.grain ?? 0) >= 30 && (p?.gold ?? 0) >= 20;
        },
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.grain -= 30;
          player.gold += 20; // -20 cost + 40 gain = +20 net
          if (!player.resources) player.resources = { copper: 0, tin: 0, cattle: 0, incense: 0 };
          player.resources.copper = (player.resources.copper ?? 0) + 3;
          player.resources.tin = (player.resources.tin ?? 0) + 2;
          return `⛏️ МЕТАЛЛ БРОНЗОВОГО ВЕКА: Экспедиция открыла рудник! Получено +3 Меди, +2 Олова и +40 Золота.`;
        }
      },
      {
        id: 'leave_sacred_peaks',
        text: 'Запретить раскопки, почитая горы как священную обитель духов',
        costDesc: 'Бесплатно',
        effectDesc: '+15% к сплоченности в холмах и предгорьях, +20 Очков Культуры',
        canAfford: () => true,
        apply: (state) => {
          const player = state.getPlayerFaction();
          if (!player) return '';
          player.culturePoints = (player.culturePoints ?? 0) + 20;
          for (const prov of state.provinces.values()) {
            if (prov.ownerFactionId === player.id && (prov.biome === BiomeType.HILLS || prov.biome === BiomeType.MOUNTAINS)) {
              prov.authority = Math.min(100, prov.authority + 15);
            }
          }
          return `🏔️ ЗАПОВЕДНЫЕ ВЕРШИНЫ: Скалы оставлены духам. Сплоченность горных кланов выросла на 15%, получено +20 Культуры.`;
        }
      }
    ]
  }
];

export class QuestSystem {
  static getNextQuest(state: GameState, questIndex: number): QuestEvent {
    const idx = questIndex % HISTORICAL_QUESTS.length;
    return HISTORICAL_QUESTS[idx];
  }
}
