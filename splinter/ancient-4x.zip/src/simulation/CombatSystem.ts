// src/simulation/CombatSystem.ts - Army Combat Resolution & Unit Production
import { Unit, UnitType, HexTile, Province, BiomeType, Faction } from '../entities/Types.ts';

export interface BattleResult {
  attackerDamage: number;
  defenderDamage: number;
  attackerSurvived: boolean;
  defenderSurvived: boolean;
  isVictory: boolean;
  description: string;
}

export class CombatSystem {
  /**
   * Base combat strength for each unit type
   */
  static getBaseStrength(type: UnitType): number {
    switch (type) {
      case UnitType.SETTLER: return 5;
      case UnitType.HORDE: return 15;
      case UnitType.SPEARMEN: return 12;
      case UnitType.ARCHERS: return 14;
      case UnitType.CHARIOT: return 20;
      case UnitType.LEGION: return 30;
      case UnitType.HEAVY_CAVALRY: return 36;
      case UnitType.MUSKETEER: return 48;
      case UnitType.CANNON: return 55;
      case UnitType.INFANTRY: return 72;
      case UnitType.TANK: return 98;
      case UnitType.REBEL: return 42;
      default: return 10;
    }
  }

  /**
   * Recruitment cost in Gold & Grain
   */
  static getRecruitmentCost(type: UnitType): { gold: number; grain: number } {
    switch (type) {
      case UnitType.SPEARMEN: return { gold: 30, grain: 25 };
      case UnitType.ARCHERS: return { gold: 35, grain: 20 };
      case UnitType.CHARIOT: return { gold: 50, grain: 35 };
      case UnitType.LEGION: return { gold: 55, grain: 35 };
      case UnitType.HEAVY_CAVALRY: return { gold: 70, grain: 45 };
      case UnitType.MUSKETEER: return { gold: 75, grain: 30 };
      case UnitType.CANNON: return { gold: 90, grain: 25 };
      case UnitType.INFANTRY: return { gold: 100, grain: 40 };
      case UnitType.TANK: return { gold: 150, grain: 30 };
      default: return { gold: 40, grain: 30 };
    }
  }

  /**
   * Calculate tactical battle resolution
   */
  static calculateBattle(
    attacker: Unit,
    defender: Unit,
    targetTile: HexTile,
    attackerFaction: Faction | null,
    defenderFaction: Faction | null
  ): BattleResult {
    const attBase = attacker.combatStrength || this.getBaseStrength(attacker.type);
    const defBase = defender.combatStrength || this.getBaseStrength(defender.type);

    // 1. Terrain Defense Modifier
    let terrainDefBonus = 0;
    if (targetTile.biome === BiomeType.MOUNTAINS) terrainDefBonus = 0.45;
    else if (targetTile.biome === BiomeType.HILLS) terrainDefBonus = 0.25;
    else if (targetTile.biome === BiomeType.FOREST) terrainDefBonus = 0.18;

    // 2. Strategic Resource Buff (+25% power if supplying proper metals)
    let attResourceBonus = 0;
    if (attackerFaction?.resources?.copper && attackerFaction.resources.copper > 0) {
      attResourceBonus = 0.20;
    }
    let defResourceBonus = 0;
    if (defenderFaction?.resources?.copper && defenderFaction.resources.copper > 0) {
      defResourceBonus = 0.20;
    }

    // 3. Dice Roll (1 to 6)
    const rollAtt = Math.floor(Math.random() * 6) + 1;
    const rollDef = Math.floor(Math.random() * 6) + 1;

    const totalAttPower = attBase * (1 + attResourceBonus) + rollAtt;
    const totalDefPower = defBase * (1 + terrainDefBonus + defResourceBonus) + rollDef;

    // Damage calculations
    const ratio = totalAttPower / Math.max(1, totalDefPower);
    const defDamage = Math.max(15, Math.min(100, Math.round(35 * ratio)));
    const attDamage = Math.max(10, Math.min(100, Math.round(28 / Math.max(0.4, ratio))));

    attacker.hp = Math.max(0, attacker.hp - attDamage);
    defender.hp = Math.max(0, defender.hp - defDamage);

    const attackerSurvived = attacker.hp > 0;
    const defenderSurvived = defender.hp > 0;
    const isVictory = defender.hp <= 0 && attackerSurvived;

    let desc = '';
    if (isVictory) {
      desc = `⚔️ Победа! Армия «${attacker.name}» (урон ${attDamage}) наголову разбила отряд «${defender.name}» (урон ${defDamage})!`;
    } else if (!attackerSurvived && defenderSurvived) {
      desc = `💀 Поражение! Армия «${attacker.name}» пала в кровопролитном сражении с «${defender.name}».`;
    } else {
      desc = `⚔️ Ожесточенный бой! Обе стороны понесли тяжелые потери (урон ${attDamage} / ${defDamage}).`;
    }

    return {
      attackerDamage: attDamage,
      defenderDamage: defDamage,
      attackerSurvived,
      defenderSurvived,
      isVictory,
      description: desc
    };
  }
}
