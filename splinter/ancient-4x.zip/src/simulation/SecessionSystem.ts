// Dynamic Empire Secession, Civil War and Splinter Faction Generation on Province Level
import { City, Faction, HexTile, Unit, UnitType, UnrestStage, Culture, Province, DiplomaticStatus, FactionTier } from '../entities/Types.ts';
import { HexCoord } from '../map/HexCoord.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';
import { EventBus } from '../core/EventBus.ts';
import { NameGenerator } from '../utils/NameGenerator.ts';

export class SecessionSystem {
  private static FACTION_COLORS = [
    '#e74c3c', '#9b59b6', '#1abc9c', '#f39c12', '#34495e', '#16a085', '#c0392b', '#8e44ad'
  ];
  private static colorIdx = 0;

  static update(
    cities: Map<string, City>,
    factions: Map<string, Faction>,
    cultures: Map<string, Culture>,
    units: Map<string, Unit>,
    tiles: Map<string, HexTile>,
    provinces: Map<string, Province>,
    currentTurn: number
  ): void {
    const candidateCities: City[] = [];

    for (const city of cities.values()) {
      const faction = factions.get(city.factionId);
      if (!faction || city.id === faction.capitalCityId) continue;

      // Non-aggression pact protects border regions from breakaway secession!
      if (this.isProtectedByBorderPact(city, factions, provinces, tiles)) {
        continue;
      }

      if (city.unrestStage === UnrestStage.SECESSION_CRISIS) {
        if (Math.random() < GAME_CONSTANTS.UNREST.CRISIS_SECESSION_CHANCE) {
          candidateCities.push(city);
        }
      } else if (city.unrestStage === UnrestStage.AUTONOMY_DEMAND) {
        const bankruptcyShock = faction.gold <= 0 || faction.grain <= 0;
        if (bankruptcyShock && Math.random() < 0.25) {
          candidateCities.push(city);
        }
      }
    }

    for (const city of candidateCities) {
      this.executeSecession(city, cities, factions, cultures, units, tiles, provinces, currentTurn);
    }
  }

  private static isProtectedByBorderPact(
    city: City,
    factions: Map<string, Faction>,
    provinces: Map<string, Province>,
    tiles: Map<string, HexTile>
  ): boolean {
    const faction = factions.get(city.factionId);
    if (!faction || !faction.diplomacy) return false;

    const prov = city.provinceId ? provinces.get(city.provinceId) : null;
    const hexKeys = prov ? prov.hexKeys : [`${city.q},${city.r}`];

    for (const hKey of hexKeys) {
      const tile = tiles.get(hKey);
      if (!tile) continue;
      const coord = new HexCoord(tile.q, tile.r);
      for (const n of coord.neighbors()) {
        const nTile = tiles.get(n.key);
        if (nTile && nTile.ownerFactionId && nTile.ownerFactionId !== city.factionId) {
          const rel = faction.diplomacy[nTile.ownerFactionId];
          if (rel && rel.status === DiplomaticStatus.NON_AGGRESSION && rel.pactTurnsLeft > 0) {
            return true;
          }
        }
      }
    }
    return false;
  }

  static executeSecession(
    city: City,
    cities: Map<string, City>,
    factions: Map<string, Faction>,
    cultures: Map<string, Culture>,
    units: Map<string, Unit>,
    tiles: Map<string, HexTile>,
    provinces: Map<string, Province>,
    currentTurn: number
  ): void {
    const oldFaction = factions.get(city.factionId);
    if (!oldFaction) return;

    const localCulture = cultures.get(city.dominantCultureId);
    const cultureName = localCulture ? localCulture.name : 'Вольная';

    // 1. Generate New Faction Identity
    const cleanCityName = city.name.split(' ')[0];
    const newFactionId = `faction_breakaway_${city.id}_${currentTurn}`;
    const newFactionName = NameGenerator.generateFactionName(cleanCityName);
    const newColor = this.FACTION_COLORS[(this.colorIdx++) % this.FACTION_COLORS.length];

    const leader = NameGenerator.generateLeaderName();

    const newFaction: Faction = {
      id: newFactionId,
      name: newFactionName,
      color: newColor,
      capitalCityId: city.id,
      rootCultureId: city.dominantCultureId,
      isPlayer: false,
      isBreakaway: true,
      gold: 100,
      grain: 120,
      overextension: 5,
      atWarWith: [oldFaction.id],
      ruler: {
        name: leader,
        title: 'Царь-Освободитель',
        age: 28 + Math.floor(Math.random() * 10),
        maxAge: 65,
        legitimacy: 80,
        traits: ['Пассионарий', 'Вождь восстания'],
        mainTrait: 'CONQUEROR'
      },
      isInterregnum: false,
      interregnumTurnsLeft: 0,
      diplomacy: {
        [oldFaction.id]: {
          status: DiplomaticStatus.WAR,
          opinion: -90,
          pactTurnsLeft: 0
        }
      },
      culturePoints: 30,
      unlockedDogmas: [],
      resources: { copper: 1, tin: 0, cattle: 2, incense: 1 },
      tier: FactionTier.TRIBE,
      outposts: []
    };

    if (!oldFaction.diplomacy) oldFaction.diplomacy = {};
    oldFaction.diplomacy[newFactionId] = {
      status: DiplomaticStatus.WAR,
      opinion: -90,
      pactTurnsLeft: 0
    };

    // Initialize relations with other factions
    for (const f of factions.values()) {
      if (f.id !== oldFaction.id && f.id !== newFactionId) {
        newFaction.diplomacy[f.id] = { status: DiplomaticStatus.PEACE, opinion: 0, pactTurnsLeft: 0 };
        if (!f.diplomacy) f.diplomacy = {};
        f.diplomacy[newFactionId] = { status: DiplomaticStatus.PEACE, opinion: 0, pactTurnsLeft: 0 };
      }
    }

    oldFaction.atWarWith.push(newFactionId);
    factions.set(newFactionId, newFaction);

    // 2. Transfer City and Province
    city.factionId = newFactionId;
    city.authority = 90;
    city.unrestStage = UnrestStage.INTEGRATED;
    city.accumulatedDrift = 0;

    // Transfer ENTIRE PROVINCE (all its hexes) to the new breakaway faction!
    const prov = city.provinceId ? provinces.get(city.provinceId) : null;
    if (prov) {
      prov.ownerFactionId = newFactionId;
      prov.dominantCultureId = city.dominantCultureId;
      prov.authority = 90;
      prov.unrestStage = UnrestStage.INTEGRATED;

      for (const hKey of prov.hexKeys) {
        const pTile = tiles.get(hKey);
        if (pTile) {
          pTile.ownerFactionId = newFactionId;
        }
      }
    }

    // 3. Transform or Spawn Breakaway Rebel Army
    const rebelUnitId = `unit_rebel_${city.id}_${currentTurn}`;
    const rebelArmy: Unit = {
      id: rebelUnitId,
      name: `Ополчение ${cleanCityName}а`,
      type: UnitType.SPEARMEN,
      factionId: newFactionId,
      q: city.q,
      r: city.r,
      hp: 100,
      maxHp: 100,
      movesLeft: 2,
      maxMoves: 2,
      combatStrength: 12,
      supply: 100,
      isGarrisoned: true,
      loyalty: 95,
      generalName: leader
    };
    units.set(rebelUnitId, rebelArmy);

    // 4. Fire Secession Event
    EventBus.emit('SECESSION_TRIGGERED', {
      turn: currentTurn,
      originalFactionId: oldFaction.id,
      originalFactionName: oldFaction.name,
      newFactionId,
      newFactionName,
      cityName: city.name,
      provinceName: prov ? prov.name : city.name,
      cultureName,
      leaderName: leader,
      isPlayerEmpire: oldFaction.isPlayer
    });

    // 5. If this was the Player's empire, present the historic choice!
    if (oldFaction.isPlayer) {
      EventBus.emit('PLAYER_SPLIT_CHOICE', {
        turn: currentTurn,
        oldFaction,
        newFaction,
        city,
        leaderName: leader
      });
    }
  }

  static switchPlayerFaction(
    oldFaction: Faction,
    newFaction: Faction
  ): void {
    oldFaction.isPlayer = false;
    newFaction.isPlayer = true;
  }
}
