// src/simulation/ResearchSystem.ts - Research Lab, Technology Tree and Modern Era Progression
import { Faction, HistoricalAge, FactionTier } from '../entities/Types.ts';
import { EventBus } from '../core/EventBus.ts';

export interface Technology {
  id: string;
  name: string;
  age: HistoricalAge;
  cost: number;
  icon: string;
  desc: string;
  effectText: string;
  prerequisites: string[];
}

export const RESEARCH_TECHS: Technology[] = [
  // Era 1: Iron Age
  {
    id: 'TECH_IRON_WORKING',
    name: 'Выплавка железа и Стальное оружие',
    age: HistoricalAge.IRON_AGE,
    cost: 50,
    icon: '⚔️',
    desc: 'Переход в Железный Век. Раскрывает тайны ковки закаленной стали.',
    effectText: 'Открывает тяжелую пехоту (Легионы, 28 силы) и тяжелую кавалерию. +20% к выработке всех шахт.',
    prerequisites: []
  },
  // Era 2: Renaissance
  {
    id: 'TECH_GUNPOWDER',
    name: 'Печатный станок и Порох',
    age: HistoricalAge.RENAISSANCE,
    cost: 110,
    icon: '📜',
    desc: 'Наступление Эпохи Возрождения. Массовое книгопечатание и огнестрельное оружие.',
    effectText: 'Открывает Мушкетеров (45 силы) и Пушки (52 силы). +50% к генерации Очков Исследований.',
    prerequisites: ['TECH_IRON_WORKING']
  },
  // Era 3: Industrial Era
  {
    id: 'TECH_STEAM_POWER',
    name: 'Паровой двигатель и Мануфактуры',
    age: HistoricalAge.INDUSTRIAL,
    cost: 200,
    icon: '⚙️',
    desc: 'Индустриальная революция. Заводы, железные дороги и массовое производство.',
    effectText: 'Открывает Моторизованную Пехоту (70 силы). Удваивает доходы от рынков. На дорогах вместо варваров возникают Повстанцы.',
    prerequisites: ['TECH_GUNPOWDER']
  },
  // Era 4: Modern Era
  {
    id: 'TECH_ELECTRONICS',
    name: 'Электроника и Атомная Энергия',
    age: HistoricalAge.MODERN,
    cost: 320,
    icon: '⚡',
    desc: 'Современная Эпоха. Вычислительные машины, бронетехника и урбанизация.',
    effectText: 'Открывает Танки (95 силы). Превращает все Аванпосты в высокоразвитые Мегаполисы.',
    prerequisites: ['TECH_STEAM_POWER']
  },
  // Victory Technology
  {
    id: 'TECH_SPACE_COLONIZATION',
    name: 'Глобальная Квантовая Сеть и Космодром',
    age: HistoricalAge.MODERN,
    cost: 450,
    icon: '🚀',
    desc: 'Финальный триумф разума. Выход человечества за пределы колыбели Земли.',
    effectText: '🌟 НАУЧНАЯ ПОБЕДА В ИГРЕ! Ваша цивилизация объединяет планету в единую сверхсеть.',
    prerequisites: ['TECH_ELECTRONICS']
  }
];

export class ResearchSystem {
  /**
   * Calculate science points generation for a faction per turn
   */
  static calculateTurnScience(faction: Faction, citiesCount: number, hasAlphabet: boolean): number {
    let base = citiesCount * 6;
    if (hasAlphabet) base += 8;
    if (faction.unlockedTechs?.includes('TECH_GUNPOWDER')) base = Math.round(base * 1.5);
    if (faction.unlockedTechs?.includes('TECH_STEAM_POWER')) base += 15;
    return base;
  }

  /**
   * Unlock research technology
   */
  static unlockTech(
    faction: Faction,
    techId: string,
    currentAge: HistoricalAge,
    setAge: (age: HistoricalAge) => void,
    addLog: (msg: string, type?: string) => void
  ): { success: boolean; message: string; isVictory?: boolean } {
    const tech = RESEARCH_TECHS.find(t => t.id === techId);
    if (!tech) return { success: false, message: 'Технология не найдена' };

    if (!faction.unlockedTechs) faction.unlockedTechs = [];
    if (faction.unlockedTechs.includes(techId)) {
      return { success: false, message: 'Эта технология уже изучена!' };
    }

    // Check prerequisites
    for (const pre of tech.prerequisites) {
      if (!faction.unlockedTechs.includes(pre)) {
        const preTech = RESEARCH_TECHS.find(t => t.id === pre);
        return { success: false, message: `Требуется предварительно изучить: «${preTech?.name || pre}»!` };
      }
    }

    const scienceBalance = faction.sciencePoints ?? 0;
    if (scienceBalance < tech.cost) {
      return { success: false, message: `Недостаточно Очков Исследований (нужно ${tech.cost} 🔬, у вас ${scienceBalance})!` };
    }

    // Deduct cost and add tech
    faction.sciencePoints = scienceBalance - tech.cost;
    faction.unlockedTechs.push(techId);

    // Transition age if technology advances era
    if (tech.age !== currentAge) {
      setAge(tech.age);
    }

    addLog(
      `🔬 НАУЧНОЕ ОТКРЫТИЕ: Изучена технология «${tech.name}»! ${tech.effectText}`,
      'info'
    );

    const isVictory = techId === 'TECH_SPACE_COLONIZATION';
    EventBus.emit('TECHNOLOGY_RESEARCHED', { factionId: faction.id, techId, isVictory });

    return { success: true, message: `Успешно открыто: ${tech.name}!`, isVictory };
  }
}
