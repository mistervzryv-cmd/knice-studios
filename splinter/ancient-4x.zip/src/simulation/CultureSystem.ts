// Culture Drift, Diffusion and Speciation System on Province Level
import { City, Culture, Faction, HexTile, Province } from '../entities/Types.ts';
import { HexCoord } from '../map/HexCoord.ts';
import { Pathfinding } from '../map/Pathfinding.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';
import { EventBus } from '../core/EventBus.ts';
import { NameGenerator } from '../utils/NameGenerator.ts';

export class CultureSystem {
  // Color palette for divergent cultures
  private static DIVERGENT_COLORS = [
    '#2ecc71', '#1abc9c', '#3498db', '#e74c3c', '#9b59b6', '#f39c12', '#d35400', '#16a085', '#27ae60'
  ];
  private static colorIdx = 0;

  static update(
    cities: Map<string, City>,
    factions: Map<string, Faction>,
    cultures: Map<string, Culture>,
    tiles: Map<string, HexTile>,
    provinces: Map<string, Province>,
    currentTurn: number
  ): void {
    for (const city of cities.values()) {
      const faction = factions.get(city.factionId);
      if (!faction) continue;

      const capital = faction.capitalCityId ? cities.get(faction.capitalCityId) : null;
      if (!capital) continue;

      const isCapital = city.id === capital.id;

      // Calculate distance between Province Centers
      const capProvince = capital.provinceId ? provinces.get(capital.provinceId) : null;
      const cityProvince = city.provinceId ? provinces.get(city.provinceId) : null;

      const capCoord = capProvince ? new HexCoord(capProvince.centerQ, capProvince.centerR) : new HexCoord(capital.q, capital.r);
      const cityCoord = cityProvince ? new HexCoord(cityProvince.centerQ, cityProvince.centerR) : new HexCoord(city.q, city.r);

      // 1. Calculate Effective Logistics Distance between Province Centers
      let effDist = 0;
      if (!isCapital) {
        effDist = Pathfinding.calculateLogisticsCost(capCoord, cityCoord, tiles);
        city.effectiveDistanceToCapital = effDist;
      } else {
        city.effectiveDistanceToCapital = 0;
      }

      // 2. Capital Cultural Pressure
      const empireCityCount = Array.from(cities.values()).filter(c => c.factionId === faction.id).length;
      const overextFactor = 1 + GAME_CONSTANTS.LOGISTICS.BETA_OVEREXTENSION_BURDEN * empireCityCount;
      const distFactor = 1 + GAME_CONSTANTS.LOGISTICS.ALPHA_DISTANCE_BURDEN * effDist;
      const capitalCulturePower = 100;
      const corePressure = isCapital ? capitalCulturePower : capitalCulturePower / (distFactor * overextFactor);

      // 3. Syncretism with frontier tribes in province
      let syncretismDrift = 0;
      if (cityProvince?.tribalCamp) {
        syncretismDrift += 3.5;
      }

      // 4. Calculate Net Drift Delta
      let deltaDrift = 0;
      if (isCapital) {
        deltaDrift = -GAME_CONSTANTS.CULTURE.CORE_REPRESSION_POWER;
      } else {
        const isolationDrift = Math.max(0, (effDist - 3) * 0.8);
        const overexpansionDrift = (faction.overextension / 100) * 2.5;
        const garrisonDampening = city.garrisonStrength * 0.2;

        const refugeDrift = cityProvince?.isRefuge ? 5.0 : 0;

        deltaDrift = GAME_CONSTANTS.CULTURE.BASE_DRIFT_PER_TURN
          + isolationDrift
          + overexpansionDrift
          + syncretismDrift
          + refugeDrift
          - (corePressure * 0.04)
          - garrisonDampening;
      }

      city.accumulatedDrift = Math.max(0, Math.min(100, city.accumulatedDrift + deltaDrift));
      if (cityProvince) {
        cityProvince.accumulatedDrift = city.accumulatedDrift;
      }

      // 5. Check Divergence Threshold (Speciation Event on Province Level!)
      if (city.accumulatedDrift >= GAME_CONSTANTS.CULTURE.DRIFT_ACCUMULATION_THRESHOLD) {
        this.triggerCultureDivergence(city, faction, cultures, tiles, provinces, currentTurn);
      }
    }
  }

  private static triggerCultureDivergence(
    city: City,
    faction: Faction,
    cultures: Map<string, Culture>,
    tiles: Map<string, HexTile>,
    provinces: Map<string, Province>,
    currentTurn: number
  ): void {
    const parentCulture = cultures.get(city.dominantCultureId);
    const parentName = parentCulture ? parentCulture.name : 'Древняя';

    const newCultureId = `culture_${city.id}_${currentTurn}`;
    const newCultureName = NameGenerator.generateCultureName(parentName);
    const color = this.DIVERGENT_COLORS[(this.colorIdx++) % this.DIVERGENT_COLORS.length];

    const newCulture: Culture = {
      id: newCultureId,
      name: newCultureName,
      parentId: parentCulture ? parentCulture.id : null,
      divergenceTurn: currentTurn,
      color,
      traits: ['Своеобычные обычаи', 'Неприязнь к имперским мытарям', 'Местный диалект']
    };

    cultures.set(newCultureId, newCulture);

    // Update city dominance and reset drift
    city.dominantCultureId = newCultureId;
    city.cultureWeights = { [newCultureId]: 0.85, [parentCulture?.id || 'old']: 0.15 };
    city.accumulatedDrift = 15;

    // Convert ENTIRE PROVINCE to the new culture!
    const province = city.provinceId ? provinces.get(city.provinceId) : null;
    if (province) {
      province.dominantCultureId = newCultureId;
      province.accumulatedDrift = 15;

      for (const hexKey of province.hexKeys) {
        const tile = tiles.get(hexKey);
        if (tile) {
          tile.ownerFactionId = faction.id;
        }
      }
    }

    // Emit event
    EventBus.emit('CULTURE_DIVERGED', {
      cityName: city.name,
      provinceName: province ? province.name : city.name,
      oldCultureName: parentName,
      newCultureName,
      factionName: faction.name,
      turn: currentTurn
    });
  }
}
