// Ruler, Legitimacy and Succession Crisis (Interregnum) System
import { Faction, City, Ruler, UnrestStage, RulerTrait, Province, Unit, HexTile, UnitType, DiplomaticStatus, FactionTier } from '../entities/Types.ts';
import { NameGenerator, PhoneticFlavor } from '../utils/NameGenerator.ts';
import { EventBus } from '../core/EventBus.ts';
import { HexCoord } from '../map/HexCoord.ts';

export class RulerSystem {
  private static TITLES_BY_FLAVOR: Record<PhoneticFlavor, string[]> = {
    MESOPOTAMIAN: ['Великий Лугаль', 'Царь Четырех Сторон Света', 'Энси-Жрец', 'Владыка Двуречья'],
    ELAMITE: ['Шуккальмах', 'Владыка Авана', 'Царь Нагорья и Суз', 'Верховный Регент'],
    LEVANTINE: ['Малк-Суверен', 'Верховный Судия', 'Царь Побережья', 'Хранитель Ковчега'],
    STEPPE: ['Великий Каган', 'Таргитай', 'Вождь Вольных Кочевий', 'Хан Степных Кланов']
  };

  private static TRAITS_POOL = [
    'Строитель зиккуратов', 'Грозный деспот', 'Ирригатор долин', 'Победитель кочевников',
    'Законодатель', 'Храмовый аскет', 'Торговый покровитель', 'Безжалостный сборщик дани'
  ];

  static generateRuler(flavor: PhoneticFlavor = 'MESOPOTAMIAN', baseLegitimacy: number = 88): Ruler {
    const titles = this.TITLES_BY_FLAVOR[flavor] || this.TITLES_BY_FLAVOR.MESOPOTAMIAN;
    const title = titles[Math.floor(Math.random() * titles.length)];
    const name = NameGenerator.generateLeaderName(flavor);
    const age = 24 + Math.floor(Math.random() * 12); // 24 - 35 years old
    // Lives approximately 30-40 turns from ascension
    const maxAge = age + (32 + Math.floor(Math.random() * 9)) * 2; 

    // Pick 2 flavor traits
    const shuffled = [...this.TRAITS_POOL].sort(() => 0.5 - Math.random());
    const traits = shuffled.slice(0, 2);

    // Pick 1 of 3 key functional traits: 'CONQUEROR' | 'WEAK_RULER' | 'BUILDER'
    const traitKeys: RulerTrait[] = ['CONQUEROR', 'WEAK_RULER', 'BUILDER'];
    const mainTrait = traitKeys[Math.floor(Math.random() * traitKeys.length)];

    return {
      name,
      title,
      age,
      maxAge,
      legitimacy: baseLegitimacy,
      traits,
      mainTrait
    };
  }

  static update(
    factions: Map<string, Faction>,
    cities: Map<string, City>,
    provinces: Map<string, Province>,
    units: Map<string, Unit>,
    tiles: Map<string, HexTile>,
    currentTurn: number
  ): void {
    for (const faction of factions.values()) {
      if (!faction.ruler) {
        faction.ruler = this.generateRuler('MESOPOTAMIAN');
      }

      // 1. Handle Interregnum (Смута) duration
      if (faction.isInterregnum) {
        faction.interregnumTurnsLeft--;
        if (faction.interregnumTurnsLeft <= 0) {
          faction.isInterregnum = false;
          EventBus.emit('SUCCESSION_CRISIS', {
            factionName: faction.name,
            rulerName: faction.ruler.name,
            status: 'RESOLVED',
            turn: currentTurn,
            msg: `Смута в державе «${faction.name}» улеглась. Новый правитель ${faction.ruler.title} ${faction.ruler.name} утвердил свою власть!`
          });
        }
      }

      const ruler = faction.ruler;
      // 2. Ruler aging (approx 2 years per turn)
      ruler.age += 2;

      // 3. Ruler Trait passive effects
      if (ruler.mainTrait === 'WEAK_RULER') {
        // Weak Ruler passively reduces authority in all cities by 1% each turn
        const factionCities = Array.from(cities.values()).filter(c => c.factionId === faction.id);
        for (const c of factionCities) {
          c.authority = Math.max(5, c.authority - 1);
        }
      }

      // 4. Legitimacy dynamics
      if (faction.isInterregnum) {
        ruler.legitimacy = Math.min(100, ruler.legitimacy + 4);
      } else {
        if (faction.overextension > 30) {
          ruler.legitimacy = Math.max(5, ruler.legitimacy - Math.round(faction.overextension * 0.08));
        } else {
          ruler.legitimacy = Math.min(100, ruler.legitimacy + 1);
        }

        if (faction.gold <= 0 || faction.grain <= 0) {
          ruler.legitimacy = Math.max(5, ruler.legitimacy - 6);
        }
      }

      // 5. Ruler Death & Succession / Civil War Check!
      // Occurs naturally around every 30-40 turns or if deposed
      const isNaturalDeath = ruler.age >= ruler.maxAge;
      const isDeposed = ruler.legitimacy <= 12 && !faction.isInterregnum;

      if (isNaturalDeath || isDeposed) {
        this.triggerSuccessionCrisis(
          faction,
          cities,
          provinces,
          factions,
          units,
          tiles,
          currentTurn,
          isNaturalDeath ? 'смерти от старости' : 'свержения из-за утраты легитимности'
        );
      }
    }
  }

  private static triggerSuccessionCrisis(
    faction: Faction,
    cities: Map<string, City>,
    provinces: Map<string, Province>,
    factions: Map<string, Faction>,
    units: Map<string, Unit>,
    tiles: Map<string, HexTile>,
    currentTurn: number,
    cause: string
  ): void {
    const oldRuler = faction.ruler;

    // 1. Enter Interregnum (Смута)
    faction.isInterregnum = true;
    faction.interregnumTurnsLeft = 3;

    // 2. Temporarily cut authority in ALL cities of this faction by 30%!
    const factionCities = Array.from(cities.values()).filter(c => c.factionId === faction.id);
    let totalAuth = 0;

    for (const city of factionCities) {
      city.authority = Math.max(5, city.authority - 30);
      totalAuth += city.authority;

      if (city.authority < 15) {
        city.unrestStage = UnrestStage.SECESSION_CRISIS;
      } else if (city.authority < 40) {
        city.unrestStage = UnrestStage.AUTONOMY_DEMAND;
      } else if (city.authority < 70) {
        city.unrestStage = UnrestStage.EROSION;
      }
    }

    const avgCohesion = factionCities.length > 0 ? totalAuth / factionCities.length : 50;

    // 3. Generate New Heir
    const newRuler = this.generateRuler('MESOPOTAMIAN', 50);
    newRuler.age = 20 + Math.floor(Math.random() * 8);
    faction.ruler = newRuler;

    EventBus.emit('RULER_DIED', {
      turn: currentTurn,
      factionId: faction.id,
      factionName: faction.name,
      oldRulerName: `${oldRuler.title} ${oldRuler.name} [${this.getTraitLabel(oldRuler.mainTrait)}]`,
      cause
    });

    // 4. Check for Civil War scenario (Гражданская Война)
    // If overall cohesion < 50%, with 40% probability triggers Civil War!
    if (avgCohesion < 50 && Math.random() < 0.40 && factionCities.length >= 2) {
      this.triggerCivilWar(faction, factionCities, cities, provinces, factions, units, tiles, currentTurn);
    } else {
      EventBus.emit('SUCCESSION_CRISIS', {
        turn: currentTurn,
        factionId: faction.id,
        factionName: faction.name,
        oldRulerName: oldRuler.name,
        newRulerName: `${newRuler.title} ${newRuler.name} [${this.getTraitLabel(newRuler.mainTrait)}]`,
        status: 'STARTED',
        msg: `КРИЗИС ПРЕСТОЛОНАСЛЕДИЯ! Правитель ${oldRuler.name} скончался (${cause}). Власть во всех провинциях упала на 30%! Трон занял наследник ${newRuler.name} [${this.getTraitLabel(newRuler.mainTrait)}].`
      });
    }
  }

  private static triggerCivilWar(
    faction: Faction,
    factionCities: City[],
    cities: Map<string, City>,
    provinces: Map<string, Province>,
    factions: Map<string, Faction>,
    units: Map<string, Unit>,
    tiles: Map<string, HexTile>,
    currentTurn: number
  ): void {
    const nonCapitals = factionCities.filter(c => c.id !== faction.capitalCityId);
    if (nonCapitals.length === 0) return;

    // Split approximately half of the non-capital cities
    const splitCount = Math.max(1, Math.floor(nonCapitals.length / 2));
    const breakawayCities = nonCapitals.slice(0, splitCount);

    const pretenderName = NameGenerator.generateLeaderName();
    const newFactionId = `faction_civilwar_${faction.id}_${currentTurn}`;
    const newFactionName = `Мятежная Лига ${pretenderName}а`;

    const rebelRuler: Ruler = {
      name: pretenderName,
      title: 'Царь-Претендент',
      age: 30,
      maxAge: 70,
      legitimacy: 85,
      traits: ['Мятежник', 'Узурпатор'],
      mainTrait: 'CONQUEROR'
    };

    const rebelFaction: Faction = {
      id: newFactionId,
      name: newFactionName,
      color: '#e74c3c',
      capitalCityId: breakawayCities[0].id,
      rootCultureId: faction.rootCultureId,
      isPlayer: false,
      isBreakaway: true,
      gold: 100,
      grain: 120,
      overextension: 5,
      atWarWith: [faction.id],
      ruler: rebelRuler,
      isInterregnum: false,
      interregnumTurnsLeft: 0,
      culturePoints: 30,
      unlockedDogmas: [...faction.unlockedDogmas],
      resources: { copper: 1, tin: 1, cattle: 2, incense: 1 },
      tier: faction.tier || FactionTier.TRIBE,
      outposts: [],
      diplomacy: {
        [faction.id]: {
          status: DiplomaticStatus.WAR,
          opinion: -100,
          pactTurnsLeft: 0
        }
      }
    };

    if (!faction.diplomacy) faction.diplomacy = {};
    faction.diplomacy[newFactionId] = {
      status: DiplomaticStatus.WAR,
      opinion: -100,
      pactTurnsLeft: 0
    };
    if (!faction.atWarWith.includes(newFactionId)) faction.atWarWith.push(newFactionId);

    factions.set(newFactionId, rebelFaction);

    // Transfer breakaway cities & their provinces
    for (const city of breakawayCities) {
      city.factionId = newFactionId;
      city.authority = 85;
      city.unrestStage = UnrestStage.INTEGRATED;

      if (city.provinceId) {
        const prov = provinces.get(city.provinceId);
        if (prov) {
          prov.ownerFactionId = newFactionId;
          prov.authority = 85;
          for (const hKey of prov.hexKeys) {
            const tile = tiles.get(hKey);
            if (tile) tile.ownerFactionId = newFactionId;
          }
        }
      }
    }

    // Spawn pretender guard army
    const capCoord = new HexCoord(breakawayCities[0].q, breakawayCities[0].r);
    const rebelArmy: Unit = {
      id: `unit_pretender_guard_${currentTurn}`,
      name: `Гвардия претендента ${pretenderName}а`,
      type: UnitType.SPEARMEN,
      factionId: newFactionId,
      q: capCoord.q,
      r: capCoord.r,
      hp: 100,
      maxHp: 100,
      movesLeft: 2,
      maxMoves: 2,
      combatStrength: 14,
      supply: 100,
      isGarrisoned: true,
      loyalty: 95,
      generalName: pretenderName
    };
    units.set(rebelArmy.id, rebelArmy);

    EventBus.emit('CIVIL_WAR_TRIGGERED', {
      turn: currentTurn,
      originalFactionName: faction.name,
      pretenderFactionName: newFactionName,
      pretenderName,
      rebelCityNames: breakawayCities.map(c => c.name),
      isPlayer: faction.isPlayer
    });

    EventBus.emit('SUCCESSION_CRISIS', {
      turn: currentTurn,
      factionId: faction.id,
      factionName: faction.name,
      oldRulerName: faction.ruler.name,
      newRulerName: faction.ruler.name,
      status: 'CIVIL_WAR',
      msg: `⚡ ГРАЖДАНСКАЯ ВОЙНА В ДЕРЖАВЕ «${faction.name}»! Смерть правителя при средней сплоченности <50% вызвала раскол! ${pretenderName} провозгласил «${newFactionName}» и увел ${breakawayCities.length} городов!`
    });
  }

  static getTraitLabel(trait: RulerTrait): string {
    switch (trait) {
      case 'CONQUEROR': return 'Завоеватель (-30% экспансия, +20% сила)';
      case 'WEAK_RULER': return 'Слабый Правитель (-10% Cohesion)';
      case 'BUILDER': return 'Строитель (-40% постройки)';
    }
  }
}
