// src/simulation/EconomySystem.ts - Economy, Province Buildings, Regimes, Epidemics and Great Wonders
import { Province, Faction, City, HexTile, PoliticalRegime, EdictId, HistoricalAge } from '../entities/Types.ts';
import { HexCoord } from '../map/HexCoord.ts';
import { EventBus } from '../core/EventBus.ts';

export class EconomySystem {
  /**
   * Update province population growth, market gold generation and farm yields
   */
  static updateEconomy(
    provinces: Map<string, Province>,
    factions: Map<string, Faction>,
    cities: Map<string, City>,
    currentTurn: number
  ): void {
    for (const prov of provinces.values()) {
      if (!prov.ownerFactionId) continue;
      const faction = factions.get(prov.ownerFactionId);
      if (!faction) continue;

      // Initialize population if missing (in thousands)
      if (prov.population === undefined || prov.population <= 0) {
        prov.population = Math.round(15 + prov.fertility * 6);
      }

      // 1. Population Growth
      let popGrowth = prov.fertility * 0.4;
      if (prov.hasFarm) popGrowth += 1.2;
      if (prov.isCutOffFromSupply) popGrowth -= 0.8;
      if (prov.isEpidemic) popGrowth = -Math.round(prov.population * 0.15); // plague casualties

      prov.population = Math.max(5, Math.min(500, Math.round(prov.population + popGrowth)));

      // 2. Gold from Markets
      if (prov.hasMarket) {
        const marketYield = faction.unlockedTechs?.includes('TECH_STEAM_POWER') ? 10 : 5;
        faction.gold += marketYield;
      }

      // 3. Wonder Construction Progress
      if (prov.wonderTurnsRemaining !== undefined && prov.wonderTurnsRemaining > 0) {
        prov.wonderTurnsRemaining -= 1;
        if (prov.wonderTurnsRemaining === 0) {
          prov.hasWonder = true;
          if (!faction.wonderProvinces) faction.wonderProvinces = [];
          faction.wonderProvinces.push(prov.id);

          EventBus.emit('WONDER_COMPLETED', {
            provinceId: prov.id,
            provinceName: prov.name,
            wonderName: prov.wonderName || 'Чудо Света',
            factionId: faction.id
          });
        }
      }

      // 4. Epidemic duration
      if (prov.isEpidemic && prov.epidemicTurnsRemaining !== undefined) {
        prov.epidemicTurnsRemaining -= 1;
        if (prov.epidemicTurnsRemaining <= 0) {
          prov.isEpidemic = false;
        }
      }
    }

    // Apply Wonder Cohesion protection aura (5 hex radius gives +30% Cohesion)
    this.applyWonderAuras(provinces);
  }

  /**
   * Apply Wonder of the World +30% Cohesion aura in 5 hex radius
   */
  static applyWonderAuras(provinces: Map<string, Province>): void {
    const wonderProvinces = Array.from(provinces.values()).filter(p => p.hasWonder);
    if (wonderProvinces.length === 0) return;

    for (const wProv of wonderProvinces) {
      const wCoord = new HexCoord(wProv.centerQ, wProv.centerR);
      for (const targetProv of provinces.values()) {
        if (targetProv.ownerFactionId === wProv.ownerFactionId) {
          const tCoord = new HexCoord(targetProv.centerQ, targetProv.centerR);
          if (wCoord.distanceTo(tCoord) <= 5) {
            targetProv.authority = Math.min(100, targetProv.authority + 5); // +5 per turn stability aura
          }
        }
      }
    }
  }

  /**
   * Process 3% epidemic outbreak and contagion transmission along active supply lines
   */
  static updateEpidemics(
    provinces: Map<string, Province>,
    tiles: Map<string, HexTile>,
    currentTurn: number,
    addChronicle: (text: string, type?: string) => void
  ): void {
    // 3% chance for random outbreak
    if (Math.random() < 0.03) {
      const ownedProvinces = Array.from(provinces.values()).filter(p => p.ownerFactionId !== null && !p.isEpidemic);
      if (ownedProvinces.length > 0) {
        const victim = ownedProvinces[Math.floor(Math.random() * ownedProvinces.length)];
        victim.isEpidemic = true;
        victim.epidemicTurnsRemaining = 4;
        victim.authority = Math.max(10, victim.authority - 30);

        addChronicle(
          `☣️ ЧЕРНАЯ МОРОВАЯ ЯЗВА: В провинции «${victim.name}» вспыхнула смертоносная эпидемия! Население косит мор, сплоченность упала на 30%.`,
          'critical'
        );
      }
    }

    // Contagion spread along active supply lines
    const infectedProvinces = Array.from(provinces.values()).filter(p => p.isEpidemic && (p.epidemicTurnsRemaining ?? 0) > 1);
    for (const infProv of infectedProvinces) {
      const infCoord = new HexCoord(infProv.centerQ, infProv.centerR);
      for (const target of provinces.values()) {
        if (!target.isEpidemic && target.ownerFactionId === infProv.ownerFactionId && !target.isCutOffFromSupply) {
          const tCoord = new HexCoord(target.centerQ, target.centerR);
          // Spread to adjacent province with 25% chance
          if (infCoord.distanceTo(tCoord) <= 2 && Math.random() < 0.25) {
            target.isEpidemic = true;
            target.epidemicTurnsRemaining = 3;
            target.authority = Math.max(10, target.authority - 20);

            addChronicle(
              `☣️ ЭПИДЕМИЯ РАСПРОСТРАНЯЕТСЯ: Зараза перекинулась по торговым караванам в провинцию «${target.name}»!`,
              'warning'
            );
          }
        }
      }
    }
  }

  /**
   * Get dynamic name for Wonder based on current historical era
   */
  static getWonderNameForAge(age: HistoricalAge): string {
    switch (age) {
      case HistoricalAge.STONE_TOOLS:
      case HistoricalAge.COPPER_AGE:
        return 'Святилище Великих Предков';
      case HistoricalAge.BRONZE_AGE:
        return 'Великий Ступенчатый Зиккурат';
      case HistoricalAge.IRON_AGE:
        return 'Колосс Непобедимой Империи';
      case HistoricalAge.RENAISSANCE:
        return 'Великий Купольный Собор';
      case HistoricalAge.INDUSTRIAL:
        return 'Монумент Промышленного Величия';
      case HistoricalAge.MODERN:
        return 'Орбитальный Космодром Человечества';
      default:
        return 'Великий Монумент Эпохи';
    }
  }
}
