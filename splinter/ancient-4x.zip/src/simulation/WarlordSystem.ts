// Frontier Military Loyalty, Warlord Ambitions and Diadochi Secession System
import { Unit, Faction, City, HexTile, UnitType, DiplomaticStatus, FactionTier } from '../entities/Types.ts';
import { HexCoord } from '../map/HexCoord.ts';
import { NameGenerator } from '../utils/NameGenerator.ts';
import { EventBus } from '../core/EventBus.ts';

export class WarlordSystem {
  private static WARLORD_COLORS = [
    '#c0392b', '#d35400', '#8e44ad', '#2c3e50', '#16a085', '#7f8c8d', '#b7950b', '#78281f'
  ];
  private static colorIdx = 0;

  static update(
    units: Map<string, Unit>,
    factions: Map<string, Faction>,
    cities: Map<string, City>,
    tiles: Map<string, HexTile>,
    currentTurn: number
  ): void {
    const rebellingUnits: Unit[] = [];

    for (const unit of units.values()) {
      // Settlers don't rebel as warlords
      if (unit.type === UnitType.SETTLER) continue;

      const faction = factions.get(unit.factionId);
      if (!faction) continue;

      // 1. Ensure unit has a general name and baseline loyalty
      if (!unit.generalName) {
        unit.generalName = NameGenerator.generateLeaderName();
      }
      if (unit.loyalty === undefined || unit.loyalty === null) {
        unit.loyalty = 85;
      }

      const unitCoord = new HexCoord(unit.q, unit.r);
      const capital = faction.capitalCityId ? cities.get(faction.capitalCityId) : null;

      // 2. Proximity to power & supply check
      let distToCapital = 99;
      if (capital) {
        distToCapital = unitCoord.distanceTo(new HexCoord(capital.q, capital.r));
      }

      // Check distance to nearest friendly city
      let distToNearestCity = 99;
      for (const city of cities.values()) {
        if (city.factionId === unit.factionId) {
          const cDist = unitCoord.distanceTo(new HexCoord(city.q, city.r));
          if (cDist < distToNearestCity) distToNearestCity = cDist;
        }
      }

      // 3. Loyalty Adjustments
      if (unit.isGarrisoned || distToCapital <= 2) {
        // High loyalty near imperial court
        unit.loyalty = Math.min(100, unit.loyalty + 6);
      } else {
        // Frontier distance erodes loyalty
        if (distToNearestCity >= 4) {
          unit.loyalty = Math.max(0, unit.loyalty - 5);
        }

        // Supply shortages cause soldiers to grumble
        if (unit.supply < 50) {
          unit.loyalty = Math.max(0, unit.loyalty - 7);
        }

        // Succession Crisis (Смута) accelerates warlord rebellion!
        if (faction.isInterregnum) {
          unit.loyalty = Math.max(0, unit.loyalty - 14);
        }
      }

      // 4. Rebellion check (Loyalty < 25%)
      if (unit.loyalty < 25) {
        // Mutiny probability
        const mutinyChance = faction.isInterregnum ? 0.65 : 0.35;
        if (Math.random() < mutinyChance) {
          rebellingUnits.push(unit);
        }
      }
    }

    // Execute Warlord Mutinies / Diadochi splits
    for (const unit of rebellingUnits) {
      this.executeWarlordRevolt(unit, factions, cities, units, tiles, currentTurn);
    }
  }

  static executeWarlordRevolt(
    unit: Unit,
    factions: Map<string, Faction>,
    cities: Map<string, City>,
    units: Map<string, Unit>,
    tiles: Map<string, HexTile>,
    currentTurn: number
  ): void {
    const oldFaction = factions.get(unit.factionId);
    if (!oldFaction) return;

    const general = unit.generalName || 'Мятежный полководец';
    const unitCoord = new HexCoord(unit.q, unit.r);

    // Option A: Check if there is an existing breakaway faction nearby to defect to
    let nearbyBreakaway: Faction | null = null;
    for (const f of factions.values()) {
      if (f.isBreakaway && f.atWarWith.includes(oldFaction.id)) {
        if (f.capitalCityId) {
          const cap = cities.get(f.capitalCityId);
          if (cap && unitCoord.distanceTo(new HexCoord(cap.q, cap.r)) <= 5) {
            nearbyBreakaway = f;
            break;
          }
        }
      }
    }

    if (nearbyBreakaway) {
      // Defect to existing breakaway kingdom!
      unit.factionId = nearbyBreakaway.id;
      unit.loyalty = 85;
      unit.name = `Легион генерала ${general}`;

      const tile = tiles.get(unitCoord.key);
      if (tile && (!tile.cityId || tile.ownerFactionId === oldFaction.id)) {
        tile.ownerFactionId = nearbyBreakaway.id;
      }

      EventBus.emit('WARLORD_REVOLT', {
        turn: currentTurn,
        generalName: general,
        oldFactionName: oldFaction.name,
        newFactionName: nearbyBreakaway.name,
        isDefection: true,
        isPlayerEmpire: oldFaction.isPlayer,
        msg: `МЯТЕЖ ВОЙСК! Полководец ${general} увел свою армию и присягнул отколовшейся державе «${nearbyBreakaway.name}»!`
      });
    } else {
      // Option B: Proclaim an Independent Military Kingdom (Diadochus Coup!)
      const newFactionId = `faction_warlord_${unit.id}_${currentTurn}`;
      const newFactionName = `Царство стратега ${general}`;
      const color = this.WARLORD_COLORS[(this.colorIdx++) % this.WARLORD_COLORS.length];

      const warlordFaction: Faction = {
        id: newFactionId,
        name: newFactionName,
        color,
        capitalCityId: null,
        rootCultureId: oldFaction.rootCultureId,
        isPlayer: false,
        isBreakaway: true,
        gold: 80,
        grain: 100,
        overextension: 0,
        atWarWith: [oldFaction.id],
        ruler: {
          name: general,
          title: 'Царь-Полководец',
          age: 32 + Math.floor(Math.random() * 12),
          maxAge: 68,
          legitimacy: 70,
          traits: ['Полевой командир', 'Кумир солдат'],
          mainTrait: 'CONQUEROR'
        },
        isInterregnum: false,
        interregnumTurnsLeft: 0,
        diplomacy: {
          [oldFaction.id]: {
            status: DiplomaticStatus.WAR,
            opinion: -95,
            pactTurnsLeft: 0
          }
        },
        culturePoints: 20,
        unlockedDogmas: [],
        resources: { copper: 2, tin: 0, cattle: 2, incense: 0 },
        tier: FactionTier.TRIBE,
        outposts: []
      };

      if (!oldFaction.diplomacy) oldFaction.diplomacy = {};
      oldFaction.diplomacy[newFactionId] = {
        status: DiplomaticStatus.WAR,
        opinion: -95,
        pactTurnsLeft: 0
      };

      // Initialize relations with other factions
      for (const f of factions.values()) {
        if (f.id !== oldFaction.id && f.id !== newFactionId) {
          warlordFaction.diplomacy[f.id] = { status: DiplomaticStatus.PEACE, opinion: 0, pactTurnsLeft: 0 };
          if (!f.diplomacy) f.diplomacy = {};
          f.diplomacy[newFactionId] = { status: DiplomaticStatus.PEACE, opinion: 0, pactTurnsLeft: 0 };
        }
      }

      oldFaction.atWarWith.push(newFactionId);
      factions.set(newFactionId, warlordFaction);

      // Re-assign unit
      unit.factionId = newFactionId;
      unit.loyalty = 95;
      unit.name = `Гвардия стратега ${general}`;

      // Claim local tile
      const tile = tiles.get(unitCoord.key);
      if (tile && !tile.cityId) {
        tile.ownerFactionId = newFactionId;
      }

      EventBus.emit('WARLORD_REVOLT', {
        turn: currentTurn,
        generalName: general,
        oldFactionName: oldFaction.name,
        newFactionName,
        isDefection: false,
        isPlayerEmpire: oldFaction.isPlayer,
        msg: `ВОЕННЫЙ ПЕРЕВОРОТ! Полководец ${general}, находясь на фронтире, объявил себя независимым монархом и основал «${newFactionName}»!`
      });
    }
  }
}
