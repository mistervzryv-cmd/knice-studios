// src/simulation/LanguageSystem.ts - Sub-culture & Language Mutation Mechanics
import { Culture, Faction, LanguageState } from '../entities/Types.ts';
import { EventBus } from '../core/EventBus.ts';

export interface LanguageTech {
  id: string;
  name: string;
  icon: string;
  cost: number;
  effect: string;
  bonusType: 'cohesion' | 'science' | 'authority' | 'diplomacy';
  bonusValue: number;
}

export const LANGUAGE_TECHS: LanguageTech[] = [
  {
    id: 'WRITING',
    name: 'Письменность (Клинопись / Иероглифы)',
    icon: '📜',
    cost: 35,
    effect: '+15% к Сплоченности (Cohesion) во всех провинциях державы',
    bonusType: 'cohesion',
    bonusValue: 0.15
  },
  {
    id: 'ALPHABET',
    name: 'Фонетический Алфавит',
    icon: '🔤',
    cost: 45,
    effect: '+10% к Очкам Исследований (Науке) каждый ход',
    bonusType: 'science',
    bonusValue: 0.10
  },
  {
    id: 'GRAMMAR',
    name: 'Грамматика и Кодификация Сводов',
    icon: '📖',
    cost: 40,
    effect: '+10% к Власти (Authority) и стабильности государства',
    bonusType: 'authority',
    bonusValue: 0.10
  },
  {
    id: 'LINGUA_FRANCA',
    name: 'Дипломатический Язык (Лингва-Франка)',
    icon: '🕊️',
    cost: 50,
    effect: '+20 к Дипломатическому Мнению (Opinion) со всеми народами мира',
    bonusType: 'diplomacy',
    bonusValue: 20
  }
];

export class LanguageSystem {
  /**
   * Initialize a default language for a culture if not present
   */
  static initLanguageForCulture(culture: Culture): LanguageState {
    if (!culture.language) {
      culture.language = {
        name: `${culture.name}-Язык`,
        writingLevel: 1,
        features: ['WRITING'],
        divergence: 0
      };
    }
    return culture.language;
  }

  /**
   * Unlock a language advancement for player faction and culture
   */
  static unlockLanguageTech(
    faction: Faction,
    culture: Culture,
    techId: string,
    addLog: (msg: string, type?: string) => void
  ): { success: boolean; message: string } {
    const tech = LANGUAGE_TECHS.find(t => t.id === techId);
    if (!tech) return { success: false, message: 'Технология не найдена' };

    const lang = this.initLanguageForCulture(culture);
    if (lang.features.includes(techId)) {
      return { success: false, message: 'Эта языковая ступень уже открыта!' };
    }

    if (faction.culturePoints < tech.cost) {
      return { success: false, message: `Недостаточно Очков Культуры (нужно ${tech.cost} 📜)!` };
    }

    faction.culturePoints -= tech.cost;
    lang.features.push(techId);
    lang.writingLevel += 1;

    // Apply immediate bonuses
    if (tech.bonusType === 'diplomacy') {
      for (const rel of Object.values(faction.diplomacy)) {
        rel.opinion = Math.min(100, rel.opinion + tech.bonusValue);
      }
    }

    addLog(
      `🗣️ ЯЗЫКОВОЙ ПРОРЫВ: Ваша культура разработала «${tech.name}»! ${tech.effect}.`,
      'info'
    );

    EventBus.emit('LANGUAGE_TECH_UNLOCKED', { factionId: faction.id, techId });
    return { success: true, message: `Успешно открыто: ${tech.name}!` };
  }

  /**
   * Process drift and language mutation for sub-cultures every turn
   */
  static updateSubCultureDrift(
    cultures: Map<string, Culture>,
    factions: Map<string, Faction>,
    currentTurn: number,
    addChronicle: (text: string, type?: string) => void
  ): void {
    const DISTINCT_COLORS = [
      '#e67e22', '#1abc9c', '#9b59b6', '#3498db', '#e74c3c', '#f1c40f', '#2ecc71', '#d35400'
    ];

    for (const cult of cultures.values()) {
      if (!cult.isSubCulture || cult.isUniqueCulture) continue;

      const parentCult = cult.parentCultureId ? cultures.get(cult.parentCultureId) : null;
      if (!parentCult) continue;

      const prevDrift = cult.drift ?? 0;
      // Increment drift by 1-2% per turn
      const driftDelta = 2;
      const newDrift = Math.min(100, prevDrift + driftDelta);
      cult.drift = newDrift;

      if (!cult.language) {
        this.initLanguageForCulture(cult);
      }
      cult.language!.divergence = newDrift;

      // Milestone: 50% language drift
      if (prevDrift < 50 && newDrift >= 50) {
        addChronicle(
          `📜 Летопись Веков (Ход ${currentTurn}): Язык суб-культуры «${cult.name}» отдалился от материнского «${parentCult.name}» на 50%! Нарастает взаимное непонимание и дипломатическое охлаждение.`,
          'warning'
        );

        // Reduce diplomatic opinion between parent faction and sub-culture factions
        for (const faction of factions.values()) {
          if (faction.rootCultureId === cult.id && faction.parentFactionId) {
            const parentFaction = factions.get(faction.parentFactionId);
            if (parentFaction?.diplomacy[faction.id]) {
              parentFaction.diplomacy[faction.id].opinion = Math.max(-100, parentFaction.diplomacy[faction.id].opinion - 25);
            }
            if (faction.diplomacy[parentFaction?.id || '']) {
              faction.diplomacy[parentFaction!.id].opinion = Math.max(-100, faction.diplomacy[parentFaction!.id].opinion - 25);
            }
          }
        }
      }

      // Milestone: 100% full unique cultural speciation!
      if (newDrift >= 100) {
        cult.isUniqueCulture = true;
        cult.isSubCulture = false;
        const color = DISTINCT_COLORS[Math.floor(Math.random() * DISTINCT_COLORS.length)];
        cult.color = color;
        cult.traits = [
          'Уникальные священные писания',
          'Самобытная металлургия',
          'Полная автокефалия'
        ];
        cult.language!.name = `Суверенный ${cult.name}-Язык`;

        addChronicle(
          `🌟 ВЕЛИКИЙ КУЛЬТУРНЫЙ РАСКОЛ (Ход ${currentTurn}): Суб-культура «${cult.name}» завершила обособление (Drift 100%) и превратилась в суверенную Уникальную Цивилизацию со своим языком и независимой идентичностью!`,
          'critical'
        );

        EventBus.emit('UNIQUE_CULTURE_FORMED', { culture: cult, turn: currentTurn });
      }
    }
  }
}
