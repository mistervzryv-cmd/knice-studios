import { Unit, City, HexTile, Faction, Province, FactionTier, DiplomaticStatus, BiomeType, ResourceType } from '../entities/Types.ts';
import { HexCoord } from '../map/HexCoord.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';
import { EventBus } from '../core/EventBus.ts';

export class SupplySystem {
  /**
   * Calculates supply line connectivity from each faction's Capital to its provinces.
   * A province is cut off if there is no valid path to the Capital within Cultural Tier range.
   * Valid paths: own provinces, allied lands, neutral empty lands (without barbarian camps), rivers/seas.
   */
  static updateProvinceSupplyLines(
    provinces: Map<string, Province>,
    cities: Map<string, City>,
    tiles: Map<string, HexTile>,
    factions: Map<string, Faction>,
    units: Map<string, Unit>
  ): void {
    for (const faction of factions.values()) {
      const ownedProvinces = Array.from(provinces.values()).filter(p => p.ownerFactionId === faction.id);
      if (ownedProvinces.length === 0) continue;

      const capitalCity = faction.capitalCityId ? cities.get(faction.capitalCityId) : null;
      if (!capitalCity) {
        // No capital exists -> all provinces are cut off
        for (const prov of ownedProvinces) {
          prov.isCutOffFromSupply = true;
          prov.supplyDistance = Infinity;
        }
        continue;
      }

      const capCoord = new HexCoord(capitalCity.q, capitalCity.r);
      const capProvinceId = capitalCity.provinceId;

      // Cultural Tier Distance and Route Rules:
      // - Tier 1 (Дикое Племя): up to 4 hexes overland, water impassable
      // - Tier 2 (Вождество): up to 7 hexes overland, or through Outposts (distance resets)
      // - Tier 3 (Цивилизация): infinite along rivers and seas/coasts (cost 0), up to 10 hexes overland
      // - Tier 4 (Великая Империя): infinite along rivers/seas (cost 0), up to 16 hexes overland
      const tier = faction.tier || FactionTier.TRIBE;
      let maxOverland = 4;
      let waterBonus = false;
      let outpostRelay = false;

      if (tier === FactionTier.TRIBE) {
        maxOverland = 4;
        waterBonus = false;
        outpostRelay = false;
      } else if (tier === FactionTier.CHIEFDOM) {
        maxOverland = 7;
        waterBonus = false;
        outpostRelay = true;
      } else if (tier === FactionTier.EARLY_STATE) {
        maxOverland = 10;
        waterBonus = true;
        outpostRelay = true;
      } else if (tier === FactionTier.EMPIRE) {
        maxOverland = 16;
        waterBonus = true;
        outpostRelay = true;
      }

      // Shortest overland distance from capital / water network / outpost
      const dist = new Map<string, number>();
      dist.set(capCoord.key, 0);

      // 0-1 BFS deque with unshift (cost 0) and push (cost 1)
      const deque: string[] = [capCoord.key];

      while (deque.length > 0) {
        const currentKey = deque.shift()!;
        const currentDist = dist.get(currentKey)!;

        if (currentDist >= maxOverland && !waterBonus) {
          // Cannot expand overland beyond maxOverland
          continue;
        }

        const currentCoord = HexCoord.fromKey(currentKey);
        for (const nCoord of currentCoord.neighbors()) {
          const nTile = tiles.get(nCoord.key);
          if (!nTile) continue;

          // 1. Blocked by barbarian camp
          if (nTile.tribalCamp) continue;

          // 2. Blocked by hostile unit (enemy faction at war or barbarians)
          if (nTile.unitId) {
            const unit = units.get(nTile.unitId);
            if (unit && (faction.atWarWith?.includes(unit.factionId) || unit.factionId === 'faction_barbarians')) {
              continue;
            }
          }

          // 3. Passage check:
          // Valid paths: own provinces, allied lands, neutral empty lands, rivers, and (for tier 3/4) seas
          const isOwn = nTile.ownerFactionId === faction.id;
          const isAllied = nTile.ownerFactionId ? faction.diplomacy?.[nTile.ownerFactionId]?.status === DiplomaticStatus.ALLIANCE : false;
          const isNeutralEmpty = nTile.ownerFactionId === null;
          const isRiver = nTile.isRiver === true;
          const isOcean = nTile.biome === BiomeType.OCEAN;

          // Ocean traversal only for tier 3 & 4
          if (isOcean && !waterBonus) continue;

          // If foreign land and not allied, not neutral, and not river: blocked!
          if (!isOwn && !isAllied && !isNeutralEmpty && !isRiver && (!isOcean || !waterBonus)) {
            continue;
          }

          // 4. Determine step cost
          let stepCost = 1;
          if (waterBonus && (isRiver || isOcean)) {
            stepCost = 0; // Infinite along rivers and seas for Tier 3 and Tier 4!
          }

          const nProv = nTile.provinceId ? provinces.get(nTile.provinceId) : null;
          let nextDist = currentDist + stepCost;

          // Outpost relay: for Tier 2+, outposts act as forward supply hubs, resetting overland count
          if (outpostRelay && nProv?.isOutpost) {
            nextDist = 0;
          }

          if (nextDist <= maxOverland || (stepCost === 0 && waterBonus)) {
            const prevDist = dist.get(nCoord.key);
            if (prevDist === undefined || nextDist < prevDist) {
              dist.set(nCoord.key, nextDist);
              if (stepCost === 0) {
                deque.unshift(nCoord.key);
              } else {
                deque.push(nCoord.key);
              }
            }
          }
        }
      }

      // Mark provinces as supplied or cut off
      for (const prov of ownedProvinces) {
        if (prov.id === capProvinceId) {
          prov.isCutOffFromSupply = false;
          prov.supplyDistance = 0;
          continue;
        }

        let isSupplied = false;
        let minD = Infinity;

        // Check if any hex of this province is reached by supply lines
        for (const hKey of prov.hexKeys) {
          const d = dist.get(hKey);
          if (d !== undefined && d <= maxOverland) {
            isSupplied = true;
            if (d < minD) minD = d;
          }
        }

        prov.isCutOffFromSupply = !isSupplied;
        prov.supplyDistance = isSupplied ? minD : Infinity;
      }

      // 5. Check Terrain Barriers and Mountain Isolation (Статус "Убежище")
      // Провинции, отрезанные от столицы горами, получают статус "Убежище"
      const mountainFreeReachable = new Set<string>();
      const mQueue: string[] = [capCoord.key];
      mountainFreeReachable.add(capCoord.key);

      while (mQueue.length > 0) {
        const mKey = mQueue.shift()!;
        const mCoord = HexCoord.fromKey(mKey);

        for (const nCoord of mCoord.neighbors()) {
          if (mountainFreeReachable.has(nCoord.key)) continue;
          const nTile = tiles.get(nCoord.key);
          if (!nTile) continue;
          // Impassable for direct mountain-free check
          if (nTile.biome === BiomeType.OCEAN || nTile.biome === BiomeType.MOUNTAINS) continue;

          mountainFreeReachable.add(nCoord.key);
          mQueue.push(nCoord.key);
        }
      }

      for (const prov of ownedProvinces) {
        if (prov.id === capProvinceId) {
          prov.isRefuge = false;
          continue;
        }

        const canReachWithoutMountains = prov.hexKeys.some(k => mountainFreeReachable.has(k));
        prov.isRefuge = !canReachWithoutMountains;
      }

      // 6. Capital Luxuries (Столичные Блага):
      // Rare luxuries (Incense, Cattle) must physically connect via supply lines to the capital.
      // If connected, they grant a global +15% Cohesion bonus to all faction provinces.
      // If cut off, the bonus immediately drops.
      const deliveredLuxuries = new Set<string>();
      for (const prov of ownedProvinces) {
        if (!prov.isCutOffFromSupply) {
          for (const hKey of prov.hexKeys) {
            const tile = tiles.get(hKey);
            if (tile) {
              if (tile.resource === ResourceType.INCENSE) deliveredLuxuries.add('Ладан');
              if (tile.resource === ResourceType.CATTLE) deliveredLuxuries.add('Скот');
            }
          }
        }
      }

      const hadLuxury = !!faction.hasCapitalLuxury;
      faction.hasCapitalLuxury = deliveredLuxuries.size > 0;
      faction.capitalLuxuries = Array.from(deliveredLuxuries);

      if (hadLuxury !== faction.hasCapitalLuxury) {
        EventBus.emit('CAPITAL_LUXURY_CHANGED', {
          factionId: faction.id,
          hasCapitalLuxury: faction.hasCapitalLuxury,
          luxuries: faction.capitalLuxuries
        });
      }
    }
  }

  static update(
    units: Map<string, Unit>,
    cities: Map<string, City>,
    tiles: Map<string, HexTile>,
    factions: Map<string, Faction>
  ): void {
    const deadUnitIds: string[] = [];

    for (const unit of units.values()) {
      const unitCoord = new HexCoord(unit.q, unit.r);
      const unitTile = tiles.get(unitCoord.key);

      // Check if unit is in friendly territory or near a friendly city
      let hasFriendlyBaseNear = false;

      // 1. Is standing in friendly territory?
      if (unitTile && unitTile.ownerFactionId === unit.factionId) {
        hasFriendlyBaseNear = true;
      } else {
        // 2. Is within supply radius of any friendly city?
        for (const city of cities.values()) {
          if (city.factionId === unit.factionId) {
            const cityCoord = new HexCoord(city.q, city.r);
            if (unitCoord.distanceTo(cityCoord) <= GAME_CONSTANTS.SUPPLY.BASE_RADIUS) {
              hasFriendlyBaseNear = true;
              break;
            }
          }
        }
      }

      if (hasFriendlyBaseNear) {
        // Resupply
        unit.supply = Math.min(100, unit.supply + 30);
      } else {
        // Cut off from supply lines
        unit.supply = Math.max(0, unit.supply - GAME_CONSTANTS.SUPPLY.ATTRITION_PER_TURN);

        // If completely out of supplies, suffer starvation attrition
        if (unit.supply === 0) {
          unit.hp -= GAME_CONSTANTS.SUPPLY.STARVATION_HP_LOSS;
          if (unit.hp <= 0) {
            deadUnitIds.push(unit.id);
            if (unitTile) unitTile.unitId = null;
          }
        }
      }
    }

    for (const id of deadUnitIds) {
      const deadUnit = units.get(id);
      if (deadUnit) {
        units.delete(id);
        EventBus.emit('UNIT_DIED', {
          unitName: deadUnit.name,
          factionId: deadUnit.factionId,
          reason: 'Голод и истощение линий снабжения'
        });
      }
    }
  }
}
