import { City, Faction, Culture, UnrestStage, Province, DogmaId, FactionTier } from '../entities/Types.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';
import { EventBus } from '../core/EventBus.ts';

export class LogisticsSystem {
  static update(
    cities: Map<string, City>,
    factions: Map<string, Faction>,
    cultures: Map<string, Culture>,
    provinces: Map<string, Province>,
    currentTurn: number
  ): void {
    // 1. Calculate Overextension for each faction
    for (const faction of factions.values()) {
      const empireCities = Array.from(cities.values()).filter(c => c.factionId === faction.id);
      const cityCount = empireCities.length;

      // Base overextension increases past 2 provinces
      const excessCities = Math.max(0, cityCount - 2);
      const totalLogisticsDist = empireCities.reduce((sum, c) => sum + c.effectiveDistanceToCapital, 0);
      
      faction.overextension = Math.round(excessCities * 18 + totalLogisticsDist * 1.2);
    }

    // 2. Calculate Authority and Unrest Stage for every City and its Province
    for (const city of cities.values()) {
      const faction = factions.get(city.factionId);
      if (!faction) continue;

      const isCapital = city.id === faction.capitalCityId;
      const rootCulture = cultures.get(faction.rootCultureId);
      const localCulture = cultures.get(city.dominantCultureId);

      // Cultural alienation
      const isCulturallyAlienated = localCulture && rootCulture && localCulture.id !== rootCulture.id;
      const alienationPenalty = isCulturallyAlienated ? GAME_CONSTANTS.LOGISTICS.CULTURAL_ALIENATION_PENALTY : 0;

      // Garrison authority contribution
      const garrisonBonus = Math.min(25, city.garrisonStrength * 2.5);

      // Distance penalty between province centers
      const distancePenalty = isCapital ? 0 : city.effectiveDistanceToCapital * 3.8;

      // Overextension drag
      const overextensionDrag = faction.overextension * 0.35;

      let authority = GAME_CONSTANTS.LOGISTICS.BASE_AUTHORITY 
        + garrisonBonus 
        - distancePenalty 
        - alienationPenalty 
        - overextensionDrag;

      // Dogma: ANCESTOR_CULT bonus (+20% Cohesion on frontier provinces)
      if (faction.unlockedDogmas?.includes(DogmaId.ANCESTOR_CULT) && !isCapital && city.effectiveDistanceToCapital >= 2.5) {
        authority += 20;
      }

      // Ruler Trait: WEAK_RULER penalty (-10% Cohesion)
      if (faction.ruler?.mainTrait === 'WEAK_RULER') {
        authority -= 10;
      }

      // Cultural Tier Mechanics:
      // Tier 1: Wild Tribe penalty when expanding beyond 3 provinces (-12 authority per excess province)
      const factionCityCount = Array.from(cities.values()).filter(c => c.factionId === faction.id).length;
      if ((!faction.tier || faction.tier === FactionTier.TRIBE) && factionCityCount > 3) {
        authority -= (factionCityCount - 3) * 12;
      }

      // Tier 2: Chiefdom reduces distance penalty by 50%
      if (faction.tier === FactionTier.CHIEFDOM && !isCapital) {
        authority += distancePenalty * 0.5;
      }

      // Tier 3: Early State mitigates overextension drag by 35%
      if (faction.tier === FactionTier.EARLY_STATE) {
        authority += overextensionDrag * 0.35;
      }

      // Tier 4: Great Empire gains massive imperial cohesion boost (+25%)
      if (faction.tier === FactionTier.EMPIRE) {
        authority += 25;
      }

      // Capital Luxuries (Столичные Блага):
      // Rare luxuries (Incense, Cattle) connected via supply lines grant +15% Cohesion globally
      if (faction.hasCapitalLuxury) {
        authority += 15;
      }

      const province = city.provinceId ? provinces.get(city.provinceId) : null;

      // Supply Line Status (Линии снабжения):
      // Если путь заблокирован: скорость падения сплоченности/власти в ней утраивается (3x)
      if (province?.isCutOffFromSupply && !isCapital) {
        const decay = Math.max(14, GAME_CONSTANTS.LOGISTICS.BASE_AUTHORITY - authority);
        authority = Math.max(0, GAME_CONSTANTS.LOGISTICS.BASE_AUTHORITY - decay * 3);
        authority = Math.min(30, authority); // Cut-off cities cannot maintain high authority
      }

      // Refuge Status (Убежище):
      // Провинции, отрезанные от столицы горами: базовая сплоченность падает на 10% быстрее
      if (province?.isRefuge && !isCapital) {
        authority -= Math.round(authority * 0.10 + 6);
      }

      if (isCapital) {
        authority = Math.max(60, authority);
      }

      city.authority = Math.max(0, Math.min(100, Math.round(authority)));

      // Determine Unrest Stage
      const oldStage = city.unrestStage;
      let newStage: UnrestStage;
      if (city.authority >= 70) {
        newStage = UnrestStage.INTEGRATED;
      } else if (city.authority >= 40) {
        newStage = UnrestStage.EROSION;
      } else if (city.authority >= 15) {
        newStage = UnrestStage.AUTONOMY_DEMAND;
      } else {
        newStage = UnrestStage.SECESSION_CRISIS;
      }

      city.unrestStage = newStage;

      // Sync with province
      if (province) {
        province.authority = city.authority;
        province.unrestStage = newStage;
      }

      // Emit event on stage escalation towards crisis
      if (newStage !== oldStage && (newStage === UnrestStage.AUTONOMY_DEMAND || newStage === UnrestStage.SECESSION_CRISIS)) {
        EventBus.emit('UNREST_ESCALATED', {
          cityName: city.name,
          provinceName: province ? province.name : city.name,
          stage: newStage,
          authority: city.authority,
          factionName: faction.name,
          turn: currentTurn
        });
      }
    }
  }
}
