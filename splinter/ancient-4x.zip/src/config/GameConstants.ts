// Game balance constants and configuration

export const GAME_CONSTANTS = {
  MAP: {
    WIDTH: 60,                           // 60 columns Earth world map
    HEIGHT: 40,                          // 40 rows
    HEX_RADIUS: 24,                      // Pixels radius of pointy hex
    SEED: 98765,                         // Фиксированный детерминированный сид генератора
    BASE_SCALE: 0.9,
    MIN_SCALE: 0.25,
    MAX_SCALE: 2.5
  },

  LOGISTICS: {
    RIVER_COST_FACTOR: 0.35,             // Moving/communicating along river is fast
    ROAD_COST_FACTOR: 0.5,               // Roads halve travel cost
    ALPHA_DISTANCE_BURDEN: 0.08,         // How fast distance erodes imperial power
    BETA_OVEREXTENSION_BURDEN: 0.12,     // Overextension per additional city
    BASE_AUTHORITY: 90,                  // Base authority in core capital
    GARRISON_AUTHORITY_BONUS: 25,        // Extra authority from garrison
    CULTURAL_ALIENATION_PENALTY: 35      // Authority penalty if culture diverges
  },

  CULTURE: {
    DRIFT_ACCUMULATION_THRESHOLD: 100,   // Divergence threshold
    SYNCRETISM_TRIBAL_DRIFT: 20,         // Drift bump upon settling among tribes
    BASE_DRIFT_PER_TURN: 3.5,            // Natural drift per turn when isolated
    CORE_REPRESSION_POWER: 4.0           // Cultural pressure from strong nearby capital
  },

  SUPPLY: {
    BASE_RADIUS: 4,                      // Hex distance from city / friendly territory
    ATTRITION_PER_TURN: 20,              // Supply loss when cut off
    STARVATION_HP_LOSS: 25               // HP loss per turn when supply == 0
  },

  UNREST: {
    AUTONOMY_TAX_LOSS: 0.30,             // In Erosion stage
    CRISIS_SECESSION_CHANCE: 0.40        // Probability of secession trigger per turn in Stage IV
  },

  AI: {
    FORCED_EXPANSION_CHANCE: 0.95,       // AI MUST claim an affordable adjacent empty province with this probability
    MAX_OVEREXTENSION: 120,              // Soft cap so the AI does not collapse itself through secession spirals
    MIGRATION_GRAIN_COST: 30,            // Grain spent to launch a Horde when boxed in by water / mountains
    MIGRATION_CULTURE_COST: 10,          // Culture Points spent to launch a Horde
    MIGRATION_SEARCH_DEPTH: 60           // Max hexes a migrating Horde will search for vacant land
  },

  WORLD: {
    SPAWN_INTERVAL_TURNS: 50,            // Dynamic World Spawner check cadence
    EMPTY_LAND_THRESHOLD: 0.40,          // Spawn new nations if more than 40% of land is vacant
    MAX_SPAWN_PER_EVENT: 4,
    STARTING_REGIONS: 3,                 // Provinces granted to each spawned nation
    STARTING_GOLD: 150,
    STARTING_GRAIN: 120,
    STARTING_CULTURE_POINTS: 40
  },

  WONDERS: {
    BUILD_TURNS: 5                       // Turns required to complete a Great Wonder
  },

  LANGUAGE: {
    MILESTONES: [25, 50, 75, 100]        // Divergence % at which the Chronicles report linguistic drift
  }
};
