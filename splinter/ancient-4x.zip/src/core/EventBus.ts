// Typed event bus for simulation events and UI notifications

export type GameEventType =
  | 'CULTURE_DIVERGED'
  | 'UNREST_ESCALATED'
  | 'SECESSION_TRIGGERED'
  | 'PLAYER_SPLIT_CHOICE'
  | 'CITY_FOUNDED'
  | 'UNIT_DIED'
  | 'SUCCESSION_CRISIS'
  | 'RULER_DIED'
  | 'WARLORD_REVOLT'
  | 'GAME_MODE_CHANGED'
  | 'DIPLOMACY_UPDATED'
  | 'AGE_TRANSITIONED'
  | 'GLOBAL_CRISIS_STARTED'
  | 'GLOBAL_CRISIS_ENDED'
  | 'MIGRATION_STARTED'
  | 'MIGRATION_SETTLED'
  | 'DOGMA_UNLOCKED'
  | 'CIVIL_WAR_TRIGGERED'
  | 'TRADE_DEAL_COMPLETED'
  | 'FACTION_EVOLVED'
  | 'PROVINCE_ANNEXED'
  | 'OUTPOST_BUILT'
  | 'TURN_CHANGED'
  | 'CHRONICLE_ADDED'
  | 'SUB_CULTURE_CREATED'
  | 'UNIT_RECRUITED'
  | 'VICTORY_ACHIEVED'
  | 'WARLORD_REVOLTED'
  | 'WONDER_COMPLETED'
  | 'LANGUAGE_TECH_UNLOCKED'
  | 'UNIQUE_CULTURE_FORMED'
  | 'TECHNOLOGY_RESEARCHED'
  | 'QUEST_TRIGGERED'
  | 'CAPITAL_LUXURY_CHANGED'
  | 'NATIONS_SPAWNED'
  | 'STATE_CHANGED';

export type EventCallback = (payload: any) => void;

export class EventBus {
  private static listeners: Map<GameEventType, EventCallback[]> = new Map();

  static on(event: GameEventType, callback: EventCallback): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(callback);
  }

  static off(event: GameEventType, callback: EventCallback): void {
    const list = this.listeners.get(event);
    if (!list) return;
    this.listeners.set(event, list.filter(cb => cb !== callback));
  }

  static emit(event: GameEventType, payload?: any): void {
    const list = this.listeners.get(event);
    if (!list) return;
    for (const callback of list) {
      try {
        callback(payload);
      } catch (err) {
        console.error(`Error in event listener for ${event}:`, err);
      }
    }
  }

  static clear(): void {
    this.listeners.clear();
  }
}
