import { HexTile, Faction, Culture, City, Unit, MapOverlayMode, UnitType, UnrestStage, Province, BiomeType, GameMode, StarterCultureChoice, DiplomaticStatus, HistoricalAge, GlobalCrisis, DogmaId, ResourceStockpile, ResourceType, FactionTier, PoliticalRegime, EdictId, VictoryType, NationType, RulerTrait } from '../entities/Types.ts';
import { HexCoord } from '../map/HexCoord.ts';
import { MapGenerator, GeneratedWorld } from '../map/MapGenerator.ts';
import { CultureSystem } from '../simulation/CultureSystem.ts';
import { LogisticsSystem } from '../simulation/LogisticsSystem.ts';
import { SecessionSystem } from '../simulation/SecessionSystem.ts';
import { SupplySystem } from '../simulation/SupplySystem.ts';
import { OpportunistAI } from '../ai/OpportunistAI.ts';
import { RulerSystem } from '../simulation/RulerSystem.ts';
import { WarlordSystem } from '../simulation/WarlordSystem.ts';
import { LanguageSystem } from '../simulation/LanguageSystem.ts';
import { ResearchSystem } from '../simulation/ResearchSystem.ts';
import { CombatSystem } from '../simulation/CombatSystem.ts';
import { EconomySystem } from '../simulation/EconomySystem.ts';
import { NameGenerator, PhoneticFlavor } from '../utils/NameGenerator.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';
import { EventBus } from './EventBus.ts';
import { SaveManager } from './SaveManager.ts';
import { QuestEvent, QuestSystem } from '../simulation/QuestSystem.ts';

export interface SecessionModalData {
  oldFaction: Faction;
  newFaction: Faction;
  city: City;
  leaderName: string;
}

export class GameState {
  mode: GameMode = 'START_MENU';
  selectedStarter: StarterCultureChoice = 'RIVER_FARMERS';

  age: HistoricalAge = HistoricalAge.STONE_TOOLS;
  currentCrisis: GlobalCrisis | null = null;

  currentTurn: number = 1;
  tiles: Map<string, HexTile> = new Map();
  provinces: Map<string, Province> = new Map();
  factions: Map<string, Faction> = new Map();
  cultures: Map<string, Culture> = new Map();
  cities: Map<string, City> = new Map();
  units: Map<string, Unit> = new Map();

  selectedHexKey: string | null = null;
  selectedUnitId: string | null = null;
  selectedCityId: string | null = null;
  overlayMode: MapOverlayMode = MapOverlayMode.POLITICAL;

  activeSecessionModal: SecessionModalData | null = null;
  eventLogs: { turn: number; text: string; type: string }[] = [];
  chroniclesOfAges: { turn: number; year: string; text: string; type: string }[] = [];
  victoryState: { won: boolean; type: VictoryType; text: string } = { won: false, type: 'NONE', text: '' };
  activeQuest: QuestEvent | null = null;
  nextQuestTurn: number = 15;
  questCounter: number = 0;

  // World Spawner bookkeeping (persisted)
  lastWorldSpawnCheckTurn: number = 0;

  // Transient UI/turn locks (NOT persisted)
  isTurnProcessing: boolean = false;   // true while endTurn() is running
  isInputLocked: boolean = false;      // true during the end-turn transition: map clicks & UI are disabled

  constructor() {
    this.initWorld(GAME_CONSTANTS.MAP.SEED, 'RIVER_FARMERS');
    this.setupEventListeners();
  }

  initWorld(seed: number = GAME_CONSTANTS.MAP.SEED, starterChoice: StarterCultureChoice = 'RIVER_FARMERS'): void {
    const generator = new MapGenerator(seed);
    const world: GeneratedWorld = generator.generate(undefined, undefined, starterChoice);

    this.tiles = world.tiles;
    this.provinces = world.provinces;
    this.factions = world.factions;
    this.cultures = world.cultures;
    this.cities = world.cities;
    this.units = world.units;
    this.currentTurn = 1;
    this.eventLogs = [];

    // Run initial supply lines & logistics calculation with provinces
    SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
    LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);

    const player = this.getPlayerFaction();
    const cult = player ? this.cultures.get(player.rootCultureId) : null;
    if (player) {
      player.sciencePoints = 20;
      player.unlockedTechs = [];
      player.regime = PoliticalRegime.TRIBAL_COUNCIL;
      player.activeEdicts = [];
      player.taxRate = 'NORMAL';
      if (cult) {
        LanguageSystem.initLanguageForCulture(cult);
      }
    }

    // Initialize Province infrastructure & populations
    for (const prov of this.provinces.values()) {
      prov.population = Math.round(15 + prov.fertility * 6);
      prov.hasFarm = false;
      prov.hasMine = false;
      prov.hasMarket = false;
      prov.hasWonder = false;
      prov.isEpidemic = false;
    }

    this.chroniclesOfAges = [];
    this.addChronicle(
      `Хроники Веков начались! Основана держава «${player?.name || 'Империя'}» [${cult?.name || 'Культура'}]. На карте 6 великих цивилизаций Бронзового Века.`,
      'info'
    );
  }

  startNewGame(choice: StarterCultureChoice): void {
    this.selectedStarter = choice;
    // Детерминированный сид 12345 для стабильности формы континентов и расположения провинций
    this.initWorld(GAME_CONSTANTS.MAP.SEED, choice);
    this.mode = 'PLAYING';
    EventBus.emit('GAME_MODE_CHANGED', { mode: this.mode });
    EventBus.emit('TURN_CHANGED', { turn: this.currentTurn });
  }

  toJSON(): any {
    return {
      version: 1,
      currentTurn: this.currentTurn,
      age: this.age,
      currentCrisis: this.currentCrisis,
      selectedStarter: this.selectedStarter,
      mode: this.mode,
      overlayMode: this.overlayMode,
      eventLogs: this.eventLogs,
      chroniclesOfAges: this.chroniclesOfAges,
      victoryState: this.victoryState,
      factions: Array.from(this.factions.entries()),
      provinces: Array.from(this.provinces.entries()),
      cities: Array.from(this.cities.entries()),
      units: Array.from(this.units.entries()),
      cultures: Array.from(this.cultures.entries()),
      tiles: Array.from(this.tiles.entries()),
      timestamp: Date.now()
    };
  }

  fromJSON(data: any): boolean {
    return SaveManager.loadGame(this);
  }

  setGameMode(newMode: GameMode): void {
    this.mode = newMode;
    EventBus.emit('GAME_MODE_CHANGED', { mode: newMode });
  }

  declareWar(targetFactionId: string): boolean {
    const player = this.getPlayerFaction();
    const target = this.factions.get(targetFactionId);
    if (!player || !target || player.id === target.id) return false;

    if (!player.atWarWith.includes(target.id)) player.atWarWith.push(target.id);
    if (!target.atWarWith.includes(player.id)) target.atWarWith.push(player.id);

    player.diplomacy[target.id] = {
      status: DiplomaticStatus.WAR,
      opinion: -85,
      pactTurnsLeft: 0
    };
    target.diplomacy[player.id] = {
      status: DiplomaticStatus.WAR,
      opinion: -85,
      pactTurnsLeft: 0
    };

    // Reset border cultural pressure between factions
    for (const city of this.cities.values()) {
      if (city.factionId === player.id || city.factionId === target.id) {
        city.accumulatedDrift = Math.max(0, city.accumulatedDrift - 30);
      }
    }

    this.addLog(`⚔️ ВОЙНА ОБЪЯВЛЕНА! Держава «${player.name}» начала войну против «${target.name}»! Пограничное культурное давление сброшено.`, 'critical');
    EventBus.emit('DIPLOMACY_UPDATED', { playerFaction: player, targetFaction: target });
    return true;
  }

  offerNonAggressionPact(targetFactionId: string): { success: boolean; message: string } {
    const player = this.getPlayerFaction();
    const target = this.factions.get(targetFactionId);
    if (!player || !target || player.id === target.id) {
      return { success: false, message: 'Неверная фракция для дипломатии.' };
    }

    const rel = target.diplomacy[player.id] || { opinion: 0 };
    if (rel.opinion < 0) {
      this.addLog(`Послы вернулись ни с чем: правитель «${target.name}» отверг пакт о ненападении (отношение: ${rel.opinion}).`, 'warning');
      return { success: false, message: `Правитель ${target.name} отверг предложение (враждебное отношение: ${rel.opinion}).` };
    }

    player.diplomacy[target.id] = {
      status: DiplomaticStatus.NON_AGGRESSION,
      opinion: Math.min(100, rel.opinion + 25),
      pactTurnsLeft: 15
    };
    target.diplomacy[player.id] = {
      status: DiplomaticStatus.NON_AGGRESSION,
      opinion: Math.min(100, rel.opinion + 25),
      pactTurnsLeft: 15
    };

    player.atWarWith = player.atWarWith.filter(id => id !== target.id);
    target.atWarWith = target.atWarWith.filter(id => id !== player.id);

    this.addLog(`🤝 ПАКТ ЗАКЛЮЧЕН! «${player.name}» и «${target.name}» подписали пакт о ненападении на 15 ходов. Пограничный раскол заморожен!`, 'info');
    EventBus.emit('DIPLOMACY_UPDATED', { playerFaction: player, targetFaction: target });
    return { success: true, message: `Пакт о ненападении с ${target.name} успешно заключен на 15 ходов!` };
  }

  getPlayerFaction(): Faction | undefined {
    return Array.from(this.factions.values()).find(f => f.isPlayer);
  }

  private setupEventListeners(): void {
    EventBus.on('CULTURE_DIVERGED', (data: any) => {
      this.addLog(
        `Культурный раскол в провинции ${data.provinceName || data.cityName}! Народ обособился и создал культуру «${data.newCultureName}»!`,
        'warning'
      );
    });

    EventBus.on('UNREST_ESCALATED', (data: any) => {
      this.addLog(
        `Кризис власти в регионе ${data.provinceName || data.cityName}: статус (${data.stage})! Авторитет упал до ${data.authority}%.`,
        'danger'
      );
    });

    EventBus.on('SECESSION_TRIGGERED', (data: any) => {
      this.addLog(
        `РАСКОЛ ИМПЕРИИ! Провинция ${data.provinceName || data.cityName} провозгласила независимость! Образовано ${data.newFactionName} под знаменем [${data.cultureName}].`,
        'critical'
      );
    });

    EventBus.on('PLAYER_SPLIT_CHOICE', (data: any) => {
      this.activeSecessionModal = data;
    });

    EventBus.on('UNIT_DIED', (data: any) => {
      this.addLog(`Гибель отряда: ${data.unitName}. Причина: ${data.reason}.`, 'danger');
    });

    EventBus.on('SUCCESSION_CRISIS', (data: any) => {
      this.addLog(data.msg, 'critical');
    });

    EventBus.on('RULER_DIED', (data: any) => {
      this.addLog(`Царь скончался: ${data.oldRulerName} (${data.factionName}) отошел к предкам. Причина: ${data.cause}.`, 'warning');
    });

    EventBus.on('WARLORD_REVOLT', (data: any) => {
      this.addLog(data.msg, 'critical');
    });
  }

  addLog(text: string, type: string = 'info'): void {
    this.eventLogs.unshift({
      turn: this.currentTurn,
      text,
      type
    });
    if (this.eventLogs.length > 35) {
      this.eventLogs.pop();
    }
  }

  addChronicle(text: string, type: string = 'info'): void {
    const yearVal = Math.max(1000, 2400 - (this.currentTurn - 1) * 25);
    const yearStr = `${Math.abs(yearVal)} до н.э.`;
    this.chroniclesOfAges.unshift({
      turn: this.currentTurn,
      year: yearStr,
      text,
      type
    });
    if (this.chroniclesOfAges.length > 60) {
      this.chroniclesOfAges.pop();
    }
    this.addLog(text, type);
    try {
      localStorage.setItem('ancient4x_chronicles_of_ages', JSON.stringify(this.chroniclesOfAges));
    } catch (e) {}
    EventBus.emit('CHRONICLE_ADDED', { text, turn: this.currentTurn, year: yearStr, type });
  }

  // End Player Turn and advance simulation (re-entrancy safe)
  endTurn(): void {
    if (this.isTurnProcessing) return;
    this.isTurnProcessing = true;
    try {
      this.processTurn();
    } finally {
      this.isTurnProcessing = false;
    }
  }

  private processTurn(): void {
    // 1. Collect player resources (with dogma and crisis modifiers)
    const player = this.getPlayerFaction();
    if (player) {
      const playerCities = Array.from(this.cities.values()).filter(c => c.factionId === player.id);
      const isAncestorCult = player.unlockedDogmas.includes(DogmaId.ANCESTOR_CULT);
      const isDrought = this.currentCrisis && this.currentCrisis.id === 'great_drought';

      for (const city of playerCities) {
        const prov = city.provinceId ? this.provinces.get(city.provinceId) : null;
        if (prov?.isCutOffFromSupply) {
          // Caravans cannot reach capital; cut off from imperial supply and treasury
          continue;
        }

        let taxEfficiency = city.authority / 100;
        if (city.unrestStage === UnrestStage.EROSION) taxEfficiency *= 0.7;
        if (city.unrestStage === UnrestStage.AUTONOMY_DEMAND) taxEfficiency *= 0.2;
        if (city.unrestStage === UnrestStage.SECESSION_CRISIS) taxEfficiency = 0;
        if (isAncestorCult) taxEfficiency *= 0.85; // -15% taxes from Ancestor Cult dogma

        const grainModifier = isDrought ? 0.5 : 1.0; // -50% food during Great Drought crisis

        player.gold += Math.round(city.population * 2 * taxEfficiency);
        player.grain += Math.round(city.population * 2.5 * grainModifier);
      }
    }

    // 2. Run simulation updates
    this.currentTurn++;

    // 2.1. Check Historical Age Transitions & Global Crises
    this.updateAgeAndCrises();

    // 2.2. Rulers Aging, Legitimacy and Succession Crises / Civil War
    RulerSystem.update(this.factions, this.cities, this.provinces, this.units, this.tiles, this.currentTurn);

    // 2.3. Culture drift on Province Level
    CultureSystem.update(this.cities, this.factions, this.cultures, this.tiles, this.provinces, this.currentTurn);

    // 2.4. Supply lines check & logistics / authority decay on Province Level
    SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
    LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);

    // 2.5. Secession crises: entire provinces secede!
    SecessionSystem.update(this.cities, this.factions, this.cultures, this.units, this.tiles, this.provinces, this.currentTurn);

    // 2.6. Frontier Army Loyalty and Warlord Revolts (Диадохи)
    WarlordSystem.update(this.units, this.factions, this.cities, this.tiles, this.currentTurn);

    // 2.7. Culture Points & Resource harvesting for all factions
    this.harvestFactionResourcesAndCulture();

    // 2.8. AI Factions Turns & AI Autonomous Migration
    for (const faction of Array.from(this.factions.values())) {
      if (!faction.isPlayer) {
        this.processAIMigration(faction);
        OpportunistAI.executeTurn(faction, this);
      }
    }

    // 2.8.5. Module 4: Barbarian Hordes spawn (5% in wild lands), movement, raiding and supply blocking
    this.processBarbarianTurn();

    // 2.9. Supply lines check & attrition
    SupplySystem.update(this.units, this.cities, this.tiles, this.factions);

    // 2.10. Diplomacy duration countdown and opinion normalization
    for (const fac of this.factions.values()) {
      for (const targetId in fac.diplomacy) {
        const rel = fac.diplomacy[targetId];
        if (rel.status === DiplomaticStatus.NON_AGGRESSION && rel.pactTurnsLeft > 0) {
          rel.pactTurnsLeft--;
          if (rel.pactTurnsLeft === 0) {
            rel.status = DiplomaticStatus.PEACE;
            if (fac.isPlayer) {
              const target = this.factions.get(targetId);
              this.addLog(`Срок пакта о ненападении с державой «${target?.name || targetId}» истек. Отношения вернулись к нейтральному миру.`, 'warning');
            }
          }
        }
      }
    }

    // 2.11. Check Cultural Tier Evolution for player
    this.checkFactionEvolution();

    // 2.12. Module 5: Cultural Assimilation of Lower Tier AI Provinces bordering Player
    this.processTierAssimilation();

    // Tier 3 Perk: Passive frontier colonization check (every 7 turns)
    if (this.currentTurn % 7 === 0) {
      for (const faction of this.factions.values()) {
        if (faction.tier && faction.tier >= FactionTier.EARLY_STATE) {
          const expandables = this.getExpandableProvinces(faction.id);
          if (expandables.length > 0 && faction.grain >= 50) {
            const targetProv = expandables[0];
            if (faction.isPlayer) {
              this.annexProvince(targetProv.id);
              this.addLog(`🌿 ПАССИВНОЕ РАСШИРЕНИЕ: Поселенцы цивилизации мирно освоили провинцию «${targetProv.name}»!`, 'info');
            } else {
              targetProv.ownerFactionId = faction.id;
              targetProv.dominantCultureId = faction.rootCultureId;
              targetProv.authority = 80;
              for (const hk of targetProv.hexKeys) {
                const t = this.tiles.get(hk);
                if (t) t.ownerFactionId = faction.id;
              }
            }
          }
        }
      }
    }

    // 2.13. Modern Systems: Economy, Population, Markets & Wonder Construction
    EconomySystem.updateEconomy(this.provinces, this.factions, this.cities, this.currentTurn);

    // 2.14. Epidemics: 3% outbreak chance and contagion along supply lines
    EconomySystem.updateEpidemics(this.provinces, this.tiles, this.currentTurn, (msg, type) => this.addChronicle(msg, type));

    // 2.15. Sub-culture drift & language mutation
    LanguageSystem.updateSubCultureDrift(this.cultures, this.factions, this.currentTurn, (msg, type) => this.addChronicle(msg, type), this.provinces, this.tiles);

    // 2.16. Generate Science / Research points for player
    if (player) {
      const citiesCount = Array.from(this.cities.values()).filter(c => c.factionId === player.id).length;
      const cult = this.cultures.get(player.rootCultureId);
      const hasAlphabet = !!cult?.language?.features.includes('ALPHABET');
      const sciGain = ResearchSystem.calculateTurnScience(player, citiesCount, hasAlphabet);
      player.sciencePoints = (player.sciencePoints ?? 0) + sciGain;
    }

    // 2.17. Check Victory Conditions (Military, Scientific, Cultural)
    this.checkVictoryConditions();

    // Refresh moves for all player units (Hordes get 7 moves if NOMADIC_LIFESTYLE)
    const hasNomadicDogma = player?.unlockedDogmas.includes(DogmaId.NOMADIC_LIFESTYLE);
    for (const unit of this.units.values()) {
      if (unit.type === UnitType.HORDE && unit.factionId === player?.id && hasNomadicDogma) {
        unit.maxMoves = 7;
      }
      unit.movesLeft = unit.maxMoves;
    }

    // 2.18. Historical Quests & Dilemmas System (every 15-20 turns)
    if (this.currentTurn >= this.nextQuestTurn && !this.activeQuest) {
      this.activeQuest = QuestSystem.getNextQuest(this, this.questCounter++);
      this.nextQuestTurn = this.currentTurn + 15 + Math.floor(Math.random() * 6);
      EventBus.emit('QUEST_TRIGGERED', this.activeQuest);
    }

    // 2.19. Dynamic World Spawner: every 50 turns, if > 40% of the land is still vacant, spawn new medieval nations
    if (this.currentTurn % GAME_CONSTANTS.WORLD.SPAWN_INTERVAL_TURNS === 0) {
      this.checkWorldSpawner();
    }

    EventBus.emit('TURN_CHANGED', { turn: this.currentTurn });
    // Autosave after turn completion
    SaveManager.saveGame(this);
  }

  // --- Historical Quests Resolution ---
  resolveQuest(choiceId: string): boolean {
    if (!this.activeQuest) return false;
    const choice = this.activeQuest.choices.find(c => c.id === choiceId);
    if (!choice) return false;
    if (!choice.canAfford(this)) return false;

    const resultMsg = choice.apply(this);
    this.addChronicle(resultMsg, 'info');
    this.addLog(resultMsg, 'info');
    this.activeQuest = null;
    EventBus.emit('STATE_CHANGED');
    return true;
  }

  // --- Sub-Culture Splinter Creation ---
  triggerSplinter(coord: HexCoord): boolean {
    const tile = this.tiles.get(coord.key);
    if (!tile || !tile.provinceId) return false;

    const prov = this.provinces.get(tile.provinceId);
    if (!prov || !prov.ownerFactionId) return false;

    const oldFaction = this.factions.get(prov.ownerFactionId);
    if (!oldFaction) return false;

    const parentCulture = this.cultures.get(prov.dominantCultureId || oldFaction.rootCultureId);
    if (!parentCulture) return false;

    // 1. Create Sub-Culture
    const cleanProvName = prov.name.split(' ')[0];
    const subCultureId = `culture_sub_${parentCulture.id}_${this.currentTurn}_${cleanProvName}`;
    const subCulture: Culture = {
      id: subCultureId,
      name: `${parentCulture.name} (${cleanProvName})`,
      parentId: parentCulture.id,
      parentCultureId: parentCulture.id,
      divergenceTurn: this.currentTurn,
      color: parentCulture.color,
      traits: [...parentCulture.traits],
      isSubCulture: true,
      drift: 0,
      isUniqueCulture: false,
      language: {
        name: `${parentCulture.name}-${cleanProvName} (диалект)`,
        writingLevel: parentCulture.language?.writingLevel || 1,
        features: [...(parentCulture.language?.features || ['WRITING'])],
        divergence: 0
      }
    };
    this.cultures.set(subCultureId, subCulture);

    // 2. Create Breakaway Sub-Culture Faction
    const newFactionId = `faction_sub_${oldFaction.id}_${this.currentTurn}_${cleanProvName}`;
    const leaderName = NameGenerator.generateLeaderName();
    const newFaction: Faction = {
      id: newFactionId,
      name: `${cleanProvName}ская Держава`,
      color: oldFaction.color,
      capitalCityId: prov.cityId,
      rootCultureId: subCultureId,
      isPlayer: false,
      isBreakaway: true,
      gold: 80,
      grain: 100,
      overextension: 5,
      atWarWith: [],
      ruler: {
        name: leaderName,
        title: 'Правитель-Наместник',
        age: 30,
        maxAge: 65,
        legitimacy: 85,
        traits: ['Основатель ветви', 'Миролюбивый'],
        mainTrait: 'BUILDER'
      },
      isInterregnum: false,
      interregnumTurnsLeft: 0,
      diplomacy: {
        [oldFaction.id]: {
          status: DiplomaticStatus.PEACE,
          opinion: 45,
          pactTurnsLeft: 12
        }
      },
      culturePoints: 20,
      unlockedDogmas: [...oldFaction.unlockedDogmas],
      resources: { copper: 1, tin: 0, cattle: 2, incense: 1 },
      tier: FactionTier.TRIBE,
      outposts: [],
      parentFactionId: oldFaction.id,
      isSubCultureFaction: true
    };

    if (!oldFaction.diplomacy) oldFaction.diplomacy = {};
    oldFaction.diplomacy[newFactionId] = {
      status: DiplomaticStatus.PEACE,
      opinion: 45,
      pactTurnsLeft: 12
    };

    this.factions.set(newFactionId, newFaction);

    // 3. Transfer Province & Hexes
    prov.ownerFactionId = newFactionId;
    prov.dominantCultureId = subCultureId;
    prov.authority = 85;
    for (const hKey of prov.hexKeys) {
      const hTile = this.tiles.get(hKey);
      if (hTile) hTile.ownerFactionId = newFactionId;
    }

    if (prov.cityId) {
      const city = this.cities.get(prov.cityId);
      if (city) {
        city.factionId = newFactionId;
        city.dominantCultureId = subCultureId;
        city.authority = 85;
      }
    }

    this.addChronicle(
      `🏛️ РОЖДЕНИЕ СУБ-КУЛЬТУРЫ: В провинции «${prov.name}» образовалась дочерняя суб-культура «${subCulture.name}»! Сохраняет мир и традиции с метрополией (Drift: 0%).`,
      'info'
    );

    EventBus.emit('SUB_CULTURE_CREATED', { faction: newFaction, culture: subCulture, province: prov });
    return true;
  }

  // --- Economy: Province Buildings Construction ---
  buildProvinceStructure(provinceId: string, structureType: 'farm' | 'mine' | 'market'): boolean {
    const player = this.getPlayerFaction();
    if (!player) return false;

    const prov = this.provinces.get(provinceId);
    if (!prov || prov.ownerFactionId !== player.id) return false;

    const costs = { farm: 30, mine: 40, market: 35 };
    const cost = costs[structureType];

    if (player.gold < cost) {
      this.addLog(`Недостаточно золота для постройки! Нужно 💰 ${cost}.`, 'warning');
      return false;
    }

    if (structureType === 'farm') {
      if (prov.hasFarm) return false;
      prov.hasFarm = true;
      player.gold -= cost;
      this.addLog(`🌾 В провинции «${prov.name}» построена Ферма! (+2 еды, ускоренный демографический рост)`, 'info');
    } else if (structureType === 'mine') {
      if (prov.hasMine) return false;
      prov.hasMine = true;
      player.gold -= cost;
      this.addLog(`⛏️ В провинции «${prov.name}» заложена Шахта! (+2 к производству и стратегическим запасам)`, 'info');
    } else if (structureType === 'market') {
      if (prov.hasMarket) return false;
      prov.hasMarket = true;
      player.gold -= cost;
      this.addLog(`💰 В провинции «${prov.name}» открыт Рынок! (+5 золота каждый ход)`, 'info');
    }

    return true;
  }

  // --- Wonders of the World ---
  buildWonder(provinceId: string): boolean {
    const player = this.getPlayerFaction();
    if (!player) return false;

    const prov = this.provinces.get(provinceId);
    if (!prov || prov.ownerFactionId !== player.id) return false;

    if (player.tier < FactionTier.EARLY_STATE) {
      this.addLog('Строительство Чудес Света доступно только с Тира «Цивилизация»!', 'warning');
      return false;
    }

    if (prov.hasWonder || (prov.wonderTurnsRemaining !== undefined && prov.wonderTurnsRemaining > 0)) {
      this.addLog('В этой провинции уже строится или возведено Чудо Света!', 'warning');
      return false;
    }

    const goldCost = 120;
    const cultCost = 50;

    if (player.gold < goldCost || player.culturePoints < cultCost) {
      this.addLog(`Недостаточно ресурсов! Нужно 💰 ${goldCost} и 📜 ${cultCost} Очков Культуры.`, 'warning');
      return false;
    }

    player.gold -= goldCost;
    player.culturePoints -= cultCost;

    prov.wonderName = EconomySystem.getWonderNameForAge(this.age);
    prov.wonderTurnsRemaining = GAME_CONSTANTS.WONDERS.BUILD_TURNS;

    this.addChronicle(
      `🏛️ ВЕЛИКАЯ СТРОЙКА: В провинции «${prov.name}» начато возведение Чуда Света «${prov.wonderName}»! По завершении даст +30% к Cohesion в радиусе 5 гексов.`,
      'critical'
    );

    return true;
  }

  // --- Military Recruitment ---
  recruitUnit(provinceId: string, unitType: UnitType): boolean {
    const player = this.getPlayerFaction();
    if (!player) return false;

    const prov = this.provinces.get(provinceId);
    if (!prov || prov.ownerFactionId !== player.id) return false;

    const cost = CombatSystem.getRecruitmentCost(unitType);
    if (player.gold < cost.gold || player.grain < cost.grain) {
      this.addLog(`Недостаточно ресурсов для найма! Требуется 💰 ${cost.gold}, 🌾 ${cost.grain}`, 'warning');
      return false;
    }

    let spawnCoord: HexCoord | null = null;
    for (const hKey of prov.hexKeys) {
      const tile = this.tiles.get(hKey);
      if (tile && !tile.unitId && tile.biome !== BiomeType.OCEAN) {
        spawnCoord = new HexCoord(tile.q, tile.r);
        break;
      }
    }

    if (!spawnCoord) {
      this.addLog('Все гексы провинции заняты отрядами!', 'warning');
      return false;
    }

    player.gold -= cost.gold;
    player.grain -= cost.grain;

    const warlordName = NameGenerator.generateLeaderName();
    const unitId = `unit_${player.id}_${this.currentTurn}_${Date.now() % 1000}`;
    const newUnit: Unit = {
      id: unitId,
      name: `${unitType} ${warlordName}`,
      type: unitType,
      factionId: player.id,
      q: spawnCoord.q,
      r: spawnCoord.r,
      hp: 100,
      maxHp: 100,
      movesLeft: 3,
      maxMoves: unitType === UnitType.HEAVY_CAVALRY || unitType === UnitType.CHARIOT ? 4 : (unitType === UnitType.TANK ? 5 : 3),
      combatStrength: CombatSystem.getBaseStrength(unitType),
      supply: 100,
      isGarrisoned: false,
      loyalty: 75 + Math.floor(Math.random() * 20),
      generalName: warlordName
    };

    this.units.set(unitId, newUnit);
    const spawnTile = this.tiles.get(spawnCoord.key);
    if (spawnTile) spawnTile.unitId = unitId;

    this.addLog(`⚔️ Отряд «${newUnit.name}» успешно сформирован в провинции «${prov.name}»!`, 'info');
    EventBus.emit('UNIT_RECRUITED', { unit: newUnit });
    return true;
  }

  // --- Language Advancements ---
  unlockLanguageTech(techId: string): { success: boolean; message: string } {
    const player = this.getPlayerFaction();
    if (!player) return { success: false, message: 'Игрок не найден' };
    const cult = this.cultures.get(player.rootCultureId);
    if (!cult) return { success: false, message: 'Культура не найдена' };

    return LanguageSystem.unlockLanguageTech(player, cult, techId, (msg, type) => this.addChronicle(msg, type));
  }

  // --- Research Techs ---
  unlockResearchTech(techId: string): { success: boolean; message: string; isVictory?: boolean } {
    const player = this.getPlayerFaction();
    if (!player) return { success: false, message: 'Игрок не найден' };

    return ResearchSystem.unlockTech(
      player,
      techId,
      this.age,
      (newAge) => {
        const oldAge = this.age;
        this.age = newAge;
        this.addChronicle(`🏛️ ПЕРЕХОД В НОВУЮ ЭПОХУ: Человечество вступило в «${newAge}»!`, 'critical');
        EventBus.emit('AGE_TRANSITIONED', { oldAge, newAge, turn: this.currentTurn });
      },
      (msg, type) => this.addChronicle(msg, type)
    );
  }

  // --- Taxes & Regimes ---
  setTaxRate(rate: 'LOW' | 'NORMAL' | 'HIGH'): void {
    const player = this.getPlayerFaction();
    if (player) player.taxRate = rate;
  }

  setPoliticalRegime(regime: PoliticalRegime): void {
    const player = this.getPlayerFaction();
    if (player) {
      player.regime = regime;
      this.addChronicle(`⚖️ ГОСУДАРСТВЕННАЯ РЕФОРМА: Принят новый политический строй: «${regime}»!`, 'info');
    }
  }

  // --- Victory Conditions ---
  checkVictoryConditions(): VictoryType {
    if (this.victoryState.won) return this.victoryState.type;

    const player = this.getPlayerFaction();
    if (!player) return 'NONE';

    // 1. Scientific Victory
    if (player.unlockedTechs?.includes('TECH_SPACE_COLONIZATION')) {
      this.victoryState = {
        won: true,
        type: 'SCIENTIFIC',
        text: '🚀 НАУЧНАЯ ПОБЕДА! Ваша цивилизация развернула Глобальную Квантовую Сеть и покорила космос, объединив все народы Земли.'
      };
      this.addChronicle(this.victoryState.text, 'critical');
      EventBus.emit('VICTORY_ACHIEVED', this.victoryState);
      return 'SCIENTIFIC';
    }

    // 2. Military Victory
    const otherFactions = Array.from(this.factions.values()).filter(f => f.id !== player.id && f.capitalCityId !== null);
    const nonBarbarianOthers = otherFactions.filter(f => f.id !== 'faction_barbarians');
    const playerCities = Array.from(this.cities.values()).filter(c => c.factionId === player.id);

    if (this.currentTurn > 8 && nonBarbarianOthers.length === 0 && playerCities.length >= 3) {
      this.victoryState = {
        won: true,
        type: 'MILITARY',
        text: '⚔️ ВОЕННАЯ ПОБЕДА! Все соперничающие державы сокрушены вашими непобедимыми армиями. Вы — единый гегемон Земли!'
      };
      this.addChronicle(this.victoryState.text, 'critical');
      EventBus.emit('VICTORY_ACHIEVED', this.victoryState);
      return 'MILITARY';
    }

    // 3. Cultural Victory
    const playerCulture = this.cultures.get(player.rootCultureId);
    if (playerCulture) {
      let totalWorldPop = 0;
      let playerCulturePop = 0;
      for (const prov of this.provinces.values()) {
        const pop = prov.population ?? 20;
        totalWorldPop += pop;
        if (prov.dominantCultureId === playerCulture.id) {
          playerCulturePop += pop;
        }
      }
      if (totalWorldPop > 0 && (playerCulturePop / totalWorldPop) >= 0.70 && this.currentTurn > 15) {
        this.victoryState = {
          won: true,
          type: 'CULTURAL',
          text: '📜 КУЛЬТУРНАЯ ПОБЕДА! Более 70% населения Земли говорят на вашем языке и исповедуют ваши традиции. Мир стал единой культурной семьей!'
        };
        this.addChronicle(this.victoryState.text, 'critical');
        EventBus.emit('VICTORY_ACHIEVED', this.victoryState);
        return 'CULTURAL';
      }
    }

    return 'NONE';
  }

  // --- Ages and Global Crises Logic ---
  private updateAgeAndCrises(): void {
    // Age Progression: 1-40 Tools, 41-80 Copper, 81+ Bronze Age
    if (this.currentTurn >= 81 && this.age !== HistoricalAge.BRONZE_AGE) {
      const oldAge = this.age;
      this.age = HistoricalAge.BRONZE_AGE;
      this.addLog('⚔️ НАСТУПИЛ БРОНЗОВЫЙ ВЕК! Для полного превосходства армий теперь необходимы Медь и Олово (дефицит дает -25% силы в бою)!', 'critical');
      EventBus.emit('AGE_TRANSITIONED', { oldAge, newAge: this.age, turn: this.currentTurn });
      this.triggerRandomCrisis();
    } else if (this.currentTurn >= 41 && this.age === HistoricalAge.STONE_TOOLS) {
      const oldAge = this.age;
      this.age = HistoricalAge.COPPER_AGE;
      this.addLog('🥉 НАСТУПИЛА ЭПОХА МЕДИ! Первые рудники и выплавка меди меняют баланс сил на Земле.', 'warning');
      EventBus.emit('AGE_TRANSITIONED', { oldAge, newAge: this.age, turn: this.currentTurn });
      this.triggerRandomCrisis();
    }

    // Progress active global crisis
    if (this.currentCrisis) {
      this.currentCrisis.turnsLeft--;

      // Global Crisis Cohesion hit: all cities lose authority
      for (const city of this.cities.values()) {
        city.authority = Math.max(5, city.authority - 2);
      }

      if (this.currentCrisis.turnsLeft <= 0) {
        const crisisName = this.currentCrisis.name;
        this.addLog(`☀️ Глобальный кризис «${crisisName}» миновал! Цивилизации древнего мира восстанавливают порядок.`, 'info');
        EventBus.emit('GLOBAL_CRISIS_ENDED', { crisisName, turn: this.currentTurn });
        this.currentCrisis = null;
      }
    }
  }

  triggerRandomCrisis(): void {
    const crises: GlobalCrisis[] = [
      {
        id: 'great_drought',
        name: 'Великая Засуха',
        description: 'Тысячелетняя засуха иссушает русла рек. Прирост урожая снижен вдвое, авторитет власти падает по всему миру!',
        turnsLeft: 10,
        totalTurns: 10,
        effect: '-50% прироста пищи, -25% сплоченности'
      },
      {
        id: 'nomadic_invasion',
        name: 'Нашествие Кочевников',
        description: 'Дикие степные и пустынные орды хлынули на границы древних царств, сметая пограничные заставы!',
        turnsLeft: 10,
        totalTurns: 10,
        effect: 'Агрессивные орды на рубежах, -25% сплоченности'
      },
      {
        id: 'bronze_collapse',
        name: 'Кризис Бронзового Века',
        description: 'Нарушение торговых путей олова и меди! Волнения охватили метрополии и колонии.',
        turnsLeft: 10,
        totalTurns: 10,
        effect: 'Падение Cohesion на 25%, бунты гарнизонов'
      }
    ];

    const crisis = crises[Math.floor(Math.random() * crises.length)];
    this.currentCrisis = crisis;

    // Apply immediate 25% Cohesion hit across all cities
    for (const city of this.cities.values()) {
      city.authority = Math.max(5, Math.round(city.authority * 0.75));
    }

    if (crisis.id === 'nomadic_invasion') {
      this.spawnBarbarianInvasionHordes();
    }

    this.addLog(`⚡ ГЛОБАЛЬНЫЙ КРИЗИС: «${crisis.name}»! ${crisis.description} (Длительность: 10 ходов).`, 'critical');
    EventBus.emit('GLOBAL_CRISIS_STARTED', { crisis, turn: this.currentTurn });
  }

  private spawnBarbarianInvasionHordes(): void {
    const spawnPoints = [
      { q: 44, r: 12 }, // Steppe
      { q: 26, r: 23 }, // Sahara frontier
      { q: 48, r: 12 }, // Central Asia
      { q: 38, r: 24 }  // Arabia
    ];

    let idx = 1;
    for (const pt of spawnPoints) {
      const tile = this.tiles.get(`${pt.q},${pt.r}`);
      if (tile && tile.biome !== BiomeType.OCEAN && !tile.unitId) {
        const hordeUnit: Unit = {
          id: `unit_barbarian_horde_${this.currentTurn}_${idx}`,
          name: `Орда Нашествия #${idx}`,
          type: UnitType.HORDE,
          factionId: 'faction_barbarians',
          q: pt.q,
          r: pt.r,
          hp: 100,
          maxHp: 100,
          movesLeft: 5,
          maxMoves: 5,
          combatStrength: 14,
          supply: 100,
          isGarrisoned: false,
          loyalty: 100,
          generalName: 'Вождь Нашествия'
        };
        tile.unitId = hordeUnit.id;
        this.units.set(hordeUnit.id, hordeUnit);
        idx++;
      }
    }
    this.addLog('⚠️ На окраинах мира замечены воинственные орды кочевников!', 'danger');
  }

  // --- Culture Points and Strategic Resource Harvesting ---
  private harvestFactionResourcesAndCulture(): void {
    for (const faction of this.factions.values()) {
      const ownedProvinces = Array.from(this.provinces.values()).filter(p => p.ownerFactionId === faction.id);

      // Линии снабжения: Провинции, отрезанные от снабжения, не могут отправлять караваны в столицу
      // Доход Очков Культуры и редких ресурсов от них падает до 0
      const suppliedProvinces = ownedProvinces.filter(p => !p.isCutOffFromSupply);

      // Base Culture Points: +3 per supplied controlled province
      let cp = suppliedProvinces.length * 3;
      if (faction.unlockedDogmas.includes(DogmaId.RIVER_PRIESTHOOD)) {
        const riverProvs = suppliedProvinces.filter(p => p.biome === BiomeType.RIVER_VALLEY).length;
        cp += riverProvs * 3; // Doubles culture points from river provinces
      }
      faction.culturePoints = (faction.culturePoints || 0) + cp;

      // Harvest Resources (только из соединенных линиями снабжения провинций)
      for (const prov of suppliedProvinces) {
        for (const hKey of prov.hexKeys) {
          const t = this.tiles.get(hKey);
          if (t && t.resource) {
            if (t.resource === ResourceType.COPPER) faction.resources.copper = (faction.resources.copper || 0) + 1;
            if (t.resource === ResourceType.TIN) faction.resources.tin = (faction.resources.tin || 0) + 1;
            if (t.resource === ResourceType.CATTLE) faction.resources.cattle = (faction.resources.cattle || 0) + 1;
            if (t.resource === ResourceType.INCENSE) faction.resources.incense = (faction.resources.incense || 0) + 1;
          }
        }
      }
    }
  }

  // --- Migration Mechanic ---
  startMigration(provinceId: string): boolean {
    const prov = this.provinces.get(provinceId);
    if (!prov || !prov.cityId) return false;

    const faction = this.factions.get(prov.ownerFactionId || '');
    if (!faction) return false;

    const city = this.cities.get(prov.cityId);
    if (!city) return false;

    const cityName = city.name;
    const centerQ = prov.centerQ;
    const centerR = prov.centerR;
    const centerTile = this.tiles.get(`${centerQ},${centerR}`);

    // Disband city & abandon current province
    this.cities.delete(city.id);
    prov.cityId = null;
    prov.ownerFactionId = null;
    prov.authority = 70;
    prov.unrestStage = UnrestStage.INTEGRATED;

    for (const hKey of prov.hexKeys) {
      const tile = this.tiles.get(hKey);
      if (tile) {
        tile.cityId = null;
        tile.ownerFactionId = null;
      }
    }

    const hasNomadicDogma = faction.unlockedDogmas.includes(DogmaId.NOMADIC_LIFESTYLE);
    const moves = hasNomadicDogma ? 7 : 5;

    const hordeId = `unit_horde_${faction.id}_${Date.now()}`;
    const hordeUnit: Unit = {
      id: hordeId,
      name: `Орда переселенцев (${cityName})`,
      type: UnitType.HORDE,
      factionId: faction.id,
      q: centerQ,
      r: centerR,
      hp: 100,
      maxHp: 100,
      movesLeft: moves,
      maxMoves: moves,
      combatStrength: 14,
      supply: 100,
      isGarrisoned: false,
      loyalty: 95,
      generalName: faction.ruler.name,
      originCityName: cityName,
      originProvinceId: prov.id
    };

    if (centerTile) centerTile.unitId = hordeId;
    this.units.set(hordeId, hordeUnit);

    this.addLog(`🚶 ВЕЛИКАЯ МИГРАЦИЯ! Народ города «${cityName}» снялся с земель провинции «${prov.name}» и сформировал мигрирующую Орду (Скорость: ${moves} гексов/ход)!`, 'warning');
    EventBus.emit('MIGRATION_STARTED', { factionId: faction.id, factionName: faction.name, provinceName: prov.name, hordeId });
    return true;
  }

  settleHorde(unitId: string): boolean {
    const unit = this.units.get(unitId);
    if (!unit || unit.type !== UnitType.HORDE) return false;

    const tile = this.tiles.get(`${unit.q},${unit.r}`);
    if (!tile || tile.biome === BiomeType.OCEAN || tile.cityId) return false;

    const faction = this.factions.get(unit.factionId);
    if (!faction) return false;

    const provId = tile.provinceId;
    const province = provId ? this.provinces.get(provId) : null;
    if (province && province.ownerFactionId && province.ownerFactionId !== faction.id) return false;
    if (province && province.cityId && this.cities.has(province.cityId)) return false;
    const cityName = unit.originCityName ? `Новый ${unit.originCityName}` : NameGenerator.generateCityName();

    const cityId = this.nextId('city');
    const newCity: City = {
      id: cityId,
      name: cityName,
      q: unit.q,
      r: unit.r,
      provinceId: provId || 'prov_unknown',
      factionId: faction.id,
      population: 6,
      dominantCultureId: faction.rootCultureId,
      cultureWeights: { [faction.rootCultureId]: 1.0 },
      accumulatedDrift: 0,
      authority: 85,
      effectiveDistanceToCapital: 0,
      unrestStage: UnrestStage.INTEGRATED,
      garrisonStrength: 6,
      foodStock: 30,
      productionStock: 20
    };

    tile.cityId = cityId;
    tile.ownerFactionId = faction.id;
    tile.hasRoad = true;
    tile.unitId = null;

    if (province) {
      province.cityId = cityId;
      province.ownerFactionId = faction.id;
      province.dominantCultureId = faction.rootCultureId;
      province.authority = 85;
      province.unrestStage = UnrestStage.INTEGRATED;

      for (const hKey of province.hexKeys) {
        const pTile = this.tiles.get(hKey);
        if (pTile) pTile.ownerFactionId = faction.id;
      }
    }

    this.cities.set(cityId, newCity);
    this.units.delete(unitId);

    SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
    LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);
    this.addLog(`🏕️ ОРДА ОСЕЛА! Мигрирующее племя державы «${faction.name}» колонизировало провинцию «${province?.name || cityName}» и основало поселение «${cityName}»!`, 'info');
    EventBus.emit('MIGRATION_SETTLED', { factionId: faction.id, factionName: faction.name, provinceName: province?.name || cityName, cityName });
    return true;
  }

  private processAIMigration(faction: Faction): void {
    // Horde movement & re-settling is handled by OpportunistAI.manageHordes
    // (vacant-land targeting, crossing water & mountains).

    // Desperate non-capital cities abandon their lands and migrate (cohesion < 20% or famine)
    const aiCities = Array.from(this.cities.values()).filter(c => c.factionId === faction.id);
    if (aiCities.length < 2) return;

    const starving = faction.grain <= 0;
    for (const city of aiCities) {
      if (city.id === faction.capitalCityId) continue;
      if ((city.authority < 20 || starving) && Math.random() < 0.25) {
        this.startMigration(city.provinceId);
        break;
      }
    }
  }

  // --- Module 4: Barbarian Hordes & Raids ---
  private processBarbarianTurn(): void {
    // 1. Spawning: empty wilderness lands have 5% chance each turn to spawn "Варвары"
    const barbarianUnits = Array.from(this.units.values()).filter(u => u.factionId === 'faction_barbarians');
    if (barbarianUnits.length < 8) {
      for (const prov of this.provinces.values()) {
        if (prov.ownerFactionId !== null) continue; // Must be empty wild lands
        const isDangerous = prov.biome === BiomeType.STEPPE || prov.biome === BiomeType.DESERT || prov.biome === BiomeType.HILLS || prov.tribalCamp !== null;
        if (!isDangerous) continue;

        if (Math.random() < 0.05) { // 5% chance
          const centerTile = this.tiles.get(`${prov.centerQ},${prov.centerR}`);
          if (centerTile && !centerTile.unitId && centerTile.biome !== BiomeType.OCEAN) {
            const barbId = `unit_barb_${this.currentTurn}_${Math.floor(Math.random() * 10000)}`;
            const barbUnit: Unit = {
              id: barbId,
              name: 'Варвары (Налетчики)',
              type: UnitType.HORDE,
              factionId: 'faction_barbarians',
              q: prov.centerQ,
              r: prov.centerR,
              hp: 85,
              maxHp: 85,
              movesLeft: 3,
              maxMoves: 3,
              combatStrength: 12,
              supply: 100,
              isGarrisoned: false,
              loyalty: 100,
              generalName: 'Вождь Варваров'
            };
            centerTile.unitId = barbId;
            this.units.set(barbId, barbUnit);
            this.addLog(`⚠️ ВАРВАРЫ: В диких землях провинции «${prov.name}» замечен враждебный отряд кочевников!`, 'warning');
            break; // limit to 1 spawn per turn
          }
        }
      }
    }

    // 2. Movement and Raiding towards closest inhabited border
    const civilizedTiles = Array.from(this.tiles.values()).filter(t => t.ownerFactionId !== null && t.ownerFactionId !== 'faction_barbarians');
    if (civilizedTiles.length === 0) return;

    for (const barb of this.units.values()) {
      if (barb.factionId !== 'faction_barbarians' || barb.movesLeft <= 0) continue;

      const barbCoord = new HexCoord(barb.q, barb.r);

      // Find closest civilized tile
      let targetTile: HexTile | null = null;
      let minDist = 999;
      for (const ct of civilizedTiles) {
        const d = barbCoord.distanceTo(new HexCoord(ct.q, ct.r));
        if (d < minDist) {
          minDist = d;
          targetTile = ct;
        }
      }

      if (!targetTile) continue;

      // Pick neighbor closest to target
      const targetCoord = new HexCoord(targetTile.q, targetTile.r);
      let bestNeighbor: HexCoord | null = null;
      let bestDist = minDist;

      for (const n of barbCoord.neighbors()) {
        const nTile = this.tiles.get(n.key);
        if (!nTile || nTile.biome === BiomeType.OCEAN || nTile.elevation >= 0.88) continue;
        const d = n.distanceTo(targetCoord);
        if (d < bestDist) {
          bestDist = d;
          bestNeighbor = n;
        }
      }

      if (bestNeighbor) {
        const destTile = this.tiles.get(bestNeighbor.key);
        if (destTile) {
          // If destTile is owned by a faction, raid resources!
          if (destTile.ownerFactionId && destTile.ownerFactionId !== 'faction_barbarians') {
            const victim = this.factions.get(destTile.ownerFactionId);
            if (victim) {
              const grainStolen = Math.min(victim.grain, 18);
              const goldStolen = Math.min(victim.gold, 12);
              victim.grain -= grainStolen;
              victim.gold -= goldStolen;
              if (victim.isPlayer) {
                this.addLog(`🔥 НАБЕГ ВАРВАРОВ! Варвары разграбили пограничные амбары (-${grainStolen} 🌾, -${goldStolen} 💰)!`, 'danger');
              }
            }
          }

          // Move or combat
          if (!destTile.unitId) {
            const currentTile = this.tiles.get(barbCoord.key);
            if (currentTile) currentTile.unitId = null;
            destTile.unitId = barb.id;
            barb.q = bestNeighbor.q;
            barb.r = bestNeighbor.r;
            barb.movesLeft = Math.max(0, barb.movesLeft - 1);
          } else {
            // Skirmish with defending unit
            const defender = this.units.get(destTile.unitId);
            if (defender && defender.factionId !== 'faction_barbarians') {
              defender.hp -= 20;
              barb.hp -= 25;
              barb.movesLeft = 0;
              if (defender.hp <= 0) {
                this.units.delete(defender.id);
                destTile.unitId = barb.id;
                const currentTile = this.tiles.get(barbCoord.key);
                if (currentTile) currentTile.unitId = null;
                barb.q = bestNeighbor.q;
                barb.r = bestNeighbor.r;
                this.addLog(`Гарнизон провинции разбит набегом варваров!`, 'danger');
              }
              if (barb.hp <= 0) {
                this.units.delete(barb.id);
                const currentTile = this.tiles.get(barbCoord.key);
                if (currentTile) currentTile.unitId = null;
              }
            }
          }
        }
      }
    }
  }

  // --- Module 5: Cultural Assimilation of Lower Tier AI Provinces ---
  private processTierAssimilation(): void {
    const player = this.getPlayerFaction();
    if (!player || !player.tier) return;

    const playerProvIds = new Set(
      Array.from(this.provinces.values())
        .filter(p => p.ownerFactionId === player.id)
        .map(p => p.id)
    );

    for (const aiProv of this.provinces.values()) {
      if (!aiProv.ownerFactionId || aiProv.ownerFactionId === player.id) continue;
      const aiFaction = this.factions.get(aiProv.ownerFactionId);
      if (!aiFaction || aiFaction.isPlayer) continue;

      const aiTier = aiFaction.tier || FactionTier.TRIBE;
      // Assimilation: If player province borders an AI province of lower Tier
      if (player.tier > aiTier) {
        let bordersPlayer = false;
        for (const hKey of aiProv.hexKeys) {
          const coord = HexCoord.fromKey(hKey);
          for (const n of coord.neighbors()) {
            const nTile = this.tiles.get(n.key);
            if (nTile && nTile.provinceId && playerProvIds.has(nTile.provinceId)) {
              bordersPlayer = true;
              break;
            }
          }
          if (bordersPlayer) break;
        }

        if (bordersPlayer) {
          // Cultural prestige of higher tier erodes lower tier cohesion
          const tierDiff = player.tier - aiTier;
          const cohesionDrop = 8 * tierDiff;
          aiProv.authority = Math.max(0, aiProv.authority - cohesionDrop);

          if (aiProv.cityId) {
            const city = this.cities.get(aiProv.cityId);
            if (city) {
              city.authority = aiProv.authority;
              city.unrestStage = aiProv.authority < 15 ? UnrestStage.SECESSION_CRISIS : UnrestStage.AUTONOMY_DEMAND;
            }
          }

          if (aiProv.authority <= 0) {
            // Peaceful assimilation!
            this.assimilateProvince(aiProv.id, player.id);
          }
        }
      }
    }
  }

  assimilateProvince(provinceId: string, playerFactionId: string): void {
    const prov = this.provinces.get(provinceId);
    const player = this.factions.get(playerFactionId);
    if (!prov || !player) return;

    const oldFaction = prov.ownerFactionId ? this.factions.get(prov.ownerFactionId) : null;
    prov.ownerFactionId = player.id;
    prov.dominantCultureId = player.rootCultureId;
    prov.authority = 65;
    prov.unrestStage = UnrestStage.INTEGRATED;

    for (const hKey of prov.hexKeys) {
      const tile = this.tiles.get(hKey);
      if (tile) {
        tile.ownerFactionId = player.id;
      }
    }

    if (prov.cityId) {
      const city = this.cities.get(prov.cityId);
      if (city) {
        city.factionId = player.id;
        city.dominantCultureId = player.rootCultureId;
        city.authority = 65;
        city.unrestStage = UnrestStage.INTEGRATED;
      }
    }

    SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
    LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);

    this.addLog(
      `🕊️ МИРНАЯ АССИМИЛЯЦИЯ! Народ провинции «${prov.name}» (ранее: ${oldFaction?.name || 'Варвары'}) признал культурное величие нашей цивилизации и добровольно перешел под наше подданство!`,
      'critical'
    );
    EventBus.emit('PROVINCE_ANNEXED', { factionId: player.id, provinceId: prov.id, provinceName: prov.name });
  }

  // --- Traditions & Dogmas ---
  unlockDogma(dogmaId: DogmaId): { success: boolean; message: string } {
    const player = this.getPlayerFaction();
    if (!player) return { success: false, message: 'Игрок не найден.' };

    if (player.unlockedDogmas.includes(dogmaId)) {
      return { success: false, message: 'Этот догмат уже открыт!' };
    }

    const cost = 75;
    if ((player.culturePoints || 0) < cost) {
      return { success: false, message: `Недостаточно Очков Культуры (${player.culturePoints || 0} / ${cost}).` };
    }

    player.culturePoints -= cost;
    player.unlockedDogmas.push(dogmaId);

    const names: Record<DogmaId, string> = {
      [DogmaId.ANCESTOR_CULT]: '«Культ Предков»',
      [DogmaId.RIVER_PRIESTHOOD]: '«Речное Священничество»',
      [DogmaId.NOMADIC_LIFESTYLE]: '«Кочевой Быт»'
    };

    const dogmaName = names[dogmaId];
    this.addLog(`📜 РЕЛИГИОЗНЫЙ ДОГМАТ! Держава «${player.name}» приняла священный догмат ${dogmaName}!`, 'info');
    EventBus.emit('DOGMA_UNLOCKED', { factionId: player.id, dogmaId, dogmaName });
    return { success: true, message: `Догмат ${dogmaName} успешно утвержден!` };
  }

  // --- Resources & Trade ---
  executeTrade(
    targetFactionId: string,
    offerResource: keyof ResourceStockpile,
    demandResource: keyof ResourceStockpile,
    offerAmount: number = 2,
    demandAmount: number = 2
  ): { success: boolean; message: string } {
    const player = this.getPlayerFaction();
    const target = this.factions.get(targetFactionId);
    if (!player || !target || player.id === target.id) {
      return { success: false, message: 'Неверные стороны торговой сделки.' };
    }

    if (player.atWarWith.includes(target.id)) {
      return { success: false, message: 'Нельзя торговать с враждебной державой во время войны!' };
    }

    if ((player.resources[offerResource] || 0) < offerAmount) {
      return { success: false, message: `У вас недостаточно ресурса (${offerResource}: ${player.resources[offerResource] || 0} / ${offerAmount}).` };
    }

    if ((target.resources[demandResource] || 0) < demandAmount) {
      return { success: false, message: `У державы ${target.name} недостаточно ресурса (${demandResource}: ${target.resources[demandResource] || 0} / ${demandAmount}).` };
    }

    // Execute exchange
    player.resources[offerResource] -= offerAmount;
    player.resources[demandResource] = (player.resources[demandResource] || 0) + demandAmount;

    target.resources[demandResource] -= demandAmount;
    target.resources[offerResource] = (target.resources[offerResource] || 0) + offerAmount;

    // Offering Incense or Cattle provides an opinion and cohesion boost to the AI
    if (offerResource === 'incense' || offerResource === 'cattle') {
      const rel = target.diplomacy[player.id];
      if (rel) {
        rel.opinion = Math.min(100, rel.opinion + 15);
      }
      for (const c of this.cities.values()) {
        if (c.factionId === target.id) {
          c.authority = Math.min(100, c.authority + 10);
        }
      }
    }

    const resNames: Record<string, string> = {
      copper: 'Медь',
      tin: 'Олово',
      cattle: 'Скот',
      incense: 'Благовония'
    };

    const msg = `Сделка заключена: обменяно ${offerAmount} ${resNames[offerResource]} на ${demandAmount} ${resNames[demandResource]} у державы ${target.name}!`;
    player.lastTradeTurn = { ...(player.lastTradeTurn || {}), [target.id]: this.currentTurn };
    target.lastTradeTurn = { ...(target.lastTradeTurn || {}), [player.id]: this.currentTurn };

    this.addLog(`🤝 ТОРГОВЛЯ: ${msg}`, 'info');
    EventBus.emit('TRADE_DEAL_COMPLETED', {
      playerFactionId: player.id,
      targetFactionId: target.id,
      offered: offerResource,
      received: demandResource
    });
    return { success: true, message: msg };
  }

  // Player Actions: Found City with Settler (Claims ENTIRE Province!)
  foundCityWithSettler(unitId: string, cityName: string): boolean {
    const unit = this.units.get(unitId);
    if (!unit || unit.type !== UnitType.SETTLER) return false;

    const tile = this.tiles.get(`${unit.q},${unit.r}`);
    if (!tile || tile.cityId || tile.biome === BiomeType.OCEAN) return false;

    const faction = this.factions.get(unit.factionId);
    if (!faction) return false;

    const provId = tile.provinceId;
    const province = provId ? this.provinces.get(provId) : null;
    const provName = province ? province.name : cityName;

    const cityId = `city_${Date.now()}`;
    const newCity: City = {
      id: cityId,
      name: cityName,
      q: unit.q,
      r: unit.r,
      provinceId: provId || 'prov_unknown',
      factionId: faction.id,
      population: 5,
      dominantCultureId: faction.rootCultureId,
      cultureWeights: { [faction.rootCultureId]: 1.0 },
      accumulatedDrift: 0,
      authority: 80,
      effectiveDistanceToCapital: 0,
      unrestStage: UnrestStage.INTEGRATED,
      garrisonStrength: 5,
      foodStock: 25,
      productionStock: 15
    };

    // If province has an indigenous camp, apply syncretism drift immediately
    if (tile.tribalCamp || province?.tribalCamp) {
      newCity.accumulatedDrift += 35;
      const tribe = tile.tribalCamp || province?.tribalCamp;
      this.addLog(`Город ${cityName} основан в землях ${tribe?.name}. Синкретизм культур ускорил дрейф!`, 'warning');
      tile.tribalCamp = null;
      if (province) province.tribalCamp = null;
    }

    tile.cityId = cityId;
    tile.ownerFactionId = faction.id;
    tile.hasRoad = true;
    tile.unitId = null;

    // Claim the ENTIRE PROVINCE for the faction!
    if (province) {
      province.cityId = cityId;
      province.ownerFactionId = faction.id;
      province.dominantCultureId = faction.rootCultureId;
      province.authority = 80;
      province.unrestStage = UnrestStage.INTEGRATED;

      for (const hKey of province.hexKeys) {
        const pTile = this.tiles.get(hKey);
        if (pTile) {
          pTile.ownerFactionId = faction.id;
        }
      }
    }

    this.cities.set(cityId, newCity);
    this.units.delete(unitId);

    // Update supply lines & logistics
    SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
    LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);
    this.addLog(`Провинция «${provName}» колонизирована! Основан город ${cityName}. Вся территория провинции вошла в состав державы.`, 'info');

    return true;
  }

  // Player Action: Move Unit
  moveUnit(unitId: string, targetCoord: HexCoord): boolean {
    const unit = this.units.get(unitId);
    if (!unit || unit.movesLeft <= 0) return false;

    const fromCoord = new HexCoord(unit.q, unit.r);
    const dist = fromCoord.distanceTo(targetCoord);
    if (dist !== 1) return false;

    const targetTile = this.tiles.get(targetCoord.key);
    if (!targetTile || targetTile.elevation <= 0.20 || targetTile.elevation >= 0.88) return false; // Water or High Peaks

    if (targetTile.unitId) {
      const defendingUnit = this.units.get(targetTile.unitId);
      if (defendingUnit && defendingUnit.factionId !== unit.factionId) {
        const attFaction = this.factions.get(unit.factionId);
        const defFaction = this.factions.get(defendingUnit.factionId);

        const battleRes = CombatSystem.calculateBattle(
          unit,
          defendingUnit,
          targetTile,
          attFaction || null,
          defFaction || null
        );
        unit.movesLeft = 0;
        this.addLog(battleRes.description, battleRes.isVictory ? 'info' : 'warning');
        this.addChronicle(battleRes.description, battleRes.isVictory ? 'info' : 'warning');

        if (!battleRes.defenderSurvived) {
          this.units.delete(defendingUnit.id);
          targetTile.unitId = null;

          if (defendingUnit.factionId === 'faction_barbarians') {
            this.addLog(`Орда варваров разгромлена! Трофеи: +20 золота, +15 зерна.`, 'info');
            if (attFaction) {
              attFaction.gold += 20;
              attFaction.grain += 15;
            }
          }
        }

        if (!battleRes.attackerSurvived) {
          this.units.delete(unit.id);
          const oldTile = this.tiles.get(fromCoord.key);
          if (oldTile) oldTile.unitId = null;
          return true;
        }

        if (!battleRes.defenderSurvived && battleRes.attackerSurvived) {
          const oldTile = this.tiles.get(fromCoord.key);
          if (oldTile) oldTile.unitId = null;
          unit.q = targetCoord.q;
          unit.r = targetCoord.r;
          targetTile.unitId = unit.id;

          if (targetTile.ownerFactionId && targetTile.ownerFactionId !== unit.factionId) {
            targetTile.ownerFactionId = unit.factionId;
          }
          return true;
        }

        return false;
      }
      return false;
    }

    // Warlord loyalty check on movement:
    if (unit.loyalty < 30 && (this.currentCrisis !== null || this.getPlayerFaction()?.isInterregnum)) {
      if (Math.random() < 0.25) {
        this.triggerWarlordRevolt(unit);
        return false;
      }
    }

    // Contact/pacify camp
    if (targetTile.tribalCamp) {
      this.addLog(`${unit.name} подчинил кочевое стойбище ${targetTile.tribalCamp.name}.`, 'info');
      targetTile.tribalCamp = null;
    }

    const oldTile = this.tiles.get(fromCoord.key);
    if (oldTile) oldTile.unitId = null;

    unit.q = targetCoord.q;
    unit.r = targetCoord.r;
    unit.movesLeft = Math.max(0, unit.movesLeft - targetTile.movementCost);
    targetTile.unitId = unit.id;

    return true;
  }

  triggerWarlordRevolt(unit: Unit): void {
    const oldFaction = this.factions.get(unit.factionId);
    if (!oldFaction) return;

    const warlordName = unit.generalName || 'Мятежный Полководец';
    const newFactionId = `faction_warlord_${this.currentTurn}_${unit.id}`;
    const newFaction: Faction = {
      id: newFactionId,
      name: `Армия ${warlordName}`,
      color: '#e74c3c',
      capitalCityId: null,
      rootCultureId: oldFaction.rootCultureId,
      isPlayer: false,
      isBreakaway: true,
      gold: 50,
      grain: 60,
      overextension: 5,
      atWarWith: [oldFaction.id],
      ruler: {
        name: warlordName,
        title: 'Военный Диктатор',
        age: 38,
        maxAge: 65,
        legitimacy: 60,
        traits: ['Мятежник', 'Полководец'],
        mainTrait: 'CONQUEROR'
      },
      isInterregnum: false,
      interregnumTurnsLeft: 0,
      diplomacy: {
        [oldFaction.id]: {
          status: DiplomaticStatus.WAR,
          opinion: -95,
          pactTurnsLeft: 0
        }
      },
      culturePoints: 10,
      unlockedDogmas: [],
      resources: { copper: 1, tin: 0, cattle: 1, incense: 0 },
      tier: FactionTier.TRIBE,
      outposts: []
    };

    if (!oldFaction.diplomacy) oldFaction.diplomacy = {};
    oldFaction.diplomacy[newFactionId] = {
      status: DiplomaticStatus.WAR,
      opinion: -95,
      pactTurnsLeft: 0
    };
    oldFaction.atWarWith.push(newFactionId);

    this.factions.set(newFactionId, newFaction);

    unit.factionId = newFactionId;
    unit.loyalty = 100;

    // If unit stands on a tile in a province, claim the province
    const tile = this.tiles.get(`${unit.q},${unit.r}`);
    if (tile && tile.provinceId) {
      const prov = this.provinces.get(tile.provinceId);
      if (prov && prov.ownerFactionId === oldFaction.id) {
        prov.ownerFactionId = newFactionId;
        prov.authority = 70;
        for (const hk of prov.hexKeys) {
          const t = this.tiles.get(hk);
          if (t) t.ownerFactionId = newFactionId;
        }
      }
    }

    this.addChronicle(
      `⚡ МЯТЕЖ ПОЛКОВОДЦА: Военачальник «${warlordName}» поднял бунт из-за низкой верности армии (<30%) и объявил себя верховным царем новой фракции!`,
      'critical'
    );
    EventBus.emit('WARLORD_REVOLTED', { unit, warlordName, newFactionId });
  }

  // --- Expansion & Outpost System ---
  getExpandableProvinces(factionId: string): Province[] {
    const faction = this.factions.get(factionId);
    if (!faction) return [];

    // All provinces owned by faction (or where faction has an outpost)
    const ownedProvIds = new Set<string>();
    for (const prov of this.provinces.values()) {
      if (prov.ownerFactionId === factionId || faction.outposts?.includes(prov.id)) {
        ownedProvIds.add(prov.id);
      }
    }

    if (ownedProvIds.size === 0) return [];

    // Find all empty land provinces that share an edge with any owned province
    const expandable: Province[] = [];
    const visited = new Set<string>();

    for (const [pId, prov] of this.provinces.entries()) {
      if (prov.ownerFactionId !== null) continue; // Must be empty
      if (visited.has(pId)) continue;

      let isAdjacent = false;
      for (const hKey of prov.hexKeys) {
        const [q, r] = hKey.split(',').map(Number);
        const coord = new HexCoord(q, r);
        for (const n of coord.neighbors()) {
          const nTile = this.tiles.get(n.key);
          if (nTile && nTile.provinceId && ownedProvIds.has(nTile.provinceId)) {
            isAdjacent = true;
            break;
          }
        }
        if (isAdjacent) break;
      }

      if (isAdjacent) {
        visited.add(pId);
        expandable.push(prov);
      }
    }

    return expandable;
  }

  isProvinceExpandable(provinceId: string, factionId: string): boolean {
    const list = this.getExpandableProvinces(factionId);
    return list.some(p => p.id === provinceId);
  }

  getAnnexationCost(provinceId: string, factionId: string): {
    food: number;
    culture: number;
    turnsPeaceful: number;
    canAfford: boolean;
    canAffordEither: boolean;   // AI rule: enough Food OR enough Culture Points
    reason?: string;
  } {
    const player = this.factions.get(factionId);
    const prov = this.provinces.get(provinceId);
    if (!player || !prov) {
      return { food: 999, culture: 999, turnsPeaceful: 99, canAfford: false, canAffordEither: false, reason: 'Неверные данные региона' };
    }

    let foodCost = 35;
    let cultureCost = 25;

    // Culture Perks (starter-culture bonuses belong to the human player only)
    if (player.isPlayer && this.selectedStarter === 'STEPPE_NOMADS' && (prov.biome === BiomeType.STEPPE || prov.biome === BiomeType.DESERT)) {
      foodCost = 20;
      cultureCost = 15;
    } else if (player.isPlayer && this.selectedStarter === 'RIVER_FARMERS' && prov.biome === BiomeType.RIVER_VALLEY) {
      foodCost = 25;
      cultureCost = 15;
    }

    // Dogma: Nomadic Lifestyle (50% discount in steppes/desert)
    if (player.unlockedDogmas?.includes(DogmaId.NOMADIC_LIFESTYLE) && (prov.biome === BiomeType.STEPPE || prov.biome === BiomeType.DESERT)) {
      foodCost = Math.round(foodCost * 0.5);
      cultureCost = Math.round(cultureCost * 0.5);
    }

    // If province has an outpost already built by player: 40% discount
    if (player.outposts?.includes(provinceId)) {
      foodCost = Math.round(foodCost * 0.6);
      cultureCost = Math.round(cultureCost * 0.6);
    }

    // Module 3: Ландшафтные преграды (Горы и Пустыня блокируют прямую экспансию -> стоимость в Культуре x3)
    if (prov.biome === BiomeType.MOUNTAINS || prov.biome === BiomeType.DESERT) {
      cultureCost = Math.round(cultureCost * 3);
    }

    const hasFood = player.grain >= foodCost;
    const hasCulture = (player.culturePoints || 0) >= cultureCost;
    const canAfford = hasFood && hasCulture;
    const canAffordEither = hasFood || hasCulture;
    let reason = '';
    if (!canAfford) {
      if (!hasFood && !hasCulture) {
        reason = `Недостаточно зерна (${player.grain}/${foodCost}) и очков культуры (${player.culturePoints || 0}/${cultureCost})`;
      } else if (!hasFood) {
        reason = `Недостаточно зерна (${player.grain}/${foodCost})`;
      } else {
        reason = `Недостаточно очков культуры (${player.culturePoints || 0}/${cultureCost})`;
      }
    }

    return {
      food: foodCost,
      culture: cultureCost,
      turnsPeaceful: 3,
      canAfford,
      canAffordEither,
      reason
    };
  }

  annexProvince(provinceId: string): { success: boolean; message: string; newCityName?: string } {
    const player = this.getPlayerFaction();
    if (!player) return { success: false, message: 'Игрок не найден.' };

    const prov = this.provinces.get(provinceId);
    if (!prov) return { success: false, message: 'Регион не найден.' };

    if (prov.ownerFactionId !== null) {
      return { success: false, message: 'Этот регион уже принадлежит другой державе!' };
    }

    if (!this.isProvinceExpandable(provinceId, player.id)) {
      return { success: false, message: 'Этот регион не граничит с вашими землями!' };
    }

    const cost = this.getAnnexationCost(provinceId, player.id);
    if (!cost.canAfford) {
      return { success: false, message: cost.reason || 'Недостаточно ресурсов для присоединения региона.' };
    }

    // Deduct cost
    player.grain -= cost.food;
    player.culturePoints = (player.culturePoints || 0) - cost.culture;

    // Create city/settlement in the province center
    const cityName = NameGenerator.generateCityName();
    const cityId = `city_${Date.now()}`;

    const newCity: City = {
      id: cityId,
      name: cityName,
      q: prov.centerQ,
      r: prov.centerR,
      provinceId: prov.id,
      factionId: player.id,
      population: 4,
      dominantCultureId: player.rootCultureId,
      cultureWeights: { [player.rootCultureId]: 1.0 },
      accumulatedDrift: 0,
      authority: 85,
      effectiveDistanceToCapital: 0,
      unrestStage: UnrestStage.INTEGRATED,
      garrisonStrength: 6,
      foodStock: 25,
      productionStock: 15
    };

    this.cities.set(cityId, newCity);

    // Update province & hexes
    prov.cityId = cityId;
    prov.ownerFactionId = player.id;
    prov.dominantCultureId = player.rootCultureId;
    prov.authority = 85;
    prov.unrestStage = UnrestStage.INTEGRATED;
    prov.isOutpost = false;

    // Remove from outposts if it was an outpost
    if (player.outposts) {
      player.outposts = player.outposts.filter(id => id !== provinceId);
    }

    for (const hKey of prov.hexKeys) {
      const tile = this.tiles.get(hKey);
      if (tile) {
        tile.ownerFactionId = player.id;
      }
    }

    const centerTile = this.tiles.get(`${prov.centerQ},${prov.centerR}`);
    if (centerTile) {
      centerTile.cityId = cityId;
      centerTile.hasRoad = true;
    }

    SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
    LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);

    this.addLog(`🏛️ ЭКСПАНСИЯ: Провинция «${prov.name}» присоединена к державе! Основано поселение «${cityName}» (-${cost.food} 🌾, -${cost.culture} 📜).`, 'info');
    EventBus.emit('PROVINCE_ANNEXED', { factionId: player.id, provinceId: prov.id, provinceName: prov.name, cityName });

    // Check if expansion triggered a cultural tier evolution!
    this.checkFactionEvolution();

    return { success: true, message: `Провинция «${prov.name}» успешно присоединена!`, newCityName: cityName };
  }

  buildOutpost(provinceId: string): { success: boolean; message: string } {
    const player = this.getPlayerFaction();
    if (!player) return { success: false, message: 'Игрок не найден.' };

    if (!player.tier || player.tier < FactionTier.CHIEFDOM) {
      return { success: false, message: 'Строительство аванпостов доступно со статуса Вождества (Тир 2)!' };
    }

    const prov = this.provinces.get(provinceId);
    if (!prov || prov.ownerFactionId !== null) {
      return { success: false, message: 'Нельзя построить аванпост на этой территории.' };
    }

    if (!this.isProvinceExpandable(provinceId, player.id)) {
      return { success: false, message: 'Провинция не граничит с вашими землями.' };
    }

    const cost = 25;
    if (player.gold < cost) {
      return { success: false, message: `Недостаточно золота (${player.gold}/${cost}).` };
    }

    player.gold -= cost;
    prov.isOutpost = true;
    if (!player.outposts) player.outposts = [];
    player.outposts.push(provinceId);

    SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
    LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);

    this.addLog(`⛺ АВАНПОСТ: В пограничной провинции «${prov.name}» возведен укрепленный аванпост (-${cost} 💰)!`, 'info');
    EventBus.emit('OUTPOST_BUILT', { factionId: player.id, provinceId: prov.id, provinceName: prov.name });

    return { success: true, message: `Аванпост в провинции «${prov.name}» успешно возведен!` };
  }

  // --- Cultural Tier Evolution System ---
  getTierProgress(factionId: string): {
    currentTier: FactionTier;
    nextTier: FactionTier | null;
    currentCulture: number;
    targetCulture: number;
    stableProvinces: number;
    targetStableProvinces: number;
    canEvolve: boolean;
  } {
    const faction = this.factions.get(factionId);
    const tier = faction?.tier || FactionTier.TRIBE;
    const culture = faction?.culturePoints || 0;

    // Count stable provinces (authority >= 70)
    const empireCities = Array.from(this.cities.values()).filter(c => c.factionId === factionId);
    const stableProvinces = empireCities.filter(c => c.authority >= 70).length;

    let targetCulture = 100;
    let targetStableProvinces = 2;
    let nextTier: FactionTier | null = FactionTier.CHIEFDOM;

    if (tier === FactionTier.CHIEFDOM) {
      targetCulture = 250;
      targetStableProvinces = 4;
      nextTier = FactionTier.EARLY_STATE;
    } else if (tier === FactionTier.EARLY_STATE) {
      targetCulture = 600;
      targetStableProvinces = 7;
      nextTier = FactionTier.EMPIRE;
    } else if (tier === FactionTier.EMPIRE) {
      nextTier = null;
      targetCulture = 600;
      targetStableProvinces = 7;
    }

    const canEvolve = nextTier !== null && culture >= targetCulture && stableProvinces >= targetStableProvinces;

    return {
      currentTier: tier,
      nextTier,
      currentCulture: culture,
      targetCulture,
      stableProvinces,
      targetStableProvinces,
      canEvolve
    };
  }

  checkFactionEvolution(): {
    evolved: boolean;
    oldTier?: FactionTier;
    newTier?: FactionTier;
    tierName?: string;
    subtitle?: string;
    perks?: string[];
  } | null {
    const player = this.getPlayerFaction();
    if (!player) return null;

    const progress = this.getTierProgress(player.id);
    if (!progress.canEvolve || !progress.nextTier) return null;

    const oldTier = progress.currentTier;
    const newTier = progress.nextTier;
    player.tier = newTier;

    let tierName = '';
    let subtitle = '';
    let perks: string[] = [];

    if (newTier === FactionTier.CHIEFDOM) {
      tierName = 'Вождество';
      subtitle = 'Племенные кланы объединились под властью верховного вождя!';
      perks = [
        '⛺ Открыто строительство пограничных Аванпостов (в меню клика по провинции).',
        '🗺️ Штраф за удаленность от столицы снижен на 50%.',
        '🛡️ Снято жесткое ограничение Дикого Племени на 3 провинции.'
      ];
    } else if (newTier === FactionTier.EARLY_STATE) {
      tierName = 'Раннее Государство / Цивилизация';
      subtitle = 'Законы, иерархия и храмовые амбары сформировали первое подлинное государство!';
      perks = [
        '🌿 Пассивное расширение: поселенцы мирно осваивают пустые рубежи каждые 7 ходов.',
        '🤝 Полноценная дипломатия: открыты союзы и расширенная торговля металлами.',
        '⚖️ Бремя перерасширения империи ослаблено на 35%.'
      ];
    } else if (newTier === FactionTier.EMPIRE) {
      tierName = 'Великая Империя';
      subtitle = 'Свет вашей цивилизации озаряет континент! Ваше господство непререкаемо.';
      perks = [
        '👑 Колоссальный бонус +25% к Cohesion (сплоченности) во всех уголках державы.',
        '🕊️ Мирная ассимиляция: бунтующие и слабые чужие города могут добровольно присягнуть вам без войны.',
        '✨ Несокрушимая легитимность монархии и абсолютный авторитет.'
      ];
    }

    const logMsg = `🌟 ЭВОЛЮЦИЯ! Держава «${player.name}» совершила качественный скачок и эволюционировала в статус «${tierName}»!`;
    this.addLog(logMsg, 'critical');

    EventBus.emit('FACTION_EVOLVED', {
      factionId: player.id,
      oldTier,
      newTier,
      tierName,
      subtitle,
      perks
    });

    return {
      evolved: true,
      oldTier,
      newTier,
      tierName,
      subtitle,
      perks
    };
  }

  // ==========================================================================
  // AI Colonisation, Migration Hordes & Dynamic World Spawner
  // ==========================================================================

  private idCounter: number = 0;

  /** Collision-free id generator (Date.now() alone collides when the AI founds several cities in one turn). */
  private nextId(prefix: string): string {
    this.idCounter++;
    return `${prefix}_${this.currentTurn}_${this.idCounter}_${Date.now().toString(36)}`;
  }

  /** Share of land tiles (tiles that belong to a province) that nobody owns yet. */
  getEmptyLandRatio(): number {
    let land = 0;
    let empty = 0;
    for (const t of this.tiles.values()) {
      if (t.biome === BiomeType.OCEAN || !t.provinceId) continue;
      land++;
      if (!t.ownerFactionId) empty++;
    }
    return land === 0 ? 0 : empty / land;
  }

  /** Provinces that share at least one hex edge with the given province. */
  getAdjacentProvinces(provinceId: string): Province[] {
    const prov = this.provinces.get(provinceId);
    if (!prov) return [];
    const result = new Map<string, Province>();
    for (const hKey of prov.hexKeys) {
      for (const n of HexCoord.fromKey(hKey).neighbors()) {
        const nTile = this.tiles.get(n.key);
        if (nTile?.provinceId && nTile.provinceId !== provinceId) {
          const np = this.provinces.get(nTile.provinceId);
          if (np) result.set(np.id, np);
        }
      }
    }
    return Array.from(result.values());
  }

  /** Founds a settlement in the province centre and hands the whole province to the faction. */
  foundCityForFaction(
    prov: Province,
    faction: Faction,
    opts: { population?: number; authority?: number; cityName?: string } = {}
  ): City {
    const cityName = opts.cityName ?? NameGenerator.generateCityName();
    const cityId = this.nextId('city');
    const authority = opts.authority ?? 85;

    const newCity: City = {
      id: cityId,
      name: cityName,
      q: prov.centerQ,
      r: prov.centerR,
      provinceId: prov.id,
      factionId: faction.id,
      population: opts.population ?? 4,
      dominantCultureId: faction.rootCultureId,
      cultureWeights: { [faction.rootCultureId]: 1.0 },
      accumulatedDrift: 0,
      authority,
      effectiveDistanceToCapital: 0,
      unrestStage: UnrestStage.INTEGRATED,
      garrisonStrength: 6,
      foodStock: 25,
      productionStock: 15
    };
    this.cities.set(cityId, newCity);

    prov.cityId = cityId;
    prov.ownerFactionId = faction.id;
    prov.dominantCultureId = faction.rootCultureId;
    prov.authority = authority;
    prov.unrestStage = UnrestStage.INTEGRATED;
    prov.isOutpost = false;
    if (faction.outposts) {
      faction.outposts = faction.outposts.filter(id => id !== prov.id);
    }

    for (const hKey of prov.hexKeys) {
      const tile = this.tiles.get(hKey);
      if (tile) tile.ownerFactionId = faction.id;
    }
    const centerTile = this.tiles.get(`${prov.centerQ},${prov.centerR}`);
    if (centerTile) {
      centerTile.cityId = cityId;
      centerTile.hasRoad = true;
    }
    return newCity;
  }

  /**
   * AI annexation of an adjacent empty province.
   * Unlike the player (who needs Food AND Culture), an AI faction may pay with Food OR Culture Points:
   * if it can cover both it pays both, otherwise it pays whichever resource it has.
   */
  annexProvinceForFaction(factionId: string, provinceId: string): boolean {
    const faction = this.factions.get(factionId);
    const prov = this.provinces.get(provinceId);
    if (!faction || !prov || prov.ownerFactionId !== null) return false;
    if (!this.isProvinceExpandable(provinceId, factionId)) return false;

    const cost = this.getAnnexationCost(provinceId, factionId);
    if (!cost.canAffordEither) return false;

    if (faction.grain >= cost.food) faction.grain -= cost.food;
    if ((faction.culturePoints || 0) >= cost.culture) faction.culturePoints -= cost.culture;

    this.foundCityForFaction(prov, faction);
    EventBus.emit('PROVINCE_ANNEXED', { factionId, provinceId, provinceName: prov.name, cityName: '' });
    return true;
  }

  /** Spawns a migrating Horde unit from a city (resources are paid by the caller). */
  launchMigrationHorde(factionId: string, cityId: string): Unit | null {
    const faction = this.factions.get(factionId);
    const city = this.cities.get(cityId);
    if (!faction || !city) return null;

    const origin = new HexCoord(city.q, city.r);
    const spot = [origin, ...origin.neighbors()].find(c => {
      const t = this.tiles.get(c.key);
      return !!t && t.biome !== BiomeType.OCEAN && !t.unitId;
    });
    if (!spot) return null;

    const moves = faction.unlockedDogmas?.includes(DogmaId.NOMADIC_LIFESTYLE) ? 7 : 5;
    const hordeId = this.nextId(`unit_horde_${faction.id}`);
    const horde: Unit = {
      id: hordeId,
      name: `Орда переселенцев (${city.name})`,
      type: UnitType.HORDE,
      factionId: faction.id,
      q: spot.q,
      r: spot.r,
      hp: 100,
      maxHp: 100,
      movesLeft: moves,
      maxMoves: moves,
      combatStrength: 14,
      supply: 100,
      isGarrisoned: false,
      loyalty: 90,
      generalName: faction.ruler?.name ?? null,
      originCityName: city.name,
      originProvinceId: city.provinceId
    };
    this.units.set(hordeId, horde);
    const tile = this.tiles.get(spot.key);
    if (tile) tile.unitId = hordeId;

    this.addLog(`🚶 «${faction.name}» заперта горами и морем — часть народа города «${city.name}» ушла в Великую Миграцию!`, 'warning');
    EventBus.emit('MIGRATION_STARTED', { factionId: faction.id, factionName: faction.name, provinceName: city.name, hordeId });
    return horde;
  }

  /** World Spawner trigger: called on every SPAWN_INTERVAL_TURNS-th turn. */
  checkWorldSpawner(): void {
    const ratio = this.getEmptyLandRatio();
    this.lastWorldSpawnCheckTurn = this.currentTurn;
    if (ratio > GAME_CONSTANTS.WORLD.EMPTY_LAND_THRESHOLD) {
      this.spawnNewMedievalNations(ratio);
    }
  }

  /**
   * Picks a random fertile river province (empty or inhabited by a rival AI) for a new nation.
   * Falls back to progressively looser requirements so the spawner still works on exotic maps.
   */
  private pickSpawnProvince(usedSites: HexCoord[]): Province | null {
    const player = this.getPlayerFaction();
    const capitals: HexCoord[] = [];
    for (const f of this.factions.values()) {
      const cap = f.capitalCityId ? this.cities.get(f.capitalCityId) : null;
      if (cap) capitals.push(new HexCoord(cap.q, cap.r));
    }

    const isRiverish = (prov: Province): boolean => {
      if (prov.biome === BiomeType.RIVER_VALLEY) return true;
      for (const hKey of prov.hexKeys) {
        const t = this.tiles.get(hKey);
        if (t?.isRiver) return true;
        for (const n of HexCoord.fromKey(hKey).neighbors()) {
          if (this.tiles.get(n.key)?.isRiver) return true;
        }
      }
      return false;
    };

    const collect = (strictness: 0 | 1 | 2): { prov: Province; weight: number }[] => {
      const out: { prov: Province; weight: number }[] = [];
      for (const prov of this.provinces.values()) {
        if (prov.biome === BiomeType.OCEAN || prov.biome === BiomeType.MOUNTAINS) continue;
        if (strictness < 2 && prov.biome === BiomeType.DESERT) continue;

        // Inhabited provinces: never the player's land, never an AI capital province
        if (prov.ownerFactionId) {
          if (player && prov.ownerFactionId === player.id) continue;
          const owner = this.factions.get(prov.ownerFactionId);
          if (owner?.capitalCityId && owner.capitalCityId === prov.cityId) continue;
        }

        const fertile = prov.fertility >= 2 || prov.biome === BiomeType.RIVER_VALLEY || prov.biome === BiomeType.FERTILE_PLAINS;
        if (strictness === 0 && !(fertile && isRiverish(prov))) continue;
        if (strictness === 1 && !fertile) continue;

        const c = new HexCoord(prov.centerQ, prov.centerR);
        if (capitals.some(cc => cc.distanceTo(c) < 5)) continue;
        if (usedSites.some(uc => uc.distanceTo(c) < 7)) continue;

        out.push({ prov, weight: prov.ownerFactionId ? 1 : 4 });
      }
      return out;
    };

    for (const strictness of [0, 1, 2] as const) {
      const pool = collect(strictness);
      if (pool.length === 0) continue;
      const total = pool.reduce((s, p) => s + p.weight, 0);
      let roll = Math.random() * total;
      for (const p of pool) {
        roll -= p.weight;
        if (roll <= 0) return p.prov;
      }
      return pool[pool.length - 1].prov;
    }
    return null;
  }

  private pickNationType(biome: BiomeType): NationType {
    switch (biome) {
      case BiomeType.STEPPE:
      case BiomeType.DESERT:
        return 'KHANATE';
      case BiomeType.HILLS:
      case BiomeType.MOUNTAINS:
        return 'MOUNTAIN_KINGDOM';
      case BiomeType.FOREST:
        return 'KNIGHTS';
      default:
        // River valleys & fertile plains: breadbaskets of Empires, with Knightly realms as the alternative
        return Math.random() < 0.65 ? 'EMPIRE' : 'KNIGHTS';
    }
  }

  /** Creates one nation (culture, faction, ruler, 3 regions, army) around the given province. */
  private spawnNationAt(site: Province): Faction | null {
    const W = GAME_CONSTANTS.WORLD;
    const type = this.pickNationType(site.biome);
    const profile = NATION_PROFILES[type];
    const usedColors = new Set(Array.from(this.factions.values()).map(f => f.color.toLowerCase()));
    const color = NATION_COLOR_POOL.find(c => !usedColors.has(c.toLowerCase()))
      ?? NATION_COLOR_POOL[Math.floor(Math.random() * NATION_COLOR_POOL.length)];

    const baseName = NameGenerator.generateCityName(profile.flavor);
    const factionName = profile.factionName(baseName);
    const factionId = this.nextId('faction_spawn');
    const cultureId = this.nextId('culture_spawn');

    // 1. Culture
    const culture: Culture = {
      id: cultureId,
      name: `${profile.cultureLabel} ${baseName}`,
      parentId: null,
      divergenceTurn: this.currentTurn,
      color,
      traits: [...profile.traits],
      isUniqueCulture: true,
      drift: 0
    };
    this.cultures.set(cultureId, culture);
    LanguageSystem.initLanguageForCulture(culture);

    // 2. Ruler (generic generator + type-specific title/traits)
    const ruler = RulerSystem.generateRuler(profile.flavor, 80);
    ruler.title = profile.titles[Math.floor(Math.random() * profile.titles.length)];
    ruler.traits = [...profile.rulerTraits];
    ruler.mainTrait = profile.mainTrait;

    // 3. Faction
    const faction: Faction = {
      id: factionId,
      name: factionName,
      color,
      capitalCityId: null,
      rootCultureId: cultureId,
      isPlayer: false,
      isBreakaway: false,
      gold: W.STARTING_GOLD,
      grain: W.STARTING_GRAIN,
      overextension: 10,
      atWarWith: [],
      ruler,
      isInterregnum: false,
      interregnumTurnsLeft: 0,
      diplomacy: {},
      culturePoints: W.STARTING_CULTURE_POINTS,
      unlockedDogmas: [...profile.dogmas],
      resources: { copper: 1, tin: 1, cattle: 2, incense: 1 },
      tier: profile.tier,
      outposts: [],
      nationType: type
    };
    this.factions.set(factionId, faction);

    // 4. Capital: take over an inhabited rival province (uprising) or settle an empty one
    const previousOwner = site.ownerFactionId ? this.factions.get(site.ownerFactionId) : undefined;
    const startingProvinces: Province[] = [site];
    let capital: City;
    if (site.cityId && this.cities.get(site.cityId)) {
      capital = this.cities.get(site.cityId)!;
      capital.factionId = factionId;
      capital.dominantCultureId = cultureId;
      capital.cultureWeights = { [cultureId]: 1.0 };
      capital.authority = 90;
      capital.population = Math.max(capital.population, 8);
      site.ownerFactionId = factionId;
      site.dominantCultureId = cultureId;
      site.authority = 90;
      site.unrestStage = UnrestStage.INTEGRATED;
      for (const hKey of site.hexKeys) {
        const t = this.tiles.get(hKey);
        if (t) t.ownerFactionId = factionId;
      }
    } else {
      site.ownerFactionId = null; // make sure the helper treats it as free land
      capital = this.foundCityForFaction(site, faction, {
        population: 10,
        authority: 90,
        cityName: `${baseName} (Столица)`
      });
    }
    faction.capitalCityId = capital.id;

    // 5. Two more starting regions: nearest vacant provinces (BFS over province adjacency)
    const seen = new Set<string>([site.id]);
    const queue: Province[] = [site];
    while (queue.length > 0 && startingProvinces.length < W.STARTING_REGIONS) {
      const current = queue.shift()!;
      for (const adj of this.getAdjacentProvinces(current.id)) {
        if (seen.has(adj.id)) continue;
        seen.add(adj.id);
        queue.push(adj);
        if (adj.ownerFactionId === null && adj.biome !== BiomeType.OCEAN && startingProvinces.length < W.STARTING_REGIONS) {
          this.foundCityForFaction(adj, faction, { population: 5, authority: 85 });
          startingProvinces.push(adj);
        }
      }
    }

    // 6. Army
    const armyPlan = profile.army;
    let armyIdx = 0;
    for (const unitType of armyPlan) {
      const home = startingProvinces[armyIdx % startingProvinces.length];
      this.spawnArmyUnit(faction, unitType, home);
      armyIdx++;
    }

    // 7. Diplomacy: everyone starts at peace; a conquered province makes its former owner an enemy
    for (const other of this.factions.values()) {
      if (other.id === factionId) continue;
      faction.diplomacy[other.id] = { status: DiplomaticStatus.PEACE, opinion: 0, pactTurnsLeft: 0 };
      other.diplomacy[factionId] = { status: DiplomaticStatus.PEACE, opinion: 0, pactTurnsLeft: 0 };
    }
    if (previousOwner) {
      faction.atWarWith.push(previousOwner.id);
      previousOwner.atWarWith.push(factionId);
      faction.diplomacy[previousOwner.id] = { status: DiplomaticStatus.WAR, opinion: -80, pactTurnsLeft: 0 };
      previousOwner.diplomacy[factionId] = { status: DiplomaticStatus.WAR, opinion: -80, pactTurnsLeft: 0 };
    }

    // 8. Chronicle
    this.addChronicle(
      profile.chronicle({
        nation: factionName,
        ruler: `${ruler.title} ${ruler.name}`,
        province: site.name,
        regions: startingProvinces.length,
        seized: previousOwner?.name
      }),
      'critical'
    );
    return faction;
  }

  private spawnArmyUnit(faction: Faction, unitType: UnitType, home: Province): void {
    const candidates: HexCoord[] = [];
    const centre = new HexCoord(home.centerQ, home.centerR);
    candidates.push(centre, ...centre.neighbors());
    for (const hKey of home.hexKeys) candidates.push(HexCoord.fromKey(hKey));
    const spot = candidates.find(c => {
      const t = this.tiles.get(c.key);
      return !!t && t.biome !== BiomeType.OCEAN && !t.unitId;
    });
    if (!spot) return;

    const general = NameGenerator.generateLeaderName();
    const id = this.nextId(`unit_${faction.id}`);
    const mounted = unitType === UnitType.HEAVY_CAVALRY || unitType === UnitType.CHARIOT;
    const unit: Unit = {
      id,
      name: `${unitType} ${general}`,
      type: unitType,
      factionId: faction.id,
      q: spot.q,
      r: spot.r,
      hp: 100,
      maxHp: 100,
      movesLeft: mounted ? 4 : 3,
      maxMoves: mounted ? 4 : 3,
      combatStrength: CombatSystem.getBaseStrength(unitType),
      supply: 100,
      isGarrisoned: !!this.tiles.get(spot.key)?.cityId,
      loyalty: 80 + Math.floor(Math.random() * 15),
      generalName: general
    };
    this.units.set(id, unit);
    const tile = this.tiles.get(spot.key);
    if (tile) tile.unitId = id;
  }

  /**
   * Dynamic World Spawner: seeds fresh medieval nations (Knights, Khanates, Empires, Mountain Kingdoms)
   * on fertile river provinces so the map is teeming with states by the Middle Ages.
   * The number of nations scales with how empty the world still is.
   */
  spawnNewMedievalNations(emptyRatio: number = this.getEmptyLandRatio()): Faction[] {
    const W = GAME_CONSTANTS.WORLD;
    const wanted = Math.max(1, Math.min(W.MAX_SPAWN_PER_EVENT, 1 + Math.floor((emptyRatio - W.EMPTY_LAND_THRESHOLD) * 8)));
    const spawned: Faction[] = [];
    const usedSites: HexCoord[] = [];

    for (let i = 0; i < wanted; i++) {
      const site = this.pickSpawnProvince(usedSites);
      if (!site) break;
      const centre = new HexCoord(site.centerQ, site.centerR);
      const faction = this.spawnNationAt(site);
      if (faction) {
        spawned.push(faction);
        usedSites.push(centre);
      }
    }

    if (spawned.length > 0) {
      SupplySystem.updateProvinceSupplyLines(this.provinces, this.cities, this.tiles, this.factions, this.units);
      LogisticsSystem.update(this.cities, this.factions, this.cultures, this.provinces, this.currentTurn);
      EventBus.emit('NATIONS_SPAWNED', { turn: this.currentTurn, factions: spawned, emptyRatio });
    }
    return spawned;
  }
}

type NationProfile = {
  flavor: PhoneticFlavor;
  cultureLabel: string;
  tier: FactionTier;
  mainTrait: RulerTrait;
  dogmas: DogmaId[];
  titles: string[];
  traits: string[];
  rulerTraits: string[];
  army: UnitType[];
  factionName: (base: string) => string;
  chronicle: (d: { nation: string; ruler: string; province: string; regions: number; seized?: string }) => string;
};

const NATION_COLOR_POOL = [
  '#8e44ad', '#16a085', '#c0392b', '#2980b9', '#d35400', '#27ae60',
  '#7f8c8d', '#f39c12', '#1abc9c', '#e84393', '#6c5ce7', '#00cec9'
];

const NATION_PROFILES: Record<NationType, NationProfile> = {
  KNIGHTS: {
    flavor: 'LEVANTINE',
    cultureLabel: 'Рыцарство',
    tier: FactionTier.CHIEFDOM,
    mainTrait: 'CONQUEROR',
    dogmas: [],
    titles: ['Великий Магистр', 'Король-Рыцарь', 'Герцог Марок'],
    traits: ['Рыцарский кодекс', 'Замки на холмах', 'Тяжёлая конница'],
    rulerTraits: ['Рыцарь без страха', 'Покровитель турниров'],
    army: [UnitType.HEAVY_CAVALRY, UnitType.HEAVY_CAVALRY, UnitType.LEGION, UnitType.ARCHERS],
    factionName: base => `Рыцарское Королевство ${base}`,
    chronicle: d => d.seized
      ? `⚔️ ВОССТАНИЕ РЫЦАРЕЙ: Железные бароны провинции «${d.province}» свергли власть «${d.seized}» и провозгласили «${d.nation}»! Под знаменем ${d.ruler} собрано ${d.regions} земель и закованная в сталь конница.`
      : `🏰 РОЖДЕНИЕ КОРОЛЕВСТВА: Среди пустых долин у «${d.province}» поднялись замки — так явилось «${d.nation}»! ${d.ruler} дал клятву верности ${d.regions} землям и созвал первую рыцарскую дружину.`
  },
  KHANATE: {
    flavor: 'STEPPE',
    cultureLabel: 'Кочевая орда',
    tier: FactionTier.CHIEFDOM,
    mainTrait: 'CONQUEROR',
    dogmas: [DogmaId.NOMADIC_LIFESTYLE],
    titles: ['Великий Хан', 'Каган Степей', 'Тархан Орды'],
    traits: ['Конные лучники', 'Курултай кланов', 'Кочевой уклад'],
    rulerTraits: ['Покоритель степей', 'Неутомимый наездник'],
    army: [UnitType.HEAVY_CAVALRY, UnitType.HEAVY_CAVALRY, UnitType.CHARIOT, UnitType.ARCHERS],
    factionName: base => `Ханство ${base}`,
    chronicle: d => d.seized
      ? `🐎 ОРДА ПРОБУДИЛАСЬ: Кочевые кланы у «${d.province}» вырвали степь из рук «${d.seized}» — над юртами реет бунчук «${d.nation}»! ${d.ruler} ведёт ${d.regions} кочевья.`
      : `🌾 КУРУЛТАЙ В СТЕПИ: Под дым костров возле «${d.province}» кланы избрали хана — родилось «${d.nation}»! ${d.ruler} объединил ${d.regions} кочевья и поднял тысячи всадников.`
  },
  EMPIRE: {
    flavor: 'MESOPOTAMIAN',
    cultureLabel: 'Имперская культура',
    tier: FactionTier.EARLY_STATE,
    mainTrait: 'BUILDER',
    dogmas: [],
    titles: ['Император', 'Базилевс', 'Великий Цезарь'],
    traits: ['Имперская бюрократия', 'Мощёные дороги', 'Единый кодекс законов'],
    rulerTraits: ['Законодатель', 'Строитель дорог'],
    army: [UnitType.LEGION, UnitType.LEGION, UnitType.ARCHERS, UnitType.SPEARMEN],
    factionName: base => `Империя ${base}`,
    chronicle: d => d.seized
      ? `👑 ИМПЕРСКИЙ ПЕРЕВОРОТ: Наместник «${d.province}» отверг власть «${d.seized}» и возложил на себя венец — так возникла «${d.nation}»! ${d.ruler} правит ${d.regions} областями.`
      : `🏛️ ВОЗВЫШЕНИЕ ИМПЕРИИ: На плодородных берегах у «${d.province}» поднялся новый центр цивилизации — «${d.nation}»! ${d.ruler} венчан на царство; ${d.regions} области уже платят подати.`
  },
  MOUNTAIN_KINGDOM: {
    flavor: 'ELAMITE',
    cultureLabel: 'Горный клан',
    tier: FactionTier.CHIEFDOM,
    mainTrait: 'BUILDER',
    dogmas: [DogmaId.ANCESTOR_CULT],
    titles: ['Король Гор', 'Верховный Тан', 'Хранитель Перевалов'],
    traits: ['Крепости ущелий', 'Культ предков', 'Горные стрелки'],
    rulerTraits: ['Хранитель перевалов', 'Сын камня'],
    army: [UnitType.SPEARMEN, UnitType.SPEARMEN, UnitType.ARCHERS, UnitType.LEGION],
    factionName: base => `Горное Королевство ${base}`,
    chronicle: d => d.seized
      ? `⛰️ ГОРЦЫ СПУСТИЛИСЬ С ПЕРЕВАЛОВ: Кланы «${d.province}» изгнали людей «${d.seized}» и основали «${d.nation}»! ${d.ruler} занял ${d.regions} горных долины.`
      : `⛰️ ГОРНЫЙ ТРОН: В холмах над «${d.province}» зажглись сигнальные огни — родилось «${d.nation}»! ${d.ruler} удерживает ${d.regions} долины и неприступные ущелья.`
  }
};
