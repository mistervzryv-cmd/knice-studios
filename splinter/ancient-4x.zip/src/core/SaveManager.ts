import type { GameState } from './GameState.ts';
import { EventBus } from './EventBus.ts';
import { SupplySystem } from '../simulation/SupplySystem.ts';
import { LogisticsSystem } from '../simulation/LogisticsSystem.ts';
import { HistoricalAge, MapOverlayMode, StarterCultureChoice } from '../entities/Types.ts';

const SAVE_STORAGE_KEY = 'ancient4x_saved_game_v1';

export interface SavedGameData {
  version: number;
  currentTurn: number;
  age: HistoricalAge;
  currentCrisis: any | null;
  selectedStarter: StarterCultureChoice;
  mode: string;
  overlayMode: MapOverlayMode;
  eventLogs: { turn: number; text: string; type: string }[];
  chroniclesOfAges?: { turn: number; year: string; text: string; type: string }[];
  victoryState?: any;
  factions: [string, any][];
  provinces: [string, any][];
  cities: [string, any][];
  units: [string, any][];
  cultures: [string, any][];
  tiles: [string, any][];
  timestamp: number;
}

export class SaveManager {
  /**
   * Save the current state to browser localStorage
   */
  static saveGame(state: GameState): boolean {
    if (!state) return false;
    try {
      const data: SavedGameData = {
        version: 1,
        currentTurn: state.currentTurn,
        age: state.age,
        currentCrisis: state.currentCrisis,
        selectedStarter: state.selectedStarter,
        mode: state.mode,
        overlayMode: state.overlayMode,
        eventLogs: state.eventLogs,
        factions: Array.from(state.factions.entries()),
        provinces: Array.from(state.provinces.entries()),
        cities: Array.from(state.cities.entries()),
        units: Array.from(state.units.entries()),
        cultures: Array.from(state.cultures.entries()),
        tiles: Array.from(state.tiles.entries()),
        timestamp: Date.now()
      };

      const serialized = JSON.stringify(data);
      localStorage.setItem(SAVE_STORAGE_KEY, serialized);
      console.log(`[SaveManager] Autosaved game state at turn ${state.currentTurn} (${(serialized.length / 1024).toFixed(1)} KB)`);
      return true;
    } catch (err) {
      console.error('[SaveManager] Failed to save game state to localStorage:', err);
      return false;
    }
  }

  /**
   * Load the saved state from browser localStorage into the provided GameState
   */
  static loadGame(state: GameState): boolean {
    if (!state) return false;
    try {
      const raw = localStorage.getItem(SAVE_STORAGE_KEY);
      if (!raw) {
        console.warn('[SaveManager] No saved game found in localStorage');
        return false;
      }

      const data: SavedGameData = JSON.parse(raw);
      if (!data.factions || !data.provinces || !data.tiles) {
        console.error('[SaveManager] Corrupted save game format');
        return false;
      }

      state.currentTurn = data.currentTurn ?? 1;
      state.age = data.age ?? HistoricalAge.STONE_TOOLS;
      state.currentCrisis = data.currentCrisis ?? null;
      state.selectedStarter = data.selectedStarter ?? 'RIVER_FARMERS';
      state.mode = 'PLAYING';
      state.overlayMode = data.overlayMode ?? MapOverlayMode.POLITICAL;
      state.eventLogs = data.eventLogs ?? [];

      state.factions = new Map(data.factions);
      state.provinces = new Map(data.provinces);
      state.cities = new Map(data.cities);
      state.units = new Map(data.units);
      state.cultures = new Map(data.cultures);
      state.tiles = new Map(data.tiles);

      // Re-run supply calculation & logistics
      SupplySystem.updateProvinceSupplyLines(state.provinces, state.cities, state.tiles, state.factions, state.units);
      LogisticsSystem.update(state.cities, state.factions, state.cultures, state.provinces, state.currentTurn);

      // Notify systems of restored game
      EventBus.emit('GAME_MODE_CHANGED', { mode: state.mode });
      EventBus.emit('TURN_CHANGED', { turn: state.currentTurn });

      console.log(`[SaveManager] Successfully restored game at turn ${state.currentTurn}`);
      return true;
    } catch (err) {
      console.error('[SaveManager] Failed to load game from localStorage:', err);
      return false;
    }
  }

  /**
   * Check if a valid save exists in localStorage
   */
  static hasSavedGame(): boolean {
    try {
      const raw = localStorage.getItem(SAVE_STORAGE_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw);
      return !!(data && data.factions && data.provinces && data.currentTurn);
    } catch {
      return false;
    }
  }

  /**
   * Get metadata about the saved game without full deserialization
   */
  static getSavedGameMeta(): { turn: number; age: string; timestamp: number } | null {
    try {
      const raw = localStorage.getItem(SAVE_STORAGE_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      return {
        turn: data.currentTurn,
        age: data.age,
        timestamp: data.timestamp
      };
    } catch {
      return null;
    }
  }

  /**
   * Clear the saved game
   */
  static clearSavedGame(): void {
    try {
      localStorage.removeItem(SAVE_STORAGE_KEY);
    } catch (err) {
      console.error('[SaveManager] Failed to clear save game:', err);
    }
  }
}
