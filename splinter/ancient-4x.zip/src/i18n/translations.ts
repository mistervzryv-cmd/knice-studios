// src/i18n/translations.ts - Complete Russian and English Localization Dictionary & Manager

export type Language = 'ru' | 'en';

export const TRANSLATIONS = {
  ru: {
    // Start Menu
    gameTitle: "РАСКОЛ ДРЕВНИХ ИМПЕРИЙ",
    gameSubtitle: "Глобальная 4X-стратегия на гексагональной карте Земли • Эпоха Бронзового Века",
    chooseCultureTitle: "Выберите стартовую культуру вашего народа:",
    startGameBtn: "👑 Основать Цивилизацию",
    continueGameBtn: "▶️ Продолжить игру",
    continueTurn: "Ход",

    // Culture 1: River Farmers
    riverFarmersTitle: "Речные Земледельцы",
    riverFarmersRegion: "Междуречье Тигра и Евфрата (Шумер)",
    riverFarmersPerk: "✨ Бонус: Ирригационная экспансия",
    riverFarmersDesc: "Мастера искусственного орошения и строительства каналов. Получают +15% к плодородию и ускоренный демографический рост во всех речных провинциях.",
    riverFarmersTrait1: "📜 Храмовые амбары и учет запасов",
    riverFarmersTrait2: "🌾 Пассивная экспансия по долинам рек",
    riverFarmersTrait3: "🏛️ Основатели древнейшей клинописи",

    // Culture 2: Steppe Nomads
    steppeNomadsTitle: "Степные Кочевники",
    steppeNomadsRegion: "Великая Евразийская Степь (Скифия)",
    steppeNomadsPerk: "✨ Бонус: Всадники без границ",
    steppeNomadsDesc: "Неукротимые скотоводы и конные стрелки. Полностью игнорируют штрафы передвижения по засушливым степям и пустыням, даруя армиям +1 к скорости.",
    steppeNomadsTrait1: "🐎 Игнорирование штрафов степей и пустынь",
    steppeNomadsTrait2: "🏹 Стремительные конные разъезды",
    steppeNomadsTrait3: "⛺ Высокая лояльность пограничных кочевий",

    // Culture 3: Mountain Totemists
    mountainTotemistsTitle: "Горные Тотемисты",
    mountainTotemistsRegion: "Нагорья Загроса и Элама",
    mountainTotemistsPerk: "✨ Бонус: Монолитное Единство",
    mountainTotemistsDesc: "Хранители священных горных вершин и древней металлургии. Обладают повышенной сплоченностью (+25% Cohesion) в холмах и горах, замедляя раскол империи.",
    mountainTotemistsTrait1: "⛰️ Высокая сплоченность и защита в горах",
    mountainTotemistsTrait2: "🛡️ Неприступные цитадели ущелий",
    mountainTotemistsTrait3: "🔥 Древние тайны выплавки бронзы",

    // Top HUD
    renameFactionTitle: "Переименовать государство",
    renamePrompt: "Введите новое название вашего государства:",
    bce: "до н.э.",
    ageYears: "г.",
    tierLabel: "Тир:",
    evolutionLabel: "Эволюция:",
    legitimacyLabel: "⚖️ Легитимность:",
    interregnumBadge: "⚠️ СМУТА",
    crisisBadge: "⚡ КРИЗИС",
    culturePointsLabel: "📜 Очки Культуры:",
    burdenLabel: "⚠️ Бремя:",
    btnBorders: "🏛️ Границы",
    btnCultures: "📜 Культуры",
    btnUnrest: "⚖️ Власть / Бунты",
    btnTraditions: "📜 Традиции",
    btnResearchLab: "🔬 Лаборатория",
    btnPolitics: "⚖️ Политика",
    btnTaxRate: "💰 Налоги",
    btnMigration: "🚶 Миграция",
    btnDiplomacy: "🤝 Дипломатия",
    btnCultureTree: "🌳 Древо",
    btnEndTurn: "Завершить ход ➔",
    langToggle: "🌐 RU",
    tierTooltip: "Культурный Тир вашей державы: Дикое Племя (1) -> Вождество (2) -> Цивилизация (3) -> Великая Империя (4)",
    evolutionTooltip: "Условия эволюции: накопление Очков Культуры и удержание стабильных провинций (Cohesion >= 70%)",
    resourcesTooltip: "Стратегические ресурсы: Медь, Олово, Скот, Благовония",

    // Inspector & Chronicles
    chroniclesTitle: "Хроники событий",
    inspectorPlaceholder: "Кликните на гекс, город или армию для осмотра",
    inspectorProvince: "Провинция",
    inspectorOwner: "Владелец",
    inspectorBiome: "Биом",
    inspectorFertility: "Плодородие",
    inspectorCohesion: "Сплоченность",
    inspectorAuthority: "Власть",
    inspectorSupplyStatus: "Линия снабжения",
    inspectorSupplyConnected: "✅ Активна (прямая связь со столицей)",
    inspectorSupplyCut: "❌ ПЕРЕРЕЗАНА (Изоляция, 3x штраф Cohesion)",
    inspectorMountainRefuge: "⛰️ Горное убежище (высокая обособленность)",
    inspectorNoOwner: "Ничейные земли",

    // Annexation Menu
    annexTitle: "Провинция",
    annexInstant: "✅ Присоединить регион",
    annexOutpost: "⛺ Построить аванпост",
    annexTooltipExpandable: "Доступно для присоединения!",
    annexTooltipCost: "Стоимость",
    annexTooltipIsolated: "⚠️ Изолировано от снабжения! 3x штраф к стоимости",
    annexTooltipRefuge: "⛰️ Горное убежище / Пустыня (3x цена)",
    annexTooltipTurns: "ходов мирного освоения",

    // Traditions Modal
    traditionsTitle: "📜 Религия и Традиции Народа",
    traditionsSubtitle: "Утверждайте священные догматы за накопленные Очки Культуры",
    traditionsBalance: "Баланс Очков Культуры:",
    traditionsCostInfo: "(Стоимость догмата: 75 очков)",
    btnAdoptDogma: "Утвердить догмат (75 📜)",
    dogmaAdopted: "Утверждено",
    btnClose: "Закрыть",

    // Migration Modal
    migrationTitle: "🚶 Великое Переселение Народов",
    migrationDesc: "Если ваши земли истощены или империя рушится, снимите свой народ с обжитых мест и отправьтесь в поход за новыми плодородными долинами.",
    migrationStep1: "1. Выберите провинцию исхода:",
    migrationStep2: "2. Выберите вектор миграции (пустую соседнюю провинцию):",
    btnStartMigration: "🚶 Начать Миграцию",

    // Diplomacy Modal
    diplomacyTitle: "🤝 Дворец Дипломатии и Переговоров",
    diplomacySubtitle: "Отношения с соседними державами Древнего Мира",
    diploDeclareWar: "⚔️ Объявить войну",
    diploOfferPact: "🤝 Пакт о ненападении",
    diploTrade: "⚖️ Обменять",
    diploTradeGive: "Торговля: Отдать 2 ед.",
    diploTradeGet: "➔ Получить 2 ед.",
    diploWarStatus: "ВОЙНА",
    diploPactStatus: "ПАКТ",
    diploNeutralStatus: "НЕЙТРАЛИТЕТ",

    // Evolution Modal
    evolutionModalTitle: "🌟 КУЛЬТУРНАЯ ТРАНСФОРМАЦИЯ!",
    evolutionModalSubtitle: "Ваша культура эволюционировала в новый статус!",
    evolutionContinueBtn: "👑 Во славу нашего народа!",

    // Historical Ages
    age_STONE_TOOLS: "Эпоха Орудий",
    age_BRONZE_DAWN: "Рассвет Бронзы",
    age_CHARIOT_ERA: "Эпоха Колесниц",
    age_BRONZE_COLLAPSE: "Катастрофа Бронзового Века",
    age_IRON_REBIRTH: "Железное Возрождение",

    // Crises
    crisis_SEA_PEOPLES: "Нашествие Народов Моря",
    crisis_GREAT_DROUGHT: "Великая Мегазасуха",
    crisis_SYSTEMIC_COLLAPSE: "Системный Коллапс Торговли",

    // Faction Tiers
    tier_WILD_TRIBE: "Дикое Племя",
    tier_CHIEFDOM: "Вождество",
    tier_CIVILIZATION: "Цивилизация",
    tier_GREAT_EMPIRE: "Великая Империя",

    // Ruler Traits
    trait_CONQUEROR: "Завоеватель",
    trait_BUILDER: "Зодчий",
    trait_DIPLOMAT: "Дипломат",
    trait_TYRANT: "Тиран",
    trait_THEOCRAT: "Жрец",
    trait_WEAK: "Слабый",

    // Biomes
    biome_OCEAN: "Океан",
    biome_RIVER_VALLEY: "Речная Долина",
    biome_FERTILE_PLAINS: "Плодородная Равнина",
    biome_STEPPE: "Степь",
    biome_FOREST: "Лес",
    biome_HILLS: "Холмы",
    biome_MOUNTAINS: "Горы",
    biome_DESERT: "Пустыня"
  },

  en: {
    // Start Menu
    gameTitle: "FALL OF ANCIENT EMPIRES",
    gameSubtitle: "Grand 4X Strategy on Earth Hexagonal Map • Bronze Age Era",
    chooseCultureTitle: "Choose your civilization's starting culture:",
    startGameBtn: "👑 Found Civilization",
    continueGameBtn: "▶️ Continue Game",
    continueTurn: "Turn",

    // Culture 1: River Farmers
    riverFarmersTitle: "River Farmers",
    riverFarmersRegion: "Tigris & Euphrates Basin (Sumer)",
    riverFarmersPerk: "✨ Bonus: Irrigation Expansion",
    riverFarmersDesc: "Masters of artificial irrigation and canal engineering. Gain +15% fertility and accelerated population growth across all river provinces.",
    riverFarmersTrait1: "📜 Temple granaries and surplus accounting",
    riverFarmersTrait2: "🌾 Passive expansion along river basins",
    riverFarmersTrait3: "🏛️ Pioneers of earliest cuneiform script",

    // Culture 2: Steppe Nomads
    steppeNomadsTitle: "Steppe Nomads",
    steppeNomadsRegion: "Great Eurasian Steppe (Scythia)",
    steppeNomadsPerk: "✨ Bonus: Boundless Riders",
    steppeNomadsDesc: "Indomitable herdsmen and horse archers. Completely ignore terrain movement penalties in arid steppes and deserts, granting +1 army speed.",
    steppeNomadsTrait1: "🐎 Ignore penalties in steppes & deserts",
    steppeNomadsTrait2: "🏹 Swift horse archer skirmishers",
    steppeNomadsTrait3: "⛺ High loyalty of nomadic border encampments",

    // Culture 3: Mountain Totemists
    mountainTotemistsTitle: "Mountain Totemists",
    mountainTotemistsRegion: "Zagros & Elam Highlands",
    mountainTotemistsPerk: "✨ Bonus: Monolithic Unity",
    mountainTotemistsDesc: "Keepers of sacred summits and ancient metallurgy. Possess enhanced cohesion (+25%) in hills and mountains, resisting imperial collapse.",
    mountainTotemistsTrait1: "⛰️ High cohesion and defensive mountain bastions",
    mountainTotemistsTrait2: "🛡️ Impregnable mountain gorges & fortresses",
    mountainTotemistsTrait3: "🔥 Ancient secrets of bronze smelting",

    // Top HUD
    renameFactionTitle: "Rename Faction",
    renamePrompt: "Enter new name for your realm:",
    bce: "BCE",
    ageYears: "yrs",
    tierLabel: "Tier:",
    evolutionLabel: "Evolution:",
    legitimacyLabel: "⚖️ Legitimacy:",
    interregnumBadge: "⚠️ INTERREGNUM",
    crisisBadge: "⚡ CRISIS",
    culturePointsLabel: "📜 Culture Points:",
    burdenLabel: "⚠️ Burden:",
    btnBorders: "🏛️ Borders",
    btnCultures: "📜 Cultures",
    btnUnrest: "⚖️ Unrest / Power",
    btnTraditions: "📜 Traditions",
    btnResearchLab: "🔬 Research Lab",
    btnPolitics: "⚖️ Politics",
    btnTaxRate: "💰 Taxes",
    btnMigration: "🚶 Migration",
    btnDiplomacy: "🤝 Diplomacy",
    btnCultureTree: "🌳 Tree",
    btnEndTurn: "Next Turn ➔",
    langToggle: "🌐 EN",
    tierTooltip: "Realm Tier: Wild Tribe (1) -> Chiefdom (2) -> Civilization (3) -> Great Empire (4)",
    evolutionTooltip: "Evolution requirements: Accumulate Culture Points & maintain stable provinces (Cohesion >= 70%)",
    resourcesTooltip: "Strategic Resources: Copper, Tin, Cattle, Incense",

    // Inspector & Chronicles
    chroniclesTitle: "Event Chronicles",
    inspectorPlaceholder: "Click any hex, city, or army to inspect",
    inspectorProvince: "Province",
    inspectorOwner: "Owner",
    inspectorBiome: "Biome",
    inspectorFertility: "Fertility",
    inspectorCohesion: "Cohesion",
    inspectorAuthority: "Authority",
    inspectorSupplyStatus: "Supply Line",
    inspectorSupplyConnected: "✅ Connected (direct link to capital)",
    inspectorSupplyCut: "❌ SEVERED (Isolated, 3x Cohesion penalty)",
    inspectorMountainRefuge: "⛰️ Mountain Refuge (high seclusion)",
    inspectorNoOwner: "Unclaimed Lands",

    // Annexation Menu
    annexTitle: "Province",
    annexInstant: "✅ Annex Region",
    annexOutpost: "⛺ Build Outpost",
    annexTooltipExpandable: "Available for annexation!",
    annexTooltipCost: "Cost",
    annexTooltipIsolated: "⚠️ Isolated from supply line! 3x cost penalty",
    annexTooltipRefuge: "⛰️ Mountain Refuge / Desert (3x cost)",
    annexTooltipTurns: "turns for peaceful settlement",

    // Traditions Modal
    traditionsTitle: "📜 Religion & Sacred Traditions",
    traditionsSubtitle: "Adopt holy dogmas with accumulated Culture Points",
    traditionsBalance: "Culture Points Balance:",
    traditionsCostInfo: "(Dogma cost: 75 pts)",
    btnAdoptDogma: "Adopt Dogma (75 📜)",
    dogmaAdopted: "Adopted",
    btnClose: "Close",

    // Migration Modal
    migrationTitle: "🚶 Great Migration of Peoples",
    migrationDesc: "When soils are depleted or collapse looms, lead your people on a trek across wild lands to settle fertile valleys.",
    migrationStep1: "1. Choose province of origin:",
    migrationStep2: "2. Choose migration vector (adjacent empty province):",
    btnStartMigration: "🚶 Begin Migration",

    // Diplomacy Modal
    diplomacyTitle: "🤝 Palace of Diplomacy & Emissaries",
    diplomacySubtitle: "Foreign relations with neighboring Bronze Age powers",
    diploDeclareWar: "⚔️ Declare War",
    diploOfferPact: "🤝 Non-Aggression Pact",
    diploTrade: "⚖️ Exchange",
    diploTradeGive: "Trade: Offer 2 units",
    diploTradeGet: "➔ Receive 2 units",
    diploWarStatus: "WAR",
    diploPactStatus: "PACT",
    diploNeutralStatus: "NEUTRAL",

    // Evolution Modal
    evolutionModalTitle: "🌟 CULTURAL TRANSFORMATION!",
    evolutionModalSubtitle: "Your culture has evolved into a new stage!",
    evolutionContinueBtn: "👑 For the glory of our people!",

    // Historical Ages
    age_STONE_TOOLS: "Age of Stone Tools",
    age_BRONZE_DAWN: "Dawn of Bronze",
    age_CHARIOT_ERA: "Age of Chariots",
    age_BRONZE_COLLAPSE: "Bronze Age Collapse",
    age_IRON_REBIRTH: "Iron Age Rebirth",

    // Crises
    crisis_SEA_PEOPLES: "Invasion of the Sea Peoples",
    crisis_GREAT_DROUGHT: "Great Mega-Drought",
    crisis_SYSTEMIC_COLLAPSE: "Systemic Trade Collapse",

    // Faction Tiers
    tier_WILD_TRIBE: "Wild Tribe",
    tier_CHIEFDOM: "Chiefdom",
    tier_CIVILIZATION: "Civilization",
    tier_GREAT_EMPIRE: "Great Empire",

    // Ruler Traits
    trait_CONQUEROR: "Conqueror",
    trait_BUILDER: "Builder",
    trait_DIPLOMAT: "Diplomat",
    trait_TYRANT: "Tyrant",
    trait_THEOCRAT: "Theocrat",
    trait_WEAK: "Weak",

    // Biomes
    biome_OCEAN: "Ocean",
    biome_RIVER_VALLEY: "River Valley",
    biome_FERTILE_PLAINS: "Fertile Plains",
    biome_STEPPE: "Steppe",
    biome_FOREST: "Forest",
    biome_HILLS: "Hills",
    biome_MOUNTAINS: "Mountains",
    biome_DESERT: "Desert"
  }
};

let currentLanguage: Language = 'ru';

export function initLanguage(): Language {
  try {
    const saved = localStorage.getItem('ancient4x_lang') as Language;
    if (saved === 'ru' || saved === 'en') {
      currentLanguage = saved;
    } else {
      const navLang = (navigator.language || '').toLowerCase();
      currentLanguage = navLang.startsWith('ru') ? 'ru' : 'en';
    }
  } catch {
    currentLanguage = 'ru';
  }
  applyLanguageToDOM(currentLanguage);
  return currentLanguage;
}

export function getCurrentLanguage(): Language {
  return currentLanguage;
}

export function setLanguage(lang: Language): void {
  currentLanguage = lang;
  try {
    localStorage.setItem('ancient4x_lang', lang);
  } catch (e) {
    console.warn('Could not save language to localStorage', e);
  }
  applyLanguageToDOM(lang);
}

export function toggleLanguage(): Language {
  const nextLang: Language = currentLanguage === 'ru' ? 'en' : 'ru';
  setLanguage(nextLang);
  return nextLang;
}

export function t(key: string, fallback?: string): string {
  const dict = TRANSLATIONS[currentLanguage] as Record<string, any>;
  if (dict && dict[key] !== undefined) {
    return dict[key];
  }
  // Try English fallback
  const enDict = TRANSLATIONS['en'] as Record<string, any>;
  if (enDict && enDict[key] !== undefined) {
    return enDict[key];
  }
  return fallback || key;
}

export function applyLanguageToDOM(lang: Language): void {
  document.documentElement.lang = lang;
  const dict = TRANSLATIONS[lang] as Record<string, any>;

  // Update elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (key && dict[key]) {
      el.textContent = dict[key];
    }
  });

  // Update elements with data-i18n-title
  document.querySelectorAll('[data-i18n-title]').forEach((el) => {
    const key = el.getAttribute('data-i18n-title');
    if (key && dict[key]) {
      el.setAttribute('title', dict[key]);
    }
  });

  // Update language toggle button text
  const langToggleBtn = document.getElementById('btn-lang-toggle');
  if (langToggleBtn) {
    langToggleBtn.textContent = lang === 'ru' ? '🌐 RU' : '🌐 EN';
  }
}
