// User Interface Manager: Top HUD, Inspector, Chronicles, Naming Ratification, Cultural Tree, Start Menu, Traditions, Migration & Diplomacy
import { GameState } from '../core/GameState.ts';
import {
  MapOverlayMode,
  UnitType,
  UnrestStage,
  StarterCultureChoice,
  DiplomaticStatus,
  GameMode,
  DogmaId,
  HistoricalAge,
  ResourceStockpile,
  RulerTrait,
  Province,
  HexTile,
  FactionTier,
  BiomeType,
  PoliticalRegime,
  VictoryType
} from '../entities/Types.ts';
import { EventBus } from '../core/EventBus.ts';
import { SecessionSystem } from '../simulation/SecessionSystem.ts';
import { NameGenerator } from '../utils/NameGenerator.ts';
import { t, toggleLanguage, getCurrentLanguage, TRANSLATIONS } from '../i18n/translations.ts';
import { SaveManager } from '../core/SaveManager.ts';
import { LANGUAGE_TECHS, LanguageTech } from '../simulation/LanguageSystem.ts';
import { RESEARCH_TECHS, Technology } from '../simulation/ResearchSystem.ts';
import { QuestEvent } from '../simulation/QuestSystem.ts';

export class UIManager {
  private state: GameState;
  private onRenderRequest: () => void;
  private pendingSettlerUnitId: string | null = null;
  private selectedStarter: StarterCultureChoice = 'RIVER_FARMERS';
  private selectedMigrationProvinceId: string | null = null;
  private activeAnnexProvinceId: string | null = null;

  constructor(state: GameState, onRenderRequest: () => void) {
    this.state = state;
    this.onRenderRequest = onRenderRequest;
    this.setupListeners();
    this.setupModals();
    this.setupFloatingAnnexMenu();
    this.setupEvolutionModal();
    this.setupTraditions();
    this.setupMigration();
    this.setupStartMenu();
    this.setupDiplomacy();
    this.setupResearchLab();
    this.setupPolitics();
    this.setupVictoryModal();
    this.setupQuestModal();
    this.updateHUD();
    this.updateInspector();
    this.updateChronicles();
    this.applyGameMode(this.state.mode);
  }

  private setupListeners(): void {
    // End Turn Button
    const endTurnBtn = document.getElementById('btn-end-turn');
    if (endTurnBtn) {
      endTurnBtn.addEventListener('click', () => {
        if (this.state.mode !== 'PLAYING') return;
        this.state.endTurn();
        this.updateHUD();
        this.updateInspector();
        this.updateChronicles();
        this.checkSecessionModal();
        this.onRenderRequest();
      });
    }

    // Language Switcher Button (RU / EN)
    const langBtn = document.getElementById('btn-lang-toggle');
    if (langBtn) {
      langBtn.addEventListener('click', () => {
        toggleLanguage();
        this.updateHUD();
        this.updateInspector();
        this.updateChronicles();
        this.updateStartMenuCultureCards();
        this.onRenderRequest();
      });
    }

    // Overlay Buttons
    const overlayBtns = document.querySelectorAll('.overlay-btn');
    overlayBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const target = e.currentTarget as HTMLElement;
        const mode = target.dataset.mode as MapOverlayMode;
        if (mode) {
          this.state.overlayMode = mode;
          overlayBtns.forEach(b => b.classList.remove('active'));
          target.classList.add('active');
          this.onRenderRequest();
        }
      });
    });

    // Spacebar to end turn
    window.addEventListener('keydown', (e) => {
      // Don't trigger if typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      if (e.code === 'Space' && this.state.mode === 'PLAYING' && !this.state.activeSecessionModal) {
        this.state.endTurn();
        this.updateHUD();
        this.updateInspector();
        this.updateChronicles();
        this.checkSecessionModal();
        this.onRenderRequest();
      }
    });

    EventBus.on('TURN_CHANGED', () => {
      this.updateHUD();
      this.updateInspector();
      this.updateChronicles();
      this.checkSecessionModal();
    });

    EventBus.on('GAME_MODE_CHANGED', ({ mode }: { mode: GameMode }) => {
      this.applyGameMode(mode);
    });

    EventBus.on('DIPLOMACY_UPDATED', () => {
      this.renderDiplomacy();
      this.updateHUD();
    });

    EventBus.on('AGE_TRANSITIONED', () => {
      this.updateHUD();
      this.updateChronicles();
    });

    EventBus.on('GLOBAL_CRISIS_STARTED', () => {
      this.updateHUD();
      this.updateChronicles();
    });

    EventBus.on('GLOBAL_CRISIS_ENDED', () => {
      this.updateHUD();
      this.updateChronicles();
    });

    EventBus.on('CIVIL_WAR_TRIGGERED', () => {
      this.updateHUD();
      this.updateInspector();
      this.updateChronicles();
      this.checkSecessionModal();
      this.onRenderRequest();
    });

    EventBus.on('DOGMA_UNLOCKED', () => {
      this.renderTraditions();
      this.updateHUD();
    });

    EventBus.on('TRADE_DEAL_COMPLETED', () => {
      this.renderDiplomacy();
      this.updateHUD();
    });

    EventBus.on('MIGRATION_STARTED', () => {
      this.updateHUD();
      this.updateInspector();
      this.updateChronicles();
      this.onRenderRequest();
    });

    EventBus.on('MIGRATION_SETTLED', () => {
      this.updateHUD();
      this.updateInspector();
      this.updateChronicles();
      this.onRenderRequest();
    });

    EventBus.on('FACTION_EVOLVED', (data: any) => {
      this.showEvolutionModal(data);
      this.updateHUD();
      this.updateChronicles();
      this.onRenderRequest();
    });

    EventBus.on('PROVINCE_ANNEXED', () => {
      this.updateHUD();
      this.updateInspector();
      this.updateChronicles();
      this.onRenderRequest();
    });

    EventBus.on('OUTPOST_BUILT', () => {
      this.updateHUD();
      this.updateInspector();
      this.updateChronicles();
      this.onRenderRequest();
    });
  }

  private setupModals(): void {
    // 1. Rename Faction Modal
    const renameBtn = document.getElementById('btn-rename-faction');
    const renameModal = document.getElementById('rename-modal');
    const factionInput = document.getElementById('input-faction-name') as HTMLInputElement;
    const factionReroll = document.getElementById('btn-faction-reroll');
    const renameConfirm = document.getElementById('btn-rename-confirm');
    const renameCancel = document.getElementById('btn-rename-cancel');

    if (renameBtn && renameModal && factionInput) {
      renameBtn.addEventListener('click', () => {
        const player = this.state.getPlayerFaction();
        if (player) {
          factionInput.value = player.name;
          renameModal.classList.remove('hidden');
        }
      });

      factionReroll?.addEventListener('click', () => {
        factionInput.value = NameGenerator.generateFactionName();
      });

      renameConfirm?.addEventListener('click', () => {
        const player = this.state.getPlayerFaction();
        if (player && factionInput.value.trim()) {
          const oldName = player.name;
          player.name = factionInput.value.trim();
          this.state.addLog(`Государство утвердило новое имя: «${player.name}» (ранее: ${oldName}).`, 'info');
          this.updateHUD();
          this.onRenderRequest();
        }
        renameModal.classList.add('hidden');
      });

      renameCancel?.addEventListener('click', () => {
        renameModal.classList.add('hidden');
      });
    }

    // 2. City Founding Modal
    const foundModal = document.getElementById('found-city-modal');
    const cityInput = document.getElementById('input-city-name') as HTMLInputElement;
    const cityReroll = document.getElementById('btn-city-reroll');
    const cityConfirm = document.getElementById('btn-city-confirm');
    const cityCancel = document.getElementById('btn-city-cancel');

    cityReroll?.addEventListener('click', () => {
      if (cityInput) cityInput.value = NameGenerator.generateCityName();
    });

    cityConfirm?.addEventListener('click', () => {
      if (this.pendingSettlerUnitId && cityInput && cityInput.value.trim()) {
        const name = cityInput.value.trim();
        this.state.foundCityWithSettler(this.pendingSettlerUnitId, name);
        this.pendingSettlerUnitId = null;
        foundModal?.classList.add('hidden');
        this.updateHUD();
        this.updateInspector();
        this.onRenderRequest();
      }
    });

    cityCancel?.addEventListener('click', () => {
      this.pendingSettlerUnitId = null;
      foundModal?.classList.add('hidden');
    });

    // 3. Cultural Tree & Chronicles of Ages Modal
    const treeBtn = document.getElementById('btn-culture-tree');
    const treeModal = document.getElementById('culture-tree-modal');
    const treeClose = document.getElementById('btn-tree-close');

    const tabTree = document.getElementById('tab-btn-tree');
    const tabAges = document.getElementById('tab-btn-ages');
    const panelTree = document.getElementById('tab-panel-tree');
    const panelAges = document.getElementById('tab-panel-ages');

    tabTree?.addEventListener('click', () => {
      tabTree.classList.add('active');
      tabAges?.classList.remove('active');
      panelTree?.classList.remove('hidden');
      panelAges?.classList.add('hidden');
      this.renderCultureTree();
    });

    tabAges?.addEventListener('click', () => {
      tabAges.classList.add('active');
      tabTree?.classList.remove('active');
      panelAges?.classList.remove('hidden');
      panelTree?.classList.add('hidden');
      this.renderChroniclesOfAges();
    });

    treeBtn?.addEventListener('click', () => {
      this.renderCultureTree();
      this.renderChroniclesOfAges();
      treeModal?.classList.remove('hidden');
    });

    treeClose?.addEventListener('click', () => {
      treeModal?.classList.add('hidden');
    });
  }

  renderCultureTree(): void {
    const container = document.getElementById('tree-container');
    if (!container) return;

    const cultures = Array.from(this.state.cultures.values());
    const roots = cultures.filter(c => !c.parentId);

    let html = '';
    for (const root of roots) {
      const rootCities = Array.from(this.state.cities.values()).filter(c => c.dominantCultureId === root.id);
      const rootPop = rootCities.reduce((sum, c) => sum + c.population, 0);

      html += `<div class="tree-node" style="border-left-color: ${root.color}">
        <h4>
          <span style="color: ${root.color}">●</span> ${root.name} 
          <span style="font-size:0.75rem; color:#f1c40f;">(Пра-культура)</span>
        </h4>
        <div class="traits">📜 Традиции: ${root.traits.join(', ')} | Городов: ${rootCities.length} | Жителей: ${rootPop * 1000}</div>
      </div>`;

      // Find direct children
      const children = cultures.filter(c => c.parentId === root.id);
      for (const child of children) {
        const childCities = Array.from(this.state.cities.values()).filter(c => c.dominantCultureId === child.id);
        const childPop = childCities.reduce((sum, c) => sum + c.population, 0);

        html += `<div class="tree-node child" style="border-left-color: ${child.color}">
          <h4>
            <span style="color: ${child.color}">↳ ●</span> ${child.name}
            <span style="font-size:0.75rem; color:#e67e22;">(Откололась на ${child.divergenceTurn} ходу)</span>
          </h4>
          <div class="traits">📜 Особенности: ${child.traits.join(', ')} | Городов: ${childCities.length} | Жителей: ${childPop * 1000}</div>
        </div>`;
      }
    }

    container.innerHTML = html || '<p class="placeholder">Культурных расколов еще не произошло.</p>';
  }

  renderChroniclesOfAges(): void {
    const list = document.getElementById('chronicles-of-ages-list');
    if (!list) return;

    if (!this.state.chroniclesOfAges || this.state.chroniclesOfAges.length === 0) {
      list.innerHTML = '<p class="placeholder">Летопись Веков чиста. Великие свершения еще впереди.</p>';
      return;
    }

    list.innerHTML = this.state.chroniclesOfAges.map(item => `
      <div style="border-left: 3px solid ${item.type === 'critical' ? '#f1c40f' : item.type === 'danger' ? '#e74c3c' : '#3498db'}; padding: 6px 10px; margin-bottom: 8px; background: rgba(255,255,255,0.04); border-radius: 0 4px 4px 0;">
        <div style="font-size: 0.76rem; color: #8b949e; margin-bottom: 2px;">
          📅 Ход ${item.turn} (${item.year})
        </div>
        <div style="font-size: 0.88rem; color: #f0f6fc; line-height: 1.4;">
          ${item.text}
        </div>
      </div>
    `).join('');
  }

  updateHUD(): void {
    const player = this.state.getPlayerFaction();
    if (!player) return;

    const year = 2400 - (this.state.currentTurn - 1) * 25;
    const yearEl = document.getElementById('hud-year');
    if (yearEl) yearEl.textContent = `${Math.abs(year)} ${t('bce', 'до н.э.')} (${getCurrentLanguage() === 'ru' ? 'Ход' : 'Turn'} ${this.state.currentTurn})`;

    // Historical Age Display
    const ageKey = 'age_' + this.state.age;
    const ageEl = document.getElementById('hud-age-name');
    if (ageEl) ageEl.textContent = t(ageKey, 'Эпоха Орудий');

    // Crisis Badge Display
    const crisisBadge = document.getElementById('hud-crisis-badge');
    if (crisisBadge) {
      if (this.state.currentCrisis) {
        crisisBadge.classList.remove('hidden');
        crisisBadge.textContent = `⚡ ${t('crisisBadge', 'КРИЗИС')}: ${this.state.currentCrisis.name.toUpperCase()} (${this.state.currentCrisis.turnsLeft} ${getCurrentLanguage() === 'ru' ? 'х.' : 't.'})`;
        crisisBadge.title = `Кризис: ${this.state.currentCrisis.description} (Сплоченность всех фракций снижена на 25%)`;
      } else {
        crisisBadge.classList.add('hidden');
      }
    }

    const factionNameEl = document.getElementById('hud-faction-name');
    if (factionNameEl) {
      factionNameEl.textContent = player.name;
      factionNameEl.style.color = player.color;
    }

    const goldEl = document.getElementById('hud-gold');
    if (goldEl) goldEl.textContent = `${player.gold}`;

    const grainEl = document.getElementById('hud-grain');
    if (grainEl) grainEl.textContent = `${player.grain}`;

    // Ruler & Legitimacy Display
    if (player.ruler) {
      const titleEl = document.getElementById('hud-ruler-title');
      if (titleEl) titleEl.textContent = player.ruler.title;

      const nameEl = document.getElementById('hud-ruler-name');
      if (nameEl) nameEl.textContent = player.ruler.name;

      const traitKey = 'trait_' + player.ruler.mainTrait;
      const traitEl = document.getElementById('hud-ruler-trait');
      if (traitEl && player.ruler.mainTrait) {
        traitEl.textContent = `[${t(traitKey, player.ruler.mainTrait)}]`;
      }

      // Cultural Tier Display
      const tierEl = document.getElementById('hud-faction-tier');
      if (tierEl) {
        const tier = player.tier || FactionTier.TRIBE;
        const tierKey = 'tier_' + tier;
        const tierColors: Record<FactionTier, string> = {
          [FactionTier.TRIBE]: '#2ecc71',
          [FactionTier.CHIEFDOM]: '#3498db',
          [FactionTier.EARLY_STATE]: '#9b59b6',
          [FactionTier.EMPIRE]: '#f1c40f'
        };
        tierEl.textContent = `[${t(tierKey, 'Дикое Племя')}]`;
        tierEl.style.color = tierColors[tier] || '#2ecc71';
      }

      // Tier Evolution Progress Display
      const progress = this.state.getTierProgress(player.id);
      const progTextEl = document.getElementById('hud-tier-progress-text');
      const progFillEl = document.getElementById('hud-tier-progress-fill');
      if (progTextEl && progFillEl) {
        if (progress.nextTier) {
          const stabText = getCurrentLanguage() === 'ru' ? 'стаб.' : 'stab.';
          progTextEl.textContent = `${progress.currentCulture}/${progress.targetCulture} 📜 (${progress.stableProvinces}/${progress.targetStableProvinces} ${stabText})`;
          const culturePct = Math.min(1, progress.currentCulture / progress.targetCulture);
          const stablePct = Math.min(1, progress.stableProvinces / progress.targetStableProvinces);
          const totalPct = Math.min(100, Math.round((culturePct * 0.5 + stablePct * 0.5) * 100));
          progFillEl.style.width = `${totalPct}%`;
          progFillEl.style.background = totalPct >= 100 ? '#f1c40f' : '#2ecc71';
        } else {
          progTextEl.textContent = getCurrentLanguage() === 'ru' ? 'Максимальный Тир (Империя)' : 'Max Tier (Empire)';
          progFillEl.style.width = '100%';
          progFillEl.style.background = '#f1c40f';
        }
      }

      const ageEl = document.getElementById('hud-ruler-age');
      if (ageEl) ageEl.textContent = `${player.ruler.age}`;

      const legitEl = document.getElementById('hud-legitimacy');
      if (legitEl) {
        legitEl.textContent = `${Math.round(player.ruler.legitimacy)}%`;
        if (player.ruler.legitimacy > 60) {
          legitEl.className = 'val good';
        } else if (player.ruler.legitimacy > 30) {
          legitEl.className = 'val warning';
        } else {
          legitEl.className = 'val danger';
        }
      }
    }

    const interregnumBadge = document.getElementById('hud-interregnum-badge');
    if (interregnumBadge) {
      if (player.isInterregnum) {
        interregnumBadge.classList.remove('hidden');
      } else {
        interregnumBadge.classList.add('hidden');
      }
    }

    // Culture Points
    const cultPointsEl = document.getElementById('hud-culture-points');
    if (cultPointsEl) cultPointsEl.textContent = `${player.culturePoints ?? 0}`;

    // Science Points
    const sciEl = document.getElementById('hud-science');
    if (sciEl) sciEl.textContent = `${player.sciencePoints ?? 0}`;

    // Tax rate button in Top HUD
    const taxBtn = document.getElementById('btn-tax-rate');
    if (taxBtn) {
      const r = player.taxRate || 'NORMAL';
      const label = r === 'LOW' ? 'Низк' : r === 'HIGH' ? 'Высок' : 'Норм';
      taxBtn.textContent = `💰 Налоги: ${label}`;
    }

    // Research lab button style based on tier
    const labBtn = document.getElementById('btn-research-lab');
    if (labBtn) {
      const canResearch = (player.tier || 1) >= FactionTier.EARLY_STATE;
      labBtn.style.opacity = canResearch ? '1' : '0.6';
    }

    // Strategic Resources
    const resCopper = document.getElementById('hud-res-copper');
    if (resCopper) resCopper.textContent = `${player.resources?.copper ?? 0}`;

    const resTin = document.getElementById('hud-res-tin');
    if (resTin) resTin.textContent = `${player.resources?.tin ?? 0}`;

    const resCattle = document.getElementById('hud-res-cattle');
    if (resCattle) resCattle.textContent = `${player.resources?.cattle ?? 0}`;

    const resIncense = document.getElementById('hud-res-incense');
    if (resIncense) resIncense.textContent = `${player.resources?.incense ?? 0}`;

    // Capital Luxuries Badge
    const luxValEl = document.getElementById('hud-luxury-val');
    if (luxValEl) {
      if (player.hasCapitalLuxury) {
        const names = player.capitalLuxuries && player.capitalLuxuries.length > 0 ? player.capitalLuxuries.join(', ') : 'Ладан/Скот';
        luxValEl.textContent = `Доставлены (+15% ⚖️ [${names}])`;
        luxValEl.className = 'val good';
        luxValEl.style.color = '#2ecc71';
      } else {
        luxValEl.textContent = 'Отрезаны (0% ⚖️)';
        luxValEl.className = 'val danger';
        luxValEl.style.color = '#e74c3c';
      }
    }

    // Overextension
    const overextEl = document.getElementById('hud-overextension');
    if (overextEl) {
      overextEl.textContent = `${player.overextension}%`;
      if (player.overextension > 35) {
        overextEl.className = 'val danger';
      } else if (player.overextension > 15) {
        overextEl.className = 'val warning';
      } else {
        overextEl.className = 'val good';
      }
    }

    const culture = this.state.cultures.get(player.rootCultureId);
    const cultureEl = document.getElementById('hud-culture');
    if (cultureEl && culture) {
      cultureEl.textContent = culture.name;
    }
  }

  updateInspector(): void {
    const panel = document.getElementById('inspector-content');
    if (!panel) return;

    // 1. If Hex is selected
    if (this.state.selectedHexKey) {
      const tile = this.state.tiles.get(this.state.selectedHexKey);
      if (!tile) {
        panel.innerHTML = '<p class="placeholder">Выберите гекс на карте</p>';
        return;
      }

      let html = `<div class="inspect-card">`;
      html += `<h3>Гекс [${tile.q}, ${tile.r}]</h3>`;
      const prov = tile.provinceId ? this.state.provinces.get(tile.provinceId) : null;
      if (prov) {
        html += `<p><strong>Провинция:</strong> <span style="color:#f1c40f; font-weight:700;">${prov.name}</span> (${prov.hexKeys.length} сот)</p>`;
        if (prov.ownerFactionId) {
          if (prov.isCutOffFromSupply) {
            html += `<div style="background:rgba(231,76,60,0.22); border:1px solid #e74c3c; border-radius:6px; padding:6px 8px; margin:6px 0;">
              <span style="color:#e74c3c; font-weight:800; font-size:0.82rem;">🚫📦 ОТРЕЗАН ОТ СНАБЖЕНИЯ!</span>
              <p style="font-size:0.75rem; color:#ecf0f1; margin-top:2px; line-height:1.35;">
                Караваны не могут достичь столицы. Доход Очков Культуры и ресурсов: <strong>0</strong>. Скорость падения власти утроена (<strong>x3</strong>)!
              </p>
            </div>`;
          } else {
            html += `<p style="color:#2ecc71; font-size:0.78rem; margin:2px 0;">📦 Линия снабжения: <strong>Активна</strong> (${prov.supplyDistance || 0} гекс. до столицы)</p>`;
          }

          if (prov.isRefuge) {
            html += `<div style="background:rgba(230,126,34,0.2); border:1px solid #e67e22; border-radius:6px; padding:4px 8px; margin:4px 0;">
              <span style="color:#f39c12; font-weight:700; font-size:0.8rem;">🏔️ Статус: «Убежище»</span>
              <p style="font-size:0.73rem; color:#ecf0f1; margin-top:1px;">
                Отрезано горами от метрополии: сплоченность падает на 10% быстрее, ускорен риск раскола культуры!
              </p>
            </div>`;
          }

          const provPop = prov.population ?? 20;
          html += `<p><strong>Население региона:</strong> ${provPop * 1000} жителей</p>`;

          const blds: string[] = [];
          if (prov.hasFarm) blds.push('🌾 Ферма (+2 🌾)');
          if (prov.hasMine) blds.push('⛏️ Шахта (+2 прод.)');
          if (prov.hasMarket) blds.push('💰 Рынок (+5 💰/х)');
          if (prov.hasWonder) blds.push(`🏛️ ${prov.wonderName || 'Чудо'} (+30% сплоченность)`);
          if (blds.length > 0) {
            html += `<p style="color:#2ecc71; font-size:0.8rem;"><strong>Постройки:</strong> ${blds.join(', ')}</p>`;
          }

          if (prov.wonderTurnsRemaining && prov.wonderTurnsRemaining > 0) {
            html += `<p style="color:#e67e22; font-size:0.8rem;"><strong>Стройка Чуда:</strong> 🏗️ ${prov.wonderName} (${prov.wonderTurnsRemaining} х.)</p>`;
          }

          if (prov.isEpidemic) {
            html += `<div style="background:rgba(231,76,60,0.25); border:1px solid #e74c3c; border-radius:6px; padding:4px 8px; margin:4px 0;">
              <span style="color:#e74c3c; font-weight:700; font-size:0.82rem;">☣️ ЭПИДЕМИЯ!</span>
              <p style="font-size:0.74rem; color:#ecf0f1; margin:2px 0 0 0;">Осталось ходов: ${prov.epidemicTurnsRemaining || 3}. Снабжение прервано, население гибнет.</p>
            </div>`;
          }

          const player = this.state.getPlayerFaction();
          if (player && prov.ownerFactionId === player.id) {
            html += `<div class="prov-management-box" style="margin: 8px 0; padding: 8px; background: rgba(0,0,0,0.25); border-radius: 6px; border: 1px solid #30363d;">
              <div style="font-size: 0.8rem; font-weight: 700; color: #c9d1d9; margin-bottom: 6px;">🏗️ Развитие провинции:</div>
              <div style="display: flex; flex-direction: column; gap: 4px;">`;

            if (!prov.hasFarm) {
              html += `<button class="action-btn btn-prov-build" data-build="farm" style="background:#27ae60; font-size:0.78rem; padding:4px 8px;">🌾 Построить Ферму (30 💰)</button>`;
            }
            if (!prov.hasMine) {
              html += `<button class="action-btn btn-prov-build" data-build="mine" style="background:#5c6b73; font-size:0.78rem; padding:4px 8px;">⛏️ Заложить Шахту (40 💰)</button>`;
            }
            if (!prov.hasMarket) {
              html += `<button class="action-btn btn-prov-build" data-build="market" style="background:#f39c12; font-size:0.78rem; padding:4px 8px;">💰 Открыть Рынок (35 💰)</button>`;
            }
            if (!prov.hasWonder && !prov.wonderTurnsRemaining && (player.tier || 1) >= FactionTier.EARLY_STATE) {
              html += `<button class="action-btn btn-prov-build" data-build="wonder" style="background:#8e44ad; font-size:0.78rem; padding:4px 8px;">🏛️ Возвести Чудо Света (120 💰, 50 📜)</button>`;
            }

            const recruitOpts = this.getRecruitmentOptionsForAge();
            html += `<div style="font-size: 0.8rem; font-weight: 700; color: #e74c3c; margin: 6px 0 2px;">⚔️ Нанять войска:</div>`;
            for (const opt of recruitOpts) {
              html += `<button class="action-btn btn-prov-recruit" data-recruit="${opt.type}" style="background:#c0392b; font-size:0.78rem; padding:4px 8px;">${opt.label}</button>`;
            }

            html += `</div></div>`;
          }
        }
      }
      html += `<p><strong>Биом:</strong> ${tile.biome} ${tile.isRiver ? '🌊 (Речная артерия)' : ''}</p>`;
      html += `<p><strong>Плодородие:</strong> ${tile.fertility} 🌾 | <strong>Проходимость:</strong> ${tile.movementCost} MP</p>`;

      if (tile.resource) {
        html += `<p class="highlight"><strong>Ресурс:</strong> ${tile.resource}</p>`;
      }

      if (tile.tribalCamp) {
        html += `<div class="tribe-box">
          <h4>⛺ ${tile.tribalCamp.name}</h4>
          <p>Воинов: ${tile.tribalCamp.warriors} | Культура: ${tile.tribalCamp.cultureName}</p>
          <p class="warning-text">⚠️ Колонизация этого гекса запустит синкретизм культур!</p>
        </div>`;
      }

      // City details
      if (tile.cityId) {
        const city = this.state.cities.get(tile.cityId);
        const cityFaction = city ? this.state.factions.get(city.factionId) : null;
        const domCulture = city ? this.state.cultures.get(city.dominantCultureId) : null;

        if (city && cityFaction && domCulture) {
          html += `<div class="city-box">
            <h4>🏛️ ${city.name}</h4>
            <p><strong>Владелец:</strong> <span style="color:${cityFaction.color}">${cityFaction.name}</span></p>
            <p><strong>Население:</strong> ${city.population * 1000} жителей</p>
            <p><strong>Культура:</strong> <span style="color:${domCulture.color}">${domCulture.name}</span></p>
            <div class="meter-box">
              <span>Имперская власть: <strong>${city.authority}%</strong> (${city.unrestStage})</span>
              <div class="meter-bar"><div class="fill" style="width:${city.authority}%; background:${city.authority < 40 ? '#e74c3c' : '#2ecc71'}"></div></div>
            </div>
            <div class="meter-box">
              <span>Культурный дрейф: <strong>${Math.round(city.accumulatedDrift)} / 100</strong></span>
              <div class="meter-bar"><div class="fill" style="width:${city.accumulatedDrift}%; background:#f39c12"></div></div>
            </div>
            <p class="small-text">Эфф. дистанция от столицы: ${Math.round(city.effectiveDistanceToCapital)} шагов</p>`;

          if (prov?.isCutOffFromSupply) {
            html += `<p style="color:#e74c3c; font-size:0.75rem; font-weight:700; margin-top:4px;">⚠️ Город отрезан: зерно и налоги не доходят до казны!</p>`;
          }

          html += `</div>`;
        }
      }

      // Unit details & actions
      if (tile.unitId) {
        const unit = this.state.units.get(tile.unitId);
        const unitFaction = unit ? this.state.factions.get(unit.factionId) : null;

        if (unit && unitFaction) {
          html += `<div class="unit-box">
            <h4>⚔️ ${unit.name}</h4>
            <p><strong>Фракция:</strong> ${unitFaction.name}</p>`;

          if (unit.generalName) {
            html += `<p style="color:#f1c40f; margin-bottom:4px;"><strong>👑 Полководец:</strong> ${unit.generalName}</p>`;
          }

          html += `<p><strong>HP:</strong> ${unit.hp}/${unit.maxHp} | <strong>Очки хода:</strong> ${unit.movesLeft}/${unit.maxMoves}</p>
            <div class="meter-box">
              <span>Линия снабжения: <strong>${unit.supply}%</strong></span>
              <div class="meter-bar"><div class="fill" style="width:${unit.supply}%; background:${unit.supply < 40 ? '#e74c3c' : '#3498db'}"></div></div>
            </div>`;

          if (unit.loyalty !== undefined && unit.loyalty !== null && unit.type !== UnitType.SETTLER) {
            const loyColor = unit.loyalty > 60 ? '#2ecc71' : unit.loyalty > 30 ? '#f39c12' : '#e74c3c';
            html += `<div class="meter-box">
              <span>Верность полководца: <strong>${Math.round(unit.loyalty)}%</strong> ${unit.loyalty < 30 ? '<span style="color:#e74c3c; font-weight:700;">⚠️ Бунт!</span>' : ''}</span>
              <div class="meter-bar"><div class="fill" style="width:${unit.loyalty}%; background:${loyColor}"></div></div>
            </div>`;
          }

          // Settler Action with Ratification Modal
          if (unit.type === UnitType.SETTLER && unitFaction.isPlayer && !tile.cityId) {
            html += `<button id="btn-found-city" class="action-btn">🏛️ Основать новое поселение...</button>`;
          }

          // Horde Settle Action
          if (unit.type === UnitType.HORDE && unitFaction.isPlayer && !tile.cityId) {
            html += `<button id="btn-settle-horde" class="action-btn" style="background:#27ae60; margin-top:8px;">🏕️ Осесть и основать поселение</button>`;
          }

          html += `</div>`;
        }
      }

      html += `</div>`;
      panel.innerHTML = html;

      // Attach button listener if settler present
      const foundBtn = document.getElementById('btn-found-city');
      if (foundBtn && tile.unitId) {
        foundBtn.addEventListener('click', () => {
          this.pendingSettlerUnitId = tile.unitId;
          const foundModal = document.getElementById('found-city-modal');
          const cityInput = document.getElementById('input-city-name') as HTMLInputElement;
          if (foundModal && cityInput) {
            cityInput.value = NameGenerator.generateCityName();
            foundModal.classList.remove('hidden');
          }
        });
      }

      // Attach button listener if horde present
      const settleBtn = document.getElementById('btn-settle-horde');
      if (settleBtn && tile.unitId) {
        settleBtn.addEventListener('click', () => {
          if (tile.unitId) {
            const success = this.state.settleHorde(tile.unitId);
            if (success) {
              this.updateHUD();
              this.updateInspector();
              this.updateChronicles();
              this.onRenderRequest();
            }
          }
        });
      }

      // Attach listeners for province infrastructure & military recruitment
      if (prov) {
        panel.querySelectorAll('.btn-prov-build').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const bType = (e.currentTarget as HTMLElement).dataset.build;
            if (bType === 'wonder') {
              this.state.buildWonder(prov.id);
            } else if (bType === 'farm' || bType === 'mine' || bType === 'market') {
              this.state.buildProvinceStructure(prov.id, bType);
            }
            this.updateHUD();
            this.updateInspector();
            this.updateChronicles();
            this.onRenderRequest();
          });
        });

        panel.querySelectorAll('.btn-prov-recruit').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const uType = (e.currentTarget as HTMLElement).dataset.recruit as UnitType;
            if (uType) {
              this.state.recruitUnit(prov.id, uType);
              this.updateHUD();
              this.updateInspector();
              this.updateChronicles();
              this.onRenderRequest();
            }
          });
        });
      }
    } else {
      panel.innerHTML = '<p class="placeholder">Выберите гекс на карте</p>';
    }
  }

  updateChronicles(): void {
    const list = document.getElementById('chronicles-list');
    if (!list) return;

    list.innerHTML = this.state.eventLogs.map(log => `
      <div class="log-entry log-${log.type}">
        <span class="log-turn">Ход ${log.turn}:</span>
        <span class="log-msg">${log.text}</span>
      </div>
    `).join('');
  }

  checkSecessionModal(): void {
    const modalData = this.state.activeSecessionModal;
    const modalEl = document.getElementById('secession-modal');
    if (!modalEl) return;

    if (!modalData) {
      modalEl.classList.add('hidden');
      return;
    }

    modalEl.classList.remove('hidden');

    const titleEl = document.getElementById('modal-title');
    const descEl = document.getElementById('modal-desc');
    const stayBtn = document.getElementById('modal-btn-stay');
    const switchBtn = document.getElementById('modal-btn-switch');

    if (titleEl) titleEl.textContent = `⚡ ВЕЛИКИЙ РАСКОЛ ИМПЕРИИ!`;
    if (descEl) {
      descEl.innerHTML = `
        <p>Кризис перерасширения достиг апогея! Город <strong>${modalData.city.name}</strong> отринул законы метрополии.</p>
        <p>Лидер сепаратистов <strong>${modalData.leaderName}</strong> провозгласил рождение независимого государства: <br>
        <strong style="color:${modalData.newFaction.color}; font-size:1.15rem">${modalData.newFaction.name}</strong>!</p>
        <p>Гарнизоны перешли на сторону мятежников. Культурный разрыв стал необратимым фактом.</p>
        <div class="choice-prompt" style="margin-top:12px; font-weight:700; color:#f1c40f;">Чью сторону вы примете в надвигающейся гражданской войне?</div>
      `;
    }

    if (stayBtn) {
      stayBtn.onclick = () => {
        this.state.addLog(`Вы остались во главе метрополии. Мятежники будут приведены к покорности!`, 'warning');
        this.state.activeSecessionModal = null;
        modalEl.classList.add('hidden');
        this.updateHUD();
        this.updateInspector();
        this.onRenderRequest();
      };
    }

    if (switchBtn) {
      switchBtn.onclick = () => {
        SecessionSystem.switchPlayerFaction(modalData.oldFaction, modalData.newFaction);
        this.state.addLog(`Вы возглавили новую державу «${modalData.newFaction.name}»! Начинается эпоха молодой пассионарной цивилизации!`, 'critical');
        this.state.activeSecessionModal = null;
        modalEl.classList.add('hidden');
        this.updateHUD();
        this.updateInspector();
        this.onRenderRequest();
      };
    }
  }

  // --- Game Mode Management ---
  applyGameMode(mode: GameMode): void {
    const startMenu = document.getElementById('start-menu-overlay');
    const diploModal = document.getElementById('diplomacy-modal');
    const topHud = document.getElementById('top-hud');
    const inspector = document.getElementById('inspector-panel');
    const chronicles = document.getElementById('chronicles-panel');

    if (mode === 'START_MENU') {
      startMenu?.classList.remove('hidden');
      diploModal?.classList.add('hidden');
      topHud?.classList.add('hidden');
      if (inspector) inspector.style.display = 'none';
      if (chronicles) chronicles.style.display = 'none';
    } else if (mode === 'PLAYING') {
      startMenu?.classList.add('hidden');
      diploModal?.classList.add('hidden');
      topHud?.classList.remove('hidden');
      if (inspector) inspector.style.display = 'block';
      if (chronicles) chronicles.style.display = 'flex';
    } else if (mode === 'DIPLOMACY_MENU') {
      this.renderDiplomacy();
      diploModal?.classList.remove('hidden');
    }
  }

  // --- Start Menu Setup ---
  private setupStartMenu(): void {
    const cards = document.querySelectorAll('.culture-card');
    cards.forEach(card => {
      card.addEventListener('click', () => {
        cards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        const choice = (card as HTMLElement).dataset.choice as StarterCultureChoice;
        if (choice) {
          this.selectedStarter = choice;
        }
      });
    });

    const startBtn = document.getElementById('btn-start-game');
    startBtn?.addEventListener('click', () => {
      this.state.startNewGame(this.selectedStarter);
      this.applyGameMode('PLAYING');
      this.updateHUD();
      this.updateInspector();
      this.updateChronicles();
      this.onRenderRequest();
    });

    // Continue Game Button (loads from localStorage)
    const continueBtn = document.getElementById('btn-continue-game');
    const saveTurnNum = document.getElementById('save-turn-num');
    if (continueBtn) {
      if (SaveManager.hasSavedGame()) {
        const meta = SaveManager.getSavedGameMeta();
        if (meta && saveTurnNum) {
          saveTurnNum.textContent = `${meta.turn}`;
        }
        continueBtn.classList.remove('hidden');
      } else {
        continueBtn.classList.add('hidden');
      }

      continueBtn.addEventListener('click', () => {
        const loaded = SaveManager.loadGame(this.state);
        if (loaded) {
          this.applyGameMode('PLAYING');
          this.updateHUD();
          this.updateInspector();
          this.updateChronicles();
          this.onRenderRequest();
          const renderer = (window as any).renderer;
          if (renderer) renderer.centerOnPlayerCapital();
        }
      });
    }

    this.updateStartMenuCultureCards();
  }

  public updateStartMenuCultureCards(): void {
    const lang = getCurrentLanguage();
    const dict = TRANSLATIONS[lang];

    // Card 1: River Farmers
    const c1 = document.querySelector('.culture-card[data-choice="RIVER_FARMERS"]');
    if (c1) {
      const title = c1.querySelector('.card-title');
      const reg = c1.querySelector('.card-region');
      const perk = c1.querySelector('.card-perk-badge');
      const desc = c1.querySelector('.card-desc');
      const traits = c1.querySelectorAll('.card-traits li');
      if (title) title.textContent = dict.riverFarmersTitle;
      if (reg) reg.textContent = dict.riverFarmersRegion;
      if (perk) perk.textContent = dict.riverFarmersPerk;
      if (desc) desc.textContent = dict.riverFarmersDesc;
      if (traits[0]) traits[0].textContent = dict.riverFarmersTrait1;
      if (traits[1]) traits[1].textContent = dict.riverFarmersTrait2;
      if (traits[2]) traits[2].textContent = dict.riverFarmersTrait3;
    }

    // Card 2: Steppe Nomads
    const c2 = document.querySelector('.culture-card[data-choice="STEPPE_NOMADS"]');
    if (c2) {
      const title = c2.querySelector('.card-title');
      const reg = c2.querySelector('.card-region');
      const perk = c2.querySelector('.card-perk-badge');
      const desc = c2.querySelector('.card-desc');
      const traits = c2.querySelectorAll('.card-traits li');
      if (title) title.textContent = dict.steppeNomadsTitle;
      if (reg) reg.textContent = dict.steppeNomadsRegion;
      if (perk) perk.textContent = dict.steppeNomadsPerk;
      if (desc) desc.textContent = dict.steppeNomadsDesc;
      if (traits[0]) traits[0].textContent = dict.steppeNomadsTrait1;
      if (traits[1]) traits[1].textContent = dict.steppeNomadsTrait2;
      if (traits[2]) traits[2].textContent = dict.steppeNomadsTrait3;
    }

    // Card 3: Mountain Totemists
    const c3 = document.querySelector('.culture-card[data-choice="MOUNTAIN_TOTEMISTS"]');
    if (c3) {
      const title = c3.querySelector('.card-title');
      const reg = c3.querySelector('.card-region');
      const perk = c3.querySelector('.card-perk-badge');
      const desc = c3.querySelector('.card-desc');
      const traits = c3.querySelectorAll('.card-traits li');
      if (title) title.textContent = dict.mountainTotemistsTitle;
      if (reg) reg.textContent = dict.mountainTotemistsRegion;
      if (perk) perk.textContent = dict.mountainTotemistsPerk;
      if (desc) desc.textContent = dict.mountainTotemistsDesc;
      if (traits[0]) traits[0].textContent = dict.mountainTotemistsTrait1;
      if (traits[1]) traits[1].textContent = dict.mountainTotemistsTrait2;
      if (traits[2]) traits[2].textContent = dict.mountainTotemistsTrait3;
    }
  }

  // --- Traditions, Faith & Language Setup & Rendering ---
  private setupTraditions(): void {
    const tradBtn = document.getElementById('btn-traditions');
    const tradModal = document.getElementById('traditions-modal');
    const tradClose = document.getElementById('btn-traditions-close');

    const tabDogmas = document.getElementById('tab-btn-dogmas');
    const tabLang = document.getElementById('tab-btn-language');
    const panelDogmas = document.getElementById('tab-panel-dogmas');
    const panelLang = document.getElementById('tab-panel-language');

    tabDogmas?.addEventListener('click', () => {
      tabDogmas.classList.add('active');
      tabLang?.classList.remove('active');
      panelDogmas?.classList.remove('hidden');
      panelLang?.classList.add('hidden');
      this.renderTraditions();
    });

    tabLang?.addEventListener('click', () => {
      tabLang.classList.add('active');
      tabDogmas?.classList.remove('active');
      panelLang?.classList.remove('hidden');
      panelDogmas?.classList.add('hidden');
      this.renderLanguageTab();
    });

    tradBtn?.addEventListener('click', () => {
      this.renderTraditions();
      this.renderLanguageTab();
      tradModal?.classList.remove('hidden');
    });

    tradClose?.addEventListener('click', () => {
      tradModal?.classList.add('hidden');
    });

    const grid = document.getElementById('tab-panel-dogmas')?.querySelector('.traditions-grid');
    grid?.addEventListener('click', (e) => {
      const target = (e.target as HTMLElement).closest('.dogma-btn') as HTMLElement;
      if (target && !target.hasAttribute('disabled')) {
        const dogmaId = target.dataset.dogma as DogmaId;
        if (dogmaId) {
          const res = this.state.unlockDogma(dogmaId);
          if (res.success) {
            this.renderTraditions();
            this.updateHUD();
            this.updateChronicles();
          } else {
            alert(res.message);
          }
        }
      }
    });
  }

  renderTraditions(): void {
    const player = this.state.getPlayerFaction();
    if (!player) return;

    const pointsVal = document.getElementById('traditions-points-val');
    if (pointsVal) pointsVal.textContent = `${player.culturePoints ?? 0}`;

    const dogmas: { id: DogmaId; elementId: string }[] = [
      { id: DogmaId.ANCESTOR_CULT, elementId: 'dogma-ancestor' },
      { id: DogmaId.RIVER_PRIESTHOOD, elementId: 'dogma-river' },
      { id: DogmaId.NOMADIC_LIFESTYLE, elementId: 'dogma-nomadic' }
    ];

    for (const d of dogmas) {
      const card = document.getElementById(d.elementId);
      if (!card) continue;

      const isUnlocked = player.unlockedDogmas.includes(d.id);
      const btn = card.querySelector('.dogma-btn') as HTMLButtonElement;

      if (isUnlocked) {
        card.classList.add('unlocked');
        if (btn) {
          btn.textContent = '✅ Принят';
          btn.disabled = true;
          btn.className = 'dogma-btn unlocked-btn';
        }
      } else {
        card.classList.remove('unlocked');
        if (btn) {
          btn.textContent = 'Принять догмат (75 📜)';
          btn.disabled = (player.culturePoints ?? 0) < 75;
          btn.className = 'dogma-btn';
        }
      }
    }
  }

  renderLanguageTab(): void {
    const grid = document.getElementById('language-techs-grid');
    const driftHud = document.getElementById('language-drift-hud');
    if (!grid) return;

    const player = this.state.getPlayerFaction();
    if (!player) return;
    const cult = this.state.cultures.get(player.rootCultureId);
    if (!cult) return;

    const langFeatures = cult.language?.features || ['WRITING'];

    if (driftHud) {
      if (cult.isSubCulture) {
        driftHud.innerHTML = `⚠️ Дрейф суб-культуры: <strong>${Math.round(cult.drift || 0)}%</strong> / 100%`;
      } else {
        driftHud.innerHTML = `🏛️ Метрополия: язык «${cult.language?.name || cult.name}»`;
      }
    }

    grid.innerHTML = LANGUAGE_TECHS.map(tech => {
      const isUnlocked = langFeatures.includes(tech.id);
      const canAfford = (player.culturePoints ?? 0) >= tech.cost;

      return `
        <div class="dogma-card ${isUnlocked ? 'unlocked' : ''}">
          <div class="dogma-icon">${tech.icon}</div>
          <div class="dogma-title">${tech.name}</div>
          <div class="dogma-desc">
            ${tech.effect}
          </div>
          <button class="dogma-btn ${isUnlocked ? 'unlocked-btn' : ''} btn-lang-unlock" data-lang-tech="${tech.id}" ${isUnlocked || !canAfford ? 'disabled' : ''}>
            ${isUnlocked ? '✅ Освоено' : `Изучить (${tech.cost} 📜)`}
          </button>
        </div>
      `;
    }).join('');

    grid.querySelectorAll('.btn-lang-unlock').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const techId = (e.currentTarget as HTMLElement).dataset.langTech;
        if (techId) {
          const res = this.state.unlockLanguageTech(techId);
          if (res.success) {
            this.renderLanguageTab();
            this.renderTraditions();
            this.updateHUD();
            this.updateChronicles();
            this.onRenderRequest();
          } else {
            alert(res.message);
          }
        }
      });
    });
  }

  // --- Migration Setup & Rendering ---
  private setupMigration(): void {
    const migBtn = document.getElementById('btn-migration');
    const migModal = document.getElementById('migration-modal');
    const cancelBtn = document.getElementById('btn-migration-cancel');
    const confirmBtn = document.getElementById('btn-migration-confirm') as HTMLButtonElement;

    migBtn?.addEventListener('click', () => {
      this.selectedMigrationProvinceId = null;
      if (confirmBtn) confirmBtn.disabled = true;
      this.renderMigrationModal();
      migModal?.classList.remove('hidden');
    });

    cancelBtn?.addEventListener('click', () => {
      migModal?.classList.add('hidden');
      this.selectedMigrationProvinceId = null;
    });

    confirmBtn?.addEventListener('click', () => {
      if (this.selectedMigrationProvinceId) {
        const ok = this.state.startMigration(this.selectedMigrationProvinceId);
        if (ok) {
          migModal?.classList.add('hidden');
          this.selectedMigrationProvinceId = null;
          this.updateHUD();
          this.updateInspector();
          this.updateChronicles();
          this.onRenderRequest();
        } else {
          alert('Не удалось начать миграцию из этой провинции.');
        }
      }
    });
  }

  renderMigrationModal(): void {
    const list = document.getElementById('migration-province-list');
    const confirmBtn = document.getElementById('btn-migration-confirm') as HTMLButtonElement;
    if (!list) return;

    const player = this.state.getPlayerFaction();
    if (!player) return;

    const playerCities = Array.from(this.state.cities.values()).filter(c => c.factionId === player.id);
    if (playerCities.length === 0) {
      list.innerHTML = '<p class="placeholder">У вашей державы нет контролируемых городов для миграции.</p>';
      if (confirmBtn) confirmBtn.disabled = true;
      return;
    }

    let html = '';
    for (const city of playerCities) {
      const prov = this.state.provinces.get(city.provinceId);
      const provName = prov ? prov.name : city.name;
      const isSelected = this.selectedMigrationProvinceId === city.provinceId;

      html += `
        <div class="migration-item ${isSelected ? 'selected' : ''}" data-prov-id="${city.provinceId}">
          <div>
            <div style="font-weight:700; color:#f1c40f;">🏛️ ${city.name} (${provName})</div>
            <div style="font-size:0.78rem; color:#8b949e;">
              Жителей: ${city.population * 1000} | Сплоченность / Власть: ${city.authority}% (${city.unrestStage})
            </div>
          </div>
          <span style="font-size:0.85rem; color:#e67e22; font-weight:700;">Снять в путь ➔</span>
        </div>
      `;
    }

    list.innerHTML = html;

    const items = list.querySelectorAll('.migration-item');
    items.forEach(item => {
      item.addEventListener('click', (e) => {
        items.forEach(it => it.classList.remove('selected'));
        const el = e.currentTarget as HTMLElement;
        el.classList.add('selected');
        this.selectedMigrationProvinceId = el.dataset.provId || null;
        if (confirmBtn) confirmBtn.disabled = !this.selectedMigrationProvinceId;
      });
    });
  }

  // --- Diplomacy Screen Setup & Rendering ---
  private setupDiplomacy(): void {
    const diploBtn = document.getElementById('btn-diplomacy');
    diploBtn?.addEventListener('click', () => {
      this.state.setGameMode('DIPLOMACY_MENU');
    });

    const closeBtn = document.getElementById('btn-diplomacy-close');
    closeBtn?.addEventListener('click', () => {
      this.state.setGameMode('PLAYING');
    });
  }

  renderDiplomacy(): void {
    const list = document.getElementById('diplomacy-list');
    if (!list) return;

    const player = this.state.getPlayerFaction();
    if (!player) return;

    const aiFactions = Array.from(this.state.factions.values()).filter(f => !f.isPlayer);
    if (aiFactions.length === 0) {
      list.innerHTML = '<p class="placeholder">Других держав в известном мире не обнаружено.</p>';
      return;
    }

    let html = '';
    for (const faction of aiFactions) {
      const relation = player.diplomacy[faction.id] || {
        status: DiplomaticStatus.PEACE,
        opinion: 15,
        pactTurnsLeft: 0
      };

      const cult = this.state.cultures.get(faction.rootCultureId);
      const cultName = cult ? cult.name : 'Древняя культура';

      // Status pill
      let statusPill = '';
      if (relation.status === DiplomaticStatus.WAR) {
        statusPill = `<span class="diplo-status-pill war">⚔️ ВОЙНА</span>`;
      } else if (relation.status === DiplomaticStatus.NON_AGGRESSION) {
        statusPill = `<span class="diplo-status-pill non-aggression">📜 ПАКТ О НЕ НАПАДЕНИИ (${relation.pactTurnsLeft} х.)</span>`;
      } else {
        statusPill = `<span class="diplo-status-pill peace">🕊️ МИР</span>`;
      }

      // Opinion color & text
      let opColor = '#2ecc71';
      let opText = 'Дружелюбное';
      if (relation.opinion < -30) {
        opColor = '#e74c3c';
        opText = 'Кровная вражда';
      } else if (relation.opinion < 0) {
        opColor = '#e67e22';
        opText = 'Напряженное';
      } else if (relation.opinion < 30) {
        opColor = '#f1c40f';
        opText = 'Нейтральное';
      }

      const isWar = relation.status === DiplomaticStatus.WAR;
      const isPact = relation.status === DiplomaticStatus.NON_AGGRESSION;

      html += `
        <div class="diplomacy-card" data-faction-id="${faction.id}">
          <div class="diplo-info">
            <div class="diplo-faction-title">
              <span style="color:${faction.color}; font-size:1.3rem;">●</span>
              <span style="color:#f0f6fc;">${faction.name}</span>
              <span style="font-size:0.75rem; color:#8b949e;">[${cultName}]</span>
              ${statusPill}
            </div>
            <div class="diplo-ruler-desc">
              👑 Правитель: <strong style="color:#f1c40f;">${faction.ruler.title} ${faction.ruler.name}</strong> 
              (Возраст: ${faction.ruler.age} лет, Легитимность: ${Math.round(faction.ruler.legitimacy)}%)
            </div>
            <div class="diplo-relation-row">
              <span>Отношение к нам: <strong style="color:${opColor}">${relation.opinion > 0 ? '+' : ''}${relation.opinion}</strong> (${opText})</span>
              <span>Городов под властью: <strong>${Array.from(this.state.cities.values()).filter(c => c.factionId === faction.id).length}</strong></span>
            </div>
            <div class="diplo-relation-row" style="margin-top:4px;">
              <span>Ресурсы ИИ: 🪨 Медь: <strong>${faction.resources?.copper ?? 0}</strong> | ⛏️ Олово: <strong>${faction.resources?.tin ?? 0}</strong> | 🐂 Скот: <strong>${faction.resources?.cattle ?? 0}</strong> | 🏺 Благовония: <strong>${faction.resources?.incense ?? 0}</strong></span>
            </div>

            <!-- Trade Box -->
            <div class="diplo-trade-box">
              <span>Торговля: Отдать 2 ед.</span>
              <select class="diplo-trade-select diplo-give-select" data-faction="${faction.id}">
                <option value="incense">🏺 Благовония (склад: ${player.resources?.incense ?? 0})</option>
                <option value="cattle">🐂 Скот (склад: ${player.resources?.cattle ?? 0})</option>
              </select>
              <span>➔ Получить 2 ед.</span>
              <select class="diplo-trade-select diplo-get-select" data-faction="${faction.id}">
                <option value="copper">🪨 Медь (у ИИ: ${faction.resources?.copper ?? 0})</option>
                <option value="tin">⛏️ Олово (у ИИ: ${faction.resources?.tin ?? 0})</option>
              </select>
              <button class="btn-diplo-trade" data-faction="${faction.id}" ${isWar ? 'disabled title="Война блокирует торговлю"' : ''}>
                ⚖️ Обменять
              </button>
            </div>
          </div>
          <div class="diplo-actions">
            <button class="diplo-btn war btn-declare-war" data-target="${faction.id}" ${isWar ? 'disabled' : ''}>
              ⚔️ Объявить войну
            </button>
            <button class="diplo-btn pact btn-offer-pact" data-target="${faction.id}" ${isWar || isPact ? 'disabled' : ''}>
              🤝 Пакт о ненападении
            </button>
          </div>
        </div>
      `;
    }

    list.innerHTML = html;

    // Attach click listeners for war and pact buttons
    const warBtns = list.querySelectorAll('.btn-declare-war');
    warBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetId = (e.currentTarget as HTMLElement).dataset.target;
        if (targetId) {
          this.state.declareWar(targetId);
          this.renderDiplomacy();
          this.updateHUD();
          this.updateChronicles();
          this.onRenderRequest();
        }
      });
    });

    const pactBtns = list.querySelectorAll('.btn-offer-pact');
    pactBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetId = (e.currentTarget as HTMLElement).dataset.target;
        if (targetId) {
          const res = this.state.offerNonAggressionPact(targetId);
          alert(res.message);
          this.renderDiplomacy();
          this.updateHUD();
          this.updateChronicles();
          this.onRenderRequest();
        }
      });
    });

    // Attach click listeners for trade
    const tradeBtns = list.querySelectorAll('.btn-diplo-trade');
    tradeBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const factionId = (e.currentTarget as HTMLElement).dataset.faction;
        if (!factionId) return;

        const card = (e.currentTarget as HTMLElement).closest('.diplomacy-card');
        if (!card) return;

        const giveSelect = card.querySelector('.diplo-give-select') as HTMLSelectElement;
        const getSelect = card.querySelector('.diplo-get-select') as HTMLSelectElement;

        if (giveSelect && getSelect) {
          const offerRes = giveSelect.value as keyof ResourceStockpile;
          const demandRes = getSelect.value as keyof ResourceStockpile;

          const res = this.state.executeTrade(factionId, offerRes, demandRes, 2, 2);
          alert(res.message);
          if (res.success) {
            this.renderDiplomacy();
            this.updateHUD();
            this.updateChronicles();
            this.onRenderRequest();
          }
        }
      });
    });
  }

  // --- Hover Tooltips & Floating Annexation Menu ---
  handleProvinceHover(prov: Province | null, screenX: number, screenY: number, tile: HexTile | null): void {
    const tooltip = document.getElementById('province-tooltip');
    if (!tooltip) return;

    if (!prov || this.state.mode !== 'PLAYING') {
      tooltip.classList.add('hidden');
      return;
    }

    const player = this.state.getPlayerFaction();
    if (!player) return;

    let html = `<div class="tt-title">🏛️ ${prov.name}</div>`;
    html += `<div>Биом: ${prov.biome} | Плодородие: ${prov.fertility} 🌾</div>`;

    if (tile?.resource) {
      html += `<div style="color:#f39c12">Ресурс: <strong>${tile.resource}</strong></div>`;
    }

    if (prov.ownerFactionId === null) {
      const isExpandable = this.state.isProvinceExpandable(prov.id, player.id);
      if (isExpandable) {
        const cost = this.state.getAnnexationCost(prov.id, player.id);
        html += `<div class="tt-expandable">✨ Доступно для присоединения!</div>`;
        html += `<div class="tt-cost">Мгновенный захват: 🌾 ${cost.food} Еды, 📜 ${cost.culture} Культуры</div>`;
        html += `<div class="tt-cost">Мирное освоение поселенцами: 3 хода</div>`;
        if (player.tier && player.tier >= FactionTier.CHIEFDOM) {
          html += `<div style="font-size:0.73rem; color:#3498db; margin-top:2px;">⛺ Можно возвести аванпост (25 💰)</div>`;
        }
        if (prov.biome === BiomeType.MOUNTAINS || prov.biome === BiomeType.DESERT) {
          html += `<div style="font-size:0.73rem; color:#e67e22; margin-top:2px;">⛰️ Ландшафтная преграда: стоимость в Культуре x3!</div>`;
        }
      } else {
        html += `<div class="tt-locked">🔒 Дикие земли (нет общей границы с державой)</div>`;
      }
    } else if (prov.ownerFactionId === player.id) {
      html += `<div style="color:#2ecc71; font-weight:700; margin-top:3px;">👑 Владения вашей державы</div>`;
      html += `<div style="font-size:0.75rem; color:#8b949e;">Сплоченность: ${prov.authority}% (${prov.unrestStage})</div>`;
      if (prov.isRefuge) {
        html += `<div style="color:#f39c12; font-size:0.75rem; margin-top:2px;">🏔️ Статус «Убежище»: отрезано горами (сплоченность -10% быстрее)</div>`;
      }
      if (prov.isCutOffFromSupply) {
        html += `<div style="color:#e74c3c; font-weight:700; margin-top:5px; font-size:0.78rem; background:rgba(231,76,60,0.18); padding:3px 6px; border-radius:4px; border:1px solid rgba(231,76,60,0.5);">
          🚫📦 ОТРЕЗАН ОТ СНАБЖЕНИЯ!
          <div style="font-weight:normal; font-size:0.72rem; color:#f0f6fc; margin-top:1px;">Доход: 0 📜, ресурсы заблокированы, падение власти x3!</div>
        </div>`;
      } else {
        html += `<div style="font-size:0.72rem; color:#2ecc71; margin-top:3px;">📦 Снабжение активно (до столицы: ${prov.supplyDistance || 0} гекс.)</div>`;
      }
    } else {
      const owner = this.state.factions.get(prov.ownerFactionId);
      html += `<div style="color:${owner?.color || '#e74c3c'}; font-weight:700; margin-top:3px;">⚔️ Земли державы ${owner?.name || ''}</div>`;
      if (owner && player.tier > (owner.tier || FactionTier.TRIBE)) {
        html += `<div style="color:#9b59b6; font-size:0.74rem; margin-top:2px;">🏛️ Подвержена мирной ассимиляции вашей цивилизацией!</div>`;
      }
      if (prov.isCutOffFromSupply) {
        html += `<div style="color:#e74c3c; font-size:0.74rem; margin-top:2px;">🚫 Регион отрезан от снабжения столицы</div>`;
      }
    }

    tooltip.innerHTML = html;
    tooltip.classList.remove('hidden');

    const pad = 16;
    const ttWidth = 260;
    const ttHeight = 110;
    const posX = Math.min(window.innerWidth - ttWidth - pad, screenX + pad);
    const posY = Math.min(window.innerHeight - ttHeight - pad, screenY + pad);

    tooltip.style.left = `${posX}px`;
    tooltip.style.top = `${posY}px`;
  }

  showAnnexMenu(prov: Province, screenX: number, screenY: number): void {
    const menu = document.getElementById('floating-annex-menu');
    if (!menu) return;

    const player = this.state.getPlayerFaction();
    if (!player) return;

    this.activeAnnexProvinceId = prov.id;
    const cost = this.state.getAnnexationCost(prov.id, player.id);

    const nameEl = document.getElementById('annex-province-name');
    if (nameEl) nameEl.textContent = prov.name;

    const infoEl = document.getElementById('annex-info-text');
    if (infoEl) infoEl.textContent = `Плодородие: ${prov.fertility} 🌾 | Биом: ${prov.biome}`;

    const costBadge = document.getElementById('annex-cost-badge');
    if (costBadge) costBadge.textContent = `(🌾 ${cost.food} | 📜 ${cost.culture})`;

    const instantBtn = document.getElementById('btn-annex-instant') as HTMLButtonElement;
    if (instantBtn) {
      instantBtn.disabled = !cost.canAfford;
      instantBtn.title = cost.canAfford ? '' : (cost.reason || 'Недостаточно ресурсов');
    }

    const outpostBtn = document.getElementById('btn-annex-outpost') as HTMLButtonElement;
    if (outpostBtn) {
      if (player.tier && player.tier >= FactionTier.CHIEFDOM) {
        outpostBtn.classList.remove('hidden');
        outpostBtn.disabled = player.gold < 25;
      } else {
        outpostBtn.classList.add('hidden');
      }
    }

    menu.classList.remove('hidden');

    const menuW = 270;
    const menuH = 150;
    const posX = Math.min(window.innerWidth - menuW - 10, Math.max(10, screenX + 12));
    const posY = Math.min(window.innerHeight - menuH - 10, Math.max(10, screenY + 12));

    menu.style.left = `${posX}px`;
    menu.style.top = `${posY}px`;
  }

  hideAnnexMenu(): void {
    const menu = document.getElementById('floating-annex-menu');
    menu?.classList.add('hidden');
    this.activeAnnexProvinceId = null;
  }

  private setupFloatingAnnexMenu(): void {
    const closeBtn = document.getElementById('btn-annex-close');
    closeBtn?.addEventListener('click', () => {
      this.hideAnnexMenu();
    });

    const instantBtn = document.getElementById('btn-annex-instant');
    instantBtn?.addEventListener('click', () => {
      if (this.activeAnnexProvinceId) {
        const res = this.state.annexProvince(this.activeAnnexProvinceId);
        if (res.success) {
          this.hideAnnexMenu();
          this.updateHUD();
          this.updateInspector();
          this.updateChronicles();
          this.onRenderRequest();
        } else {
          alert(res.message);
        }
      }
    });

    const outpostBtn = document.getElementById('btn-annex-outpost');
    outpostBtn?.addEventListener('click', () => {
      if (this.activeAnnexProvinceId) {
        const res = this.state.buildOutpost(this.activeAnnexProvinceId);
        if (res.success) {
          this.hideAnnexMenu();
          this.updateHUD();
          this.updateInspector();
          this.updateChronicles();
          this.onRenderRequest();
        } else {
          alert(res.message);
        }
      }
    });
  }

  private setupEvolutionModal(): void {
    const continueBtn = document.getElementById('btn-evolution-continue');
    const modal = document.getElementById('tier-evolution-modal');
    continueBtn?.addEventListener('click', () => {
      modal?.classList.add('hidden');
    });
  }

  showEvolutionModal(data: any): void {
    const modal = document.getElementById('tier-evolution-modal');
    if (!modal) return;

    const titleEl = document.getElementById('evolution-title');
    const subtitleEl = document.getElementById('evolution-subtitle');
    const descEl = document.getElementById('evolution-desc');

    if (titleEl) titleEl.textContent = `🌟 КУЛЬТУРНАЯ ТРАНСФОРМАЦИЯ!`;
    if (subtitleEl) subtitleEl.textContent = `Ваша культура эволюционировала в статус [${data.tierName}]!`;

    if (descEl) {
      let html = `<p style="margin-bottom:8px; font-weight:600; color:#f0f6fc;">${data.subtitle || ''}</p>`;
      if (data.perks && data.perks.length > 0) {
        html += `<ul class="perks-list">`;
        for (const perk of data.perks) {
          html += `<li>${perk}</li>`;
        }
        html += `</ul>`;
      }
      descEl.innerHTML = html;
    }

    modal.classList.remove('hidden');
  }

  private getRecruitmentOptionsForAge(): { type: UnitType; label: string }[] {
    switch (this.state.age) {
      case HistoricalAge.MODERN:
        return [
          { type: UnitType.INFANTRY, label: '🪖 Мотопехота (💰 75, 🌾 45)' },
          { type: UnitType.TANK, label: '🚜 Танк (💰 110, 🌾 60)' }
        ];
      case HistoricalAge.INDUSTRIAL:
        return [
          { type: UnitType.INFANTRY, label: '🪖 Пехота (💰 75, 🌾 45)' },
          { type: UnitType.CANNON, label: '💣 Артиллерия (💰 70, 🌾 40)' }
        ];
      case HistoricalAge.RENAISSANCE:
        return [
          { type: UnitType.MUSKETEER, label: '💂 Мушкетеры (💰 55, 🌾 35)' },
          { type: UnitType.CANNON, label: '💣 Пушки (💰 70, 🌾 40)' }
        ];
      case HistoricalAge.IRON_AGE:
        return [
          { type: UnitType.LEGION, label: '⚔️ Легионеры (💰 40, 🌾 30)' },
          { type: UnitType.HEAVY_CAVALRY, label: '🏇 Тяжелая конница (💰 55, 🌾 40)' }
        ];
      default:
        return [
          { type: UnitType.SPEARMEN, label: '🛡️ Копейщики (💰 30, 🌾 25)' },
          { type: UnitType.CHARIOT, label: '🐎 Колесницы (💰 45, 🌾 35)' }
        ];
    }
  }

  // --- Research Lab Setup & Rendering ---
  private setupResearchLab(): void {
    const labBtn = document.getElementById('btn-research-lab');
    const modal = document.getElementById('research-modal');
    const closeBtn = document.getElementById('btn-research-close');

    labBtn?.addEventListener('click', () => {
      const player = this.state.getPlayerFaction();
      if (player && (player.tier || 1) < FactionTier.EARLY_STATE) {
        alert('🔬 Научно-Исследовательская Лаборатория становится доступна с Тира «Цивилизация» (Тир 3)!');
        return;
      }
      this.renderResearchModal();
      modal?.classList.remove('hidden');
    });

    closeBtn?.addEventListener('click', () => {
      modal?.classList.add('hidden');
    });
  }

  renderResearchModal(): void {
    const treeEl = document.getElementById('research-tech-tree');
    const scienceVal = document.getElementById('research-science-val');
    if (!treeEl) return;

    const player = this.state.getPlayerFaction();
    if (!player) return;

    if (scienceVal) scienceVal.textContent = `${player.sciencePoints ?? 0}`;

    const unlocked = player.unlockedTechs || [];

    treeEl.innerHTML = RESEARCH_TECHS.map(tech => {
      const isUnlocked = unlocked.includes(tech.id);
      const preMet = tech.prerequisites.every(p => unlocked.includes(p));
      const canAfford = (player.sciencePoints ?? 0) >= tech.cost;

      let btnText = `Изучить (${tech.cost} 🔬)`;
      let btnDisabled = false;

      if (isUnlocked) {
        btnText = '✅ Изучено';
        btnDisabled = true;
      } else if (!preMet) {
        const missing = tech.prerequisites.filter(p => !unlocked.includes(p)).map(p => {
          const pt = RESEARCH_TECHS.find(t => t.id === p);
          return pt?.name || p;
        });
        btnText = `🔒 Требуется: ${missing.join(', ')}`;
        btnDisabled = true;
      } else if (!canAfford) {
        btnDisabled = true;
      }

      return `
        <div class="dogma-card ${isUnlocked ? 'unlocked' : ''}" style="border: 1px solid ${isUnlocked ? '#2ecc71' : '#30363d'}; background: rgba(13,17,23,0.85); padding:12px; border-radius:8px; display:flex; flex-direction:column; justify-content:space-between;">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
              <span style="font-size:1.8rem;">${tech.icon}</span>
              <span style="font-size:0.75rem; background:#21262d; border-radius:4px; padding:2px 6px; color:#58a6ff;">${tech.age}</span>
            </div>
            <div style="font-weight:700; color:#f0f6fc; margin-bottom:4px; font-size:0.95rem;">${tech.name}</div>
            <div style="font-size:0.8rem; color:#8b949e; margin-bottom:6px;">${tech.desc}</div>
            <div style="font-size:0.82rem; color:#2ecc71; margin-bottom:10px; font-weight:600;">✨ ${tech.effectText}</div>
          </div>
          <button class="modal-btn ${isUnlocked ? 'secondary' : 'primary'} btn-tech-research" data-tech-id="${tech.id}" ${btnDisabled ? 'disabled' : ''} style="width:100%; margin-top:8px;">
            ${btnText}
          </button>
        </div>
      `;
    }).join('');

    treeEl.querySelectorAll('.btn-tech-research').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const techId = (e.currentTarget as HTMLElement).dataset.techId;
        if (techId) {
          const res = this.state.unlockResearchTech(techId);
          if (res.success) {
            this.renderResearchModal();
            this.updateHUD();
            this.updateChronicles();
            this.onRenderRequest();
          } else {
            alert(res.message);
          }
        }
      });
    });
  }

  // --- Politics & Regimes Setup & Rendering ---
  private setupPolitics(): void {
    const polBtn = document.getElementById('btn-politics');
    const modal = document.getElementById('politics-modal');
    const closeBtn = document.getElementById('btn-politics-close');

    polBtn?.addEventListener('click', () => {
      this.renderPoliticsModal();
      modal?.classList.remove('hidden');
    });

    closeBtn?.addEventListener('click', () => {
      modal?.classList.add('hidden');
    });

    // Top HUD tax rate cycle button
    const taxRateBtn = document.getElementById('btn-tax-rate');
    taxRateBtn?.addEventListener('click', () => {
      const player = this.state.getPlayerFaction();
      if (!player) return;
      const current = player.taxRate || 'NORMAL';
      const next: Record<'LOW' | 'NORMAL' | 'HIGH', 'LOW' | 'NORMAL' | 'HIGH'> = {
        'LOW': 'NORMAL',
        'NORMAL': 'HIGH',
        'HIGH': 'LOW'
      };
      this.state.setTaxRate(next[current]);
      this.updateHUD();
      this.renderPoliticsModal();
    });

    // Taxes row inside modal
    ['LOW', 'NORMAL', 'HIGH'].forEach(rate => {
      const btn = document.getElementById(`btn-tax-${rate.toLowerCase()}`);
      btn?.addEventListener('click', () => {
        this.state.setTaxRate(rate as 'LOW' | 'NORMAL' | 'HIGH');
        this.updateHUD();
        this.renderPoliticsModal();
      });
    });
  }

  renderPoliticsModal(): void {
    const list = document.getElementById('regimes-list');
    if (!list) return;

    const player = this.state.getPlayerFaction();
    if (!player) return;

    const currentRegime = player.regime || PoliticalRegime.TRIBAL_COUNCIL;

    const regimes = [
      {
        id: PoliticalRegime.TRIBAL_COUNCIL,
        name: 'Племенной Совет Вождей',
        icon: '⛺',
        desc: 'Древнейшая форма самоуправления. Сплоченность кочевий и фронтира повышена на +15%, но сбор налогов снижен на -10%.'
      },
      {
        id: PoliticalRegime.MONARCHY,
        name: 'Монархия (Царская Власть)',
        icon: '👑',
        desc: 'Единовластие государя. Легитимность правителя +15%, дистанция эффективного снабжения увеличена на +1 гекс.'
      },
      {
        id: PoliticalRegime.REPUBLIC,
        name: 'Республика (Сенат и Собрание)',
        icon: '🏛️',
        desc: 'Власть граждан и законов. +25% к очкам Науки и генерации золота от рынков, но верность армий падает быстрее (-10%).'
      },
      {
        id: PoliticalRegime.DICTATORSHIP,
        name: 'Военная Диктатура (Хунта)',
        icon: '⚔️',
        desc: 'Власть генералов и стального кулака. Сила всех армий +30%, полное подавление смут и мятежей, но штраф к науке -15%.'
      }
    ];

    list.innerHTML = regimes.map(reg => {
      const isActive = currentRegime === reg.id;
      return `
        <div class="dogma-card ${isActive ? 'unlocked' : ''}" style="border: 1px solid ${isActive ? '#f1c40f' : '#30363d'}; background: rgba(13,17,23,0.85); padding:12px; border-radius:8px;">
          <div style="font-size:1.8rem; margin-bottom:4px;">${reg.icon}</div>
          <div style="font-weight:700; color:#f0f6fc; margin-bottom:4px;">${reg.name}</div>
          <div style="font-size:0.8rem; color:#8b949e; margin-bottom:10px; line-height:1.4;">${reg.desc}</div>
          <button class="modal-btn ${isActive ? 'secondary' : 'primary'} btn-select-regime" data-regime="${reg.id}" ${isActive ? 'disabled' : ''} style="width:100%;">
            ${isActive ? '✅ Действующий строй' : 'Утвердить строй'}
          </button>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.btn-select-regime').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const regId = (e.currentTarget as HTMLElement).dataset.regime as PoliticalRegime;
        if (regId) {
          this.state.setPoliticalRegime(regId);
          this.renderPoliticsModal();
          this.updateHUD();
          this.updateChronicles();
        }
      });
    });

    // Update tax buttons highlighting inside modal
    const currentTax = player.taxRate || 'NORMAL';
    ['LOW', 'NORMAL', 'HIGH'].forEach(rate => {
      const btn = document.getElementById(`btn-tax-${rate.toLowerCase()}`);
      if (btn) {
        if (currentTax === rate) {
          btn.className = 'modal-btn primary tax-option-btn';
        } else {
          btn.className = 'modal-btn secondary tax-option-btn';
        }
      }
    });
  }

  // --- Victory Modal Setup ---
  private setupVictoryModal(): void {
    const modal = document.getElementById('victory-modal');
    const titleEl = document.getElementById('victory-title');
    const descEl = document.getElementById('victory-desc');
    const continueBtn = document.getElementById('btn-victory-continue');
    const restartBtn = document.getElementById('btn-victory-restart');

    EventBus.on('VICTORY_ACHIEVED', (data: any) => {
      if (modal && titleEl && descEl) {
        titleEl.textContent = data.type === 'SCIENTIFIC'
          ? '🚀 НАУЧНЫЙ ТРИУМФ!'
          : data.type === 'MILITARY'
          ? '⚔️ ВОЕННАЯ ГЕГЕМОНИЯ!'
          : '📜 КУЛЬТУРНОЕ ЕДИНСТВО!';
        descEl.textContent = data.text;
        modal.classList.remove('hidden');
      }
    });

    continueBtn?.addEventListener('click', () => {
      modal?.classList.add('hidden');
    });

    restartBtn?.addEventListener('click', () => {
      SaveManager.clearSavedGame();
      window.location.reload();
    });
  }

  // --- Historical Quests & Dilemmas Modal Setup ---
  private setupQuestModal(): void {
    EventBus.on('QUEST_TRIGGERED', (quest: QuestEvent) => {
      this.showQuestModal(quest);
    });
  }

  private showQuestModal(quest: QuestEvent): void {
    const modal = document.getElementById('quest-modal');
    const iconEl = document.getElementById('quest-icon');
    const titleEl = document.getElementById('quest-title');
    const descEl = document.getElementById('quest-desc');
    const choicesEl = document.getElementById('quest-choices');

    if (!modal || !titleEl || !descEl || !choicesEl) return;

    if (iconEl) iconEl.textContent = quest.icon;
    titleEl.textContent = quest.title;
    descEl.textContent = quest.description;

    choicesEl.innerHTML = '';

    quest.choices.forEach(choice => {
      const btn = document.createElement('button');
      btn.className = 'quest-choice-btn';
      const canAfford = choice.canAfford(this.state);

      btn.disabled = !canAfford;

      let html = `<div class="quest-choice-title">${choice.text}</div>`;
      if (choice.costDesc) {
        html += `<div class="quest-choice-cost">Стоимость: ${choice.costDesc}</div>`;
      }
      html += `<div class="quest-choice-effect">Эффект: ${choice.effectDesc}</div>`;
      btn.innerHTML = html;

      btn.addEventListener('click', () => {
        this.state.resolveQuest(choice.id);
        modal.classList.add('hidden');
        this.updateHUD();
        this.updateInspector();
        this.updateChronicles();
        this.onRenderRequest();
      });

      choicesEl.appendChild(btn);
    });

    modal.classList.remove('hidden');
  }
}
