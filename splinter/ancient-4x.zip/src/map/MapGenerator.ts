// Procedural Earth World Map Generator (60x40) with Polygonal Province Clusters
import { HexCoord } from './HexCoord.ts';
import { HexTile, BiomeType, ResourceType, TribalCamp, Faction, City, Culture, Unit, UnitType, UnrestStage, Province, StarterCultureChoice, DiplomaticStatus, FactionTier } from '../entities/Types.ts';
import { PerlinNoise2D, PRNG } from '../utils/Noise.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';
import { NameGenerator } from '../utils/NameGenerator.ts';
import { RulerSystem } from '../simulation/RulerSystem.ts';

export interface GeneratedWorld {
  tiles: Map<string, HexTile>;
  provinces: Map<string, Province>;
  factions: Map<string, Faction>;
  cultures: Map<string, Culture>;
  cities: Map<string, City>;
  units: Map<string, Unit>;
  width: number;
  height: number;
}

export class MapGenerator {
  private prng: PRNG;
  private elevNoise: PerlinNoise2D;
  private moistNoise: PerlinNoise2D;

  constructor(seed: number = GAME_CONSTANTS.MAP.SEED) {
    this.prng = new PRNG(seed);
    this.elevNoise = new PerlinNoise2D(seed);
    this.moistNoise = new PerlinNoise2D(seed + 999);
  }

  generate(
    width: number = GAME_CONSTANTS.MAP.WIDTH,
    height: number = GAME_CONSTANTS.MAP.HEIGHT,
    playerChoice: StarterCultureChoice = 'RIVER_FARMERS'
  ): GeneratedWorld {
    const tiles = new Map<string, HexTile>();
    const provinces = new Map<string, Province>();
    const factions = new Map<string, Faction>();
    const cultures = new Map<string, Culture>();
    const cities = new Map<string, City>();
    const units = new Map<string, Unit>();

    // 1. Generate Earth land/water matrix (60x40)
    for (let row = 0; row < height; row++) {
      for (let col = 0; col < width; col++) {
        // Pointy-topped axial coordinates
        const q = col - Math.floor(row / 2);
        const r = row;
        const coord = new HexCoord(q, r);

        const isLand = this.checkEarthLand(col, row);
        const elev = this.calculateEarthElevation(col, row, isLand);
        const moist = this.calculateEarthMoisture(col, row, isLand);
        const biome = this.determineBiome(isLand, col, row, elev, moist);
        const fertility = this.calculateFertility(biome);
        const moveCost = this.calculateMovementCost(biome);

        const tile: HexTile = {
          q,
          r,
          col,
          row,
          provinceId: null,
          biome,
          elevation: elev,
          moisture: moist,
          fertility,
          movementCost: moveCost,
          resource: ResourceType.NONE,
          isRiver: false,
          hasRoad: false,
          ownerFactionId: null,
          cityId: null,
          unitId: null,
          tribalCamp: null
        };

        tiles.set(coord.key, tile);
      }
    }

    // 2. Carve Famous Earth Ancient Rivers (Nile, Tigris, Euphrates, Indus, Yellow, Danube, Mississippi)
    this.carveMajorEarthRivers(tiles);

    // 3. Group Land Hexes into Polygonal Provinces (5–9 hexes each)
    this.clusterPolygonalProvinces(tiles, provinces, width, height);

    // 4. Distribute Strategic Resources
    this.distributeResources(tiles, provinces);

    // 5. Spawn Frontier Tribal Camps on Wilderness Provinces
    this.spawnFrontierTribes(provinces, tiles);

    // 6. Seed Starting Ancient Empires on Historic Cradles (Mesopotamia, Steppes, Zagros, Nile, Indus, Yellow River)
    this.seedAncientEmpires(tiles, provinces, factions, cultures, cities, units, playerChoice);

    return {
      tiles,
      provinces,
      factions,
      cultures,
      cities,
      units,
      width,
      height
    };
  }

  // --- Earth Landmass Geography Mask (60 columns x 40 rows) ---
  private checkEarthLand(col: number, row: number): boolean {
    // Arctic ice caps / edges
    if (row <= 2 || row >= 39) return false;

    // Small boundary noise to make coastlines natural
    const noise = this.elevNoise.noise(col * 0.45, row * 0.45) * 0.9;
    const c = col + noise;
    const r = row + noise;

    // 1. North America
    // Alaska
    if (c >= 1 && c <= 6 && r >= 5 && r <= 8) return true;
    // Canada / Arctic Islands
    if (c >= 6 && c <= 18 && r >= 4 && r <= 10) return true;
    // Greenland
    if (c >= 18 && c <= 22 && r >= 3 && r <= 7) return true;
    // USA
    if (c >= 6 && c <= 19 && r >= 10 && r <= 17) {
      // Exclude Atlantic water notch
      if (c >= 18 && r >= 14) return false;
      return true;
    }
    // Mexico & Central America
    if (c >= 7 && c <= 14 && r >= 17 && r <= 23) {
      if (c >= 13 && r >= 18 && r <= 20) return false; // Gulf of Mexico
      return true;
    }
    // Caribbean
    if (c >= 14 && c <= 17 && r >= 20 && r <= 22 && this.prng.next() < 0.3) return true;

    // 2. South America
    // Colombia / Venezuela / Guiana
    if (c >= 12 && c <= 19 && r >= 22 && r <= 25) return true;
    // Amazon / Brazil
    if (c >= 13 && c <= 23 && r >= 25 && r <= 32) {
      if (c >= 22 && r >= 30) return false; // South Atlantic curve
      return true;
    }
    // Andes / Peru / Bolivia / Chile
    if (c >= 11 && c <= 16 && r >= 25 && r <= 38) return true;
    // Argentina / Patagonia
    if (c >= 14 && c <= 18 && r >= 31 && r <= 38) return true;

    // 3. Europe
    // British Isles
    if (c >= 24 && c <= 27 && r >= 9 && r <= 13) return true;
    // Scandinavia
    if (c >= 28 && c <= 33 && r >= 4 && r <= 9) return true;
    // Iberia (Spain & Portugal)
    if (c >= 23 && c <= 27 && r >= 14 && r <= 17) return true;
    // France & Central Europe
    if (c >= 26 && c <= 33 && r >= 11 && r <= 15) return true;
    // Italy
    if (c >= 29 && c <= 31 && r >= 15 && r <= 18) return true;
    // Balkans & Greece
    if (c >= 32 && c <= 35 && r >= 14 && r <= 19) return true;
    // Eastern Europe / Western Russia
    if (c >= 33 && c <= 41 && r >= 7 && r <= 15) return true;

    // 4. Africa
    // Maghreb / North Africa Coast
    if (c >= 23 && c <= 32 && r >= 18 && r <= 21) return true;
    // Egypt & Nile
    if (c >= 33 && c <= 36 && r >= 19 && r <= 24) return true;
    // Sahara
    if (c >= 24 && c <= 36 && r >= 21 && r <= 25) return true;
    // West Africa / Guinea
    if (c >= 22 && c <= 29 && r >= 24 && r <= 28) return true;
    // Central Africa / Congo
    if (c >= 28 && c <= 36 && r >= 25 && r <= 31) return true;
    // East Africa / Horn
    if (c >= 35 && c <= 40 && r >= 21 && r <= 28) return true;
    // Southern Africa
    if (c >= 29 && c <= 36 && r >= 31 && r <= 36) return true;
    // Madagascar
    if (c >= 38 && c <= 40 && r >= 30 && r <= 34) return true;

    // 5. Middle East
    // Anatolia
    if (c >= 34 && c <= 38 && r >= 15 && r <= 18) return true;
    // Levant & Mesopotamia
    if (c >= 35 && c <= 39 && r >= 17 && r <= 21) return true;
    // Arabia
    if (c >= 36 && c <= 41 && r >= 21 && r <= 26) {
      if (c >= 39 && r >= 21 && r <= 22) return false; // Persian Gulf notch
      return true;
    }
    // Persia / Iran
    if (c >= 38 && c <= 43 && r >= 16 && r <= 21) return true;

    // 6. Asia
    // Urals & Siberia
    if (c >= 38 && c <= 57 && r >= 4 && r <= 11) return true;
    // Central Asian Steppes
    if (c >= 39 && c <= 48 && r >= 11 && r <= 17) return true;
    // India
    if (c >= 41 && c <= 47 && r >= 18 && r <= 27) return true;
    // China
    if (c >= 45 && c <= 54 && r >= 13 && r <= 23) return true;
    // Korea
    if (c >= 52 && c <= 54 && r >= 14 && r <= 17) return true;
    // Japan
    if (c >= 55 && c <= 58 && r >= 13 && r <= 18) return true;
    // Indochina / SE Asia
    if (c >= 47 && c <= 53 && r >= 22 && r <= 27) return true;
    // Indonesia & Philippines (strictly capped at row 27 to preserve ocean channel)
    if (c >= 48 && c <= 56 && r >= 26 && r <= 27 && this.prng.next() < 0.45) return true;

    // Strict Water Barrier Guarantee between Eurasia/SE Asia and Australia
    // Guaranteed Ocean band at rows 28-30 so no land bridges can form between Eurasia and Australia
    if (row >= 28 && row <= 30 && col >= 45 && col <= 60) {
      return false; // Guaranteed Ocean: Timor Sea, Arafura Sea, Torres Strait
    }

    // 7. Australia & Oceania (strictly starts at row 31+)
    // Australia Mainland
    if (c >= 50 && c <= 58 && r >= 31 && r <= 37) {
      if (c >= 53 && c <= 55 && r >= 31 && r <= 32) return false; // Gulf of Carpentaria
      return true;
    }
    // New Zealand
    if (c >= 57 && c <= 59 && r >= 35 && r <= 38) return true;

    return false;
  }

  private calculateEarthElevation(col: number, row: number, isLand: boolean): number {
    if (!isLand) return 0.12;

    let elev = 0.45;
    // Mountain Chains
    // Andes
    if (col >= 11 && col <= 15 && row >= 22 && row <= 37) elev = 0.88;
    // Rockies
    if (col >= 7 && col <= 11 && row >= 8 && row <= 16) elev = 0.84;
    // Alps
    if (col >= 28 && col <= 32 && row >= 13 && row <= 15) elev = 0.85;
    // Zagros / Caucasus
    if (col >= 36 && col <= 41 && row >= 15 && row <= 19) elev = 0.86;
    // Himalayas / Tibetan Plateau
    if (col >= 43 && col <= 49 && row >= 16 && row <= 20) elev = 0.95;
    // Urals
    if (col >= 40 && col <= 42 && row >= 5 && row <= 12) elev = 0.72;

    return Math.min(0.98, Math.max(0.3, elev + this.elevNoise.noise(col * 0.3, row * 0.3) * 0.1));
  }

  private calculateEarthMoisture(col: number, row: number, isLand: boolean): number {
    if (!isLand) return 1.0;

    // Deserts
    // Sahara
    if (col >= 24 && col <= 34 && row >= 20 && row <= 24) return 0.08;
    // Arabia
    if (col >= 36 && col <= 41 && row >= 21 && row <= 25) return 0.10;
    // Gobi
    if (col >= 44 && col <= 50 && row >= 14 && row <= 16) return 0.12;
    // Australian Outback
    if (col >= 51 && col <= 56 && row >= 32 && row <= 35) return 0.12;

    // Rainforests
    // Amazon
    if (col >= 14 && col <= 21 && row >= 24 && row <= 30) return 0.88;
    // Congo
    if (col >= 29 && col <= 34 && row >= 26 && row <= 29) return 0.85;

    return 0.45 + this.moistNoise.noise(col * 0.25, row * 0.25) * 0.25;
  }

  private determineBiome(isLand: boolean, col: number, row: number, elev: number, moist: number): BiomeType {
    if (!isLand) return BiomeType.OCEAN;
    if (elev > 0.82) return BiomeType.MOUNTAINS;
    if (elev > 0.68) return BiomeType.HILLS;

    if (moist < 0.18) return BiomeType.DESERT;
    if (moist < 0.35) return BiomeType.STEPPE;
    if (moist > 0.65) return BiomeType.FOREST;

    // Fertile Plains
    return BiomeType.FERTILE_PLAINS;
  }

  private calculateFertility(biome: BiomeType): number {
    switch (biome) {
      case BiomeType.OCEAN: return 0;
      case BiomeType.RIVER_VALLEY: return 5;
      case BiomeType.FERTILE_PLAINS: return 4;
      case BiomeType.FOREST: return 2;
      case BiomeType.STEPPE: return 2;
      case BiomeType.HILLS: return 2;
      case BiomeType.DESERT: return 1;
      case BiomeType.MOUNTAINS: return 0;
    }
  }

  private calculateMovementCost(biome: BiomeType): number {
    switch (biome) {
      case BiomeType.OCEAN: return 4.0;
      case BiomeType.MOUNTAINS: return 8.0;
      case BiomeType.HILLS: return 2.2;
      case BiomeType.FOREST: return 2.0;
      case BiomeType.STEPPE: return 1.2;
      case BiomeType.FERTILE_PLAINS: return 1.0;
      case BiomeType.RIVER_VALLEY: return 1.0;
      case BiomeType.DESERT: return 1.8;
    }
  }

  private carveMajorEarthRivers(tiles: Map<string, HexTile>): void {
    // Historic river traces [col, row]
    const riverPaths = [
      // Nile
      [[34, 25], [34, 24], [34, 23], [34, 22], [34, 21], [34, 20]],
      // Tigris & Euphrates
      [[36, 17], [36, 18], [37, 18], [37, 19], [38, 19]],
      // Indus
      [[43, 19], [43, 20], [42, 21], [42, 22]],
      // Yellow River
      [[47, 16], [48, 16], [49, 16], [50, 16]],
      // Yangtze
      [[47, 18], [48, 18], [50, 18], [51, 18]],
      // Danube
      [[28, 14], [30, 14], [32, 14], [34, 15]],
      // Mississippi
      [[13, 11], [13, 13], [14, 14], [14, 16]]
    ];

    for (const path of riverPaths) {
      for (const [col, row] of path) {
        const q = col - Math.floor(row / 2);
        const r = row;
        const tile = tiles.get(`${q},${r}`);
        if (tile && tile.biome !== BiomeType.OCEAN) {
          tile.isRiver = true;
          if (tile.biome !== BiomeType.MOUNTAINS) {
            tile.biome = BiomeType.RIVER_VALLEY;
            tile.fertility = 5;
            tile.movementCost = 1.0;
          }
        }
      }
    }
  }

  // --- 3. Polygonal Province Clustering Algorithm (5-9 hexes each) ---
  private clusterPolygonalProvinces(
    tiles: Map<string, HexTile>,
    provinces: Map<string, Province>,
    width: number,
    height: number
  ): void {
    const landTiles = Array.from(tiles.values()).filter(t => t.biome !== BiomeType.OCEAN);
    if (landTiles.length === 0) return;

    const unassigned = new Set<string>(landTiles.map(t => `${t.q},${t.r}`));
    const provinceHexes = new Map<string, string[]>();

    // Step A: Seed selection (spaced discrete seeds separated by at least 2.5 hexes)
    const seeds: HexTile[] = [];
    const shuffledLand = [...landTiles].sort(() => 0.5 - this.prng.next());

    for (const tile of shuffledLand) {
      const coord = new HexCoord(tile.q, tile.r);
      let tooClose = false;
      for (const s of seeds) {
        if (coord.distanceTo(new HexCoord(s.q, s.r)) < 2.5) {
          tooClose = true;
          break;
        }
      }
      if (!tooClose) {
        seeds.push(tile);
      }
    }

    // Colors palette for provinces
    const PROVINCE_PALETTES = [
      '#3d5a45', '#4e6d42', '#5c6b3e', '#6e6b45', '#556644',
      '#48604d', '#5a7350', '#637048', '#4f5e3d', '#5d6840',
      '#465842', '#6b7a54', '#586b4f', '#647347', '#506649'
    ];

    // Historical & regional province names
    const REGION_NAMES = [
      'Нижняя Месопотамия', 'Верхняя Месопотамия', 'Дельта Нила', 'Верхний Египет', 'Элам',
      'Загрос', 'Ханаан', 'Финикия', 'Анатолия', 'Киликия', 'Фракия', 'Эллада', 'Пелопоннес',
      'Лациум', 'Этрурия', 'Галлия', 'Аквитания', 'Иберия', 'Британия', 'Скандия', 'Германия',
      'Сарматия', 'Скифия', 'Бактрия', 'Согдиана', 'Пенджаб', 'Ганг', 'Хуанхэ', 'Шаньдун',
      'Янцзы', 'Нубия', 'Пунт', 'Сахель', 'Магриб', 'Киренаика', 'Сибирь', 'Алтай', 'Маньчжурия',
      'Индокитай', 'Ява', 'Лусон', 'Кимберли', 'Квинсленд', 'Миссисипи', 'Юкатан', 'Анды',
      'Амазония', 'Пампа', 'Куба', 'Гренландия'
    ];

    let provIdx = 0;

    // Step B: Initialize provinces at seeds
    const frontiers = new Map<string, HexCoord[]>(); // provinceId -> adjacent open frontier

    for (const seed of seeds) {
      const pId = `prov_${provIdx + 1}`;
      const name = REGION_NAMES[provIdx % REGION_NAMES.length] || `Провинция ${provIdx + 1}`;
      const baseColor = PROVINCE_PALETTES[provIdx % PROVINCE_PALETTES.length];

      const prov: Province = {
        id: pId,
        name,
        centerQ: seed.q,
        centerR: seed.r,
        hexKeys: [`${seed.q},${seed.r}`],
        biome: seed.biome,
        baseColor,
        fertility: seed.fertility,
        ownerFactionId: null,
        dominantCultureId: null,
        cityId: null,
        authority: 80,
        accumulatedDrift: 0,
        unrestStage: UnrestStage.INTEGRATED,
        tribalCamp: null
      };

      provinces.set(pId, prov);
      provinceHexes.set(pId, [`${seed.q},${seed.r}`]);
      seed.provinceId = pId;
      unassigned.delete(`${seed.q},${seed.r}`);

      frontiers.set(pId, new HexCoord(seed.q, seed.r).neighbors());
      provIdx++;
    }

    // Step C: Multi-source BFS growth to reach 5-9 hexes per province
    let expanded = true;
    while (expanded && unassigned.size > 0) {
      expanded = false;

      for (const [pId, prov] of provinces.entries()) {
        const curHexes = provinceHexes.get(pId) || [];
        if (curHexes.length >= 8) continue; // Target optimal size 7-8 hexes

        const frontier = frontiers.get(pId) || [];
        const nextFrontier: HexCoord[] = [];

        for (const neighbor of frontier) {
          const key = neighbor.key;
          if (unassigned.has(key)) {
            // Claim hex for this province!
            unassigned.delete(key);
            curHexes.push(key);
            const tile = tiles.get(key);
            if (tile) {
              tile.provinceId = pId;
            }
            expanded = true;

            // Add its neighbors to frontier
            for (const n of neighbor.neighbors()) {
              if (unassigned.has(n.key)) nextFrontier.push(n);
            }

            if (curHexes.length >= 8) break;
          }
        }

        frontiers.set(pId, nextFrontier);
      }
    }

    // Step D: Merge leftover unassigned stray land hexes into adjacent province
    for (const key of Array.from(unassigned)) {
      const tile = tiles.get(key);
      if (!tile) continue;

      const coord = new HexCoord(tile.q, tile.r);
      for (const n of coord.neighbors()) {
        const nTile = tiles.get(n.key);
        if (nTile && nTile.provinceId) {
          tile.provinceId = nTile.provinceId;
          const p = provinces.get(nTile.provinceId);
          if (p && !p.hexKeys.includes(key)) {
            p.hexKeys.push(key);
          }
          unassigned.delete(key);
          break;
        }
      }
    }

    // Step E: Recalculate true centroid and finalize province hex list
    for (const [pId, prov] of provinces.entries()) {
      const hexList = provinceHexes.get(pId) || [];
      prov.hexKeys = hexList;

      if (hexList.length > 0) {
        // Average coordinates
        let sumQ = 0, sumR = 0;
        for (const k of hexList) {
          const c = HexCoord.fromKey(k);
          sumQ += c.q;
          sumR += c.r;
        }
        const avgQ = Math.round(sumQ / hexList.length);
        const avgR = Math.round(sumR / hexList.length);

        // Pick closest actual hex in the province
        let closestKey = hexList[0];
        let minDist = 999;
        const target = new HexCoord(avgQ, avgR);
        for (const k of hexList) {
          const c = HexCoord.fromKey(k);
          const d = c.distanceTo(target);
          if (d < minDist) {
            minDist = d;
            closestKey = k;
          }
        }
        const centerCoord = HexCoord.fromKey(closestKey);
        prov.centerQ = centerCoord.q;
        prov.centerR = centerCoord.r;
      }
    }
  }

  private distributeResources(tiles: Map<string, HexTile>, provinces: Map<string, Province>): void {
    for (const tile of tiles.values()) {
      if (tile.biome === BiomeType.OCEAN || tile.biome === BiomeType.MOUNTAINS) continue;

      const roll = this.prng.next();
      if (roll < 0.06) {
        if (tile.biome === BiomeType.HILLS) {
          tile.resource = this.prng.next() > 0.5 ? ResourceType.COPPER : ResourceType.TIN;
        } else if (tile.biome === BiomeType.STEPPE) {
          tile.resource = this.prng.next() > 0.5 ? ResourceType.HORSES : ResourceType.CATTLE;
        } else if (tile.biome === BiomeType.FERTILE_PLAINS) {
          tile.resource = this.prng.next() > 0.5 ? ResourceType.CATTLE : ResourceType.FERTILE_SILT;
        } else if (tile.biome === BiomeType.DESERT) {
          tile.resource = ResourceType.INCENSE;
        } else if (tile.biome === BiomeType.RIVER_VALLEY) {
          tile.resource = this.prng.next() > 0.6 ? ResourceType.INCENSE : ResourceType.FERTILE_SILT;
        } else if (tile.biome === BiomeType.FOREST) {
          tile.resource = ResourceType.TIMBER;
        }
      } else if (roll < 0.08 && tile.biome === BiomeType.HILLS) {
        tile.resource = ResourceType.GOLD;
      } else if (roll < 0.10 && tile.isRiver) {
        tile.resource = ResourceType.CLAY;
      }
    }
  }

  private spawnFrontierTribes(provinces: Map<string, Province>, tiles: Map<string, HexTile>): void {
    let tribeIdx = 0;

    for (const prov of provinces.values()) {
      // Wilderness provinces (Steppes, Forests, Hills far away from start valleys)
      const isWild = prov.biome === BiomeType.STEPPE || prov.biome === BiomeType.FOREST || prov.biome === BiomeType.HILLS;

      if (isWild && this.prng.next() < 0.28) {
        const root = NameGenerator.generateCityName('STEPPE');
        const tribeCamp: TribalCamp = {
          name: `${root} (кочевники)`,
          warriors: this.prng.intRange(2, 5),
          cultureName: `Автохтонные ${root}`,
          syncretismValue: 25
        };

        prov.tribalCamp = tribeCamp;
        // Place on province center tile
        const centerTile = tiles.get(`${prov.centerQ},${prov.centerR}`);
        if (centerTile) {
          centerTile.tribalCamp = tribeCamp;
        }
      }
    }
  }

  // --- Seed Ancient Empires on Earth Cradles ---
  private seedAncientEmpires(
    tiles: Map<string, HexTile>,
    provinces: Map<string, Province>,
    factions: Map<string, Faction>,
    cultures: Map<string, Culture>,
    cities: Map<string, City>,
    units: Map<string, Unit>,
    playerChoice: StarterCultureChoice
  ): void {
    const factionDefinitions = [
      {
        choiceKey: 'RIVER_FARMERS' as StarterCultureChoice,
        id: 'faction_river',
        cultId: 'culture_river',
        cultName: 'Речные Земледельцы',
        defaultCityName: 'Урук',
        defaultFactionName: 'Шумерское Царство',
        color: '#e67e22',
        style: 'MESOPOTAMIAN' as const,
        traits: ['Ирригаторы Двуречья', 'Храмовые амбары', 'Экспансия вдоль рек +25%'],
        col: 37,
        row: 19
      },
      {
        choiceKey: 'STEPPE_NOMADS' as StarterCultureChoice,
        id: 'faction_steppe',
        cultId: 'culture_steppe',
        cultName: 'Степные Кочевники',
        defaultCityName: 'Сарайшык',
        defaultFactionName: 'Степной Каганат',
        color: '#27ae60',
        style: 'STEPPE' as const,
        traits: ['Всадники Степей', 'Игнорирование штрафов пустыни', 'Скорость разведки +1'],
        col: 43,
        row: 14
      },
      {
        choiceKey: 'MOUNTAIN_TOTEMISTS' as StarterCultureChoice,
        id: 'faction_mountain',
        cultId: 'culture_mountain',
        cultName: 'Горные Тотемисты',
        defaultCityName: 'Сузы',
        defaultFactionName: 'Эламское Нагорье',
        color: '#9b59b6',
        style: 'ELAMITE' as const,
        traits: ['Горные Тотемы', 'Сплоченность нагорья +30%', 'Крепости ущелий'],
        col: 40,
        row: 19
      },
      {
        choiceKey: null,
        id: 'faction_nile',
        cultId: 'culture_nile',
        cultName: 'Дельта Нила',
        defaultCityName: 'Мемфис',
        defaultFactionName: 'Нильское Царство',
        color: '#d4ac0d',
        style: 'LEVANTINE' as const,
        traits: ['Благодать Нила', 'Каменные пирамиды', 'Фараонова власть'],
        col: 34,
        row: 21
      },
      {
        choiceKey: null,
        id: 'faction_indus',
        cultId: 'culture_indus',
        cultName: 'Долина Инда',
        defaultCityName: 'Мохенджо',
        defaultFactionName: 'Хараппская Держава',
        color: '#2980b9',
        style: 'MESOPOTAMIAN' as const,
        traits: ['Речные фактории', 'Каменные цитадели', 'Морская торговля'],
        col: 42,
        row: 21
      },
      {
        choiceKey: null,
        id: 'faction_china',
        cultId: 'culture_china',
        cultName: 'Хуанхэ',
        defaultCityName: 'Аньян',
        defaultFactionName: 'Поднебесная Империя',
        color: '#c0392b',
        style: 'MESOPOTAMIAN' as const,
        traits: ['Срединные равнины', 'Бронзовое литье', 'Стены гарнизонов'],
        col: 48,
        row: 16
      }
    ];

    // 1. Create Cultures, Factions, Capital Cities and Starting Units
    for (const def of factionDefinitions) {
      // Culture
      const culture: Culture = {
        id: def.cultId,
        name: def.cultName,
        parentId: null,
        divergenceTurn: 0,
        color: def.color,
        traits: def.traits
      };
      cultures.set(culture.id, culture);

      // Is this faction the one picked by the player?
      const isPlayer = def.choiceKey === playerChoice;

      // Ruler
      const ruler = RulerSystem.generateRuler(def.style);

      // Faction
      const faction: Faction = {
        id: def.id,
        name: def.defaultFactionName,
        color: def.color,
        capitalCityId: `city_cap_${def.id}`,
        rootCultureId: def.cultId,
        isPlayer,
        isBreakaway: false,
        gold: isPlayer ? 180 : 140,
        grain: isPlayer ? 240 : 180,
        overextension: 10,
        atWarWith: [],
        ruler,
        isInterregnum: false,
        interregnumTurnsLeft: 0,
        diplomacy: {},
        culturePoints: isPlayer ? 40 : 20,
        unlockedDogmas: [],
        resources: {
          copper: isPlayer ? 2 : 1,
          tin: isPlayer ? 1 : 1,
          cattle: isPlayer ? 3 : 2,
          incense: isPlayer ? 2 : 1
        },
        tier: FactionTier.TRIBE,
        outposts: []
      };
      factions.set(faction.id, faction);

      // Capital City & Province Claim
      const q = def.col - Math.floor(def.row / 2);
      const r = def.row;
      const capCoord = new HexCoord(q, r);

      this.createCityInProvince(
        capCoord,
        `city_cap_${def.id}`,
        `${def.defaultCityName} (Столица)`,
        faction.id,
        def.cultId,
        16,
        95,
        tiles,
        provinces,
        cities
      );

      // Garrison Spearmen for everyone
      this.createUnit(
        capCoord,
        `unit_guard_${def.id}`,
        `Стража ${def.defaultCityName}а`,
        UnitType.SPEARMEN,
        faction.id,
        100,
        2,
        10,
        tiles,
        units
      );

      // If player, also spawn a Settler unit
      if (isPlayer) {
        const settlerCoord = new HexCoord(q - 1, r);
        this.createUnit(
          settlerCoord,
          `unit_settler_${def.id}`,
          'Отряд Колонистов',
          UnitType.SETTLER,
          faction.id,
          100,
          2,
          0,
          tiles,
          units
        );
      }
    }

    // 2. Initialize Pairwise Diplomatic Relations between all factions
    for (const f1 of factions.values()) {
      for (const f2 of factions.values()) {
        if (f1.id !== f2.id) {
          f1.diplomacy[f2.id] = {
            status: DiplomaticStatus.PEACE,
            opinion: 15,
            pactTurnsLeft: 0
          };
        }
      }
    }
  }

  private createCityInProvince(
    coord: HexCoord,
    id: string,
    name: string,
    factionId: string,
    cultureId: string,
    population: number,
    authority: number,
    tiles: Map<string, HexTile>,
    provinces: Map<string, Province>,
    cities: Map<string, City>
  ): City {
    let tile = tiles.get(coord.key);

    // Find province of this coordinate
    let province: Province | undefined;
    if (tile && tile.provinceId) {
      province = provinces.get(tile.provinceId);
    } else {
      // Find nearest land province
      for (const p of provinces.values()) {
        province = p;
        break;
      }
    }

    const cityQ = province ? province.centerQ : coord.q;
    const cityR = province ? province.centerR : coord.r;
    const actualCoord = new HexCoord(cityQ, cityR);
    const actualTile = tiles.get(actualCoord.key);

    const city: City = {
      id,
      name,
      q: cityQ,
      r: cityR,
      provinceId: province ? province.id : 'prov_unknown',
      factionId,
      population,
      dominantCultureId: cultureId,
      cultureWeights: { [cultureId]: 1.0 },
      accumulatedDrift: 0,
      authority,
      effectiveDistanceToCapital: 0,
      unrestStage: authority >= 70 ? UnrestStage.INTEGRATED : authority >= 40 ? UnrestStage.EROSION : UnrestStage.AUTONOMY_DEMAND,
      garrisonStrength: 10,
      foodStock: 60,
      productionStock: 25
    };

    if (actualTile) {
      actualTile.cityId = id;
      actualTile.hasRoad = true;
    }

    // Claim the ENTIRE PROVINCE for this faction and culture!
    if (province) {
      province.cityId = id;
      province.ownerFactionId = factionId;
      province.dominantCultureId = cultureId;
      province.authority = authority;
      province.unrestStage = city.unrestStage;

      for (const hexKey of province.hexKeys) {
        const pTile = tiles.get(hexKey);
        if (pTile) {
          pTile.ownerFactionId = factionId;
        }
      }
    }

    cities.set(id, city);
    return city;
  }

  private createUnit(
    coord: HexCoord,
    id: string,
    name: string,
    type: UnitType,
    factionId: string,
    hp: number,
    moves: number,
    combat: number,
    tiles: Map<string, HexTile>,
    units: Map<string, Unit>
  ): Unit {
    const tile = tiles.get(coord.key);
    if (tile) {
      tile.unitId = id;
    }

    const unit: Unit = {
      id,
      name,
      type,
      factionId,
      q: coord.q,
      r: coord.r,
      hp,
      maxHp: hp,
      movesLeft: moves,
      maxMoves: moves,
      combatStrength: combat,
      supply: 100,
      isGarrisoned: tile?.cityId !== null,
      loyalty: 95,
      generalName: type === UnitType.SETTLER ? null : NameGenerator.generateLeaderName()
    };

    units.set(id, unit);
    return unit;
  }
}
