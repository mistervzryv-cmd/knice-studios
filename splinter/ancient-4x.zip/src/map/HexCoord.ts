// Pointy-topped hexagonal coordinate mathematics
export interface Point {
  x: number;
  y: number;
}

export interface CubeCoord {
  x: number;
  y: number;
  z: number;
}

export class HexCoord {
  readonly q: number;
  readonly r: number;

  constructor(q: number, r: number) {
    this.q = q;
    this.r = r;
  }

  get s(): number {
    return -this.q - this.r;
  }

  get key(): string {
    return `${this.q},${this.r}`;
  }

  static fromKey(key: string): HexCoord {
    const [q, r] = key.split(',').map(Number);
    return new HexCoord(q, r);
  }

  equals(other: HexCoord): boolean {
    return this.q === other.q && this.r === other.r;
  }

  add(other: HexCoord): HexCoord {
    return new HexCoord(this.q + other.q, this.r + other.r);
  }

  subtract(other: HexCoord): HexCoord {
    return new HexCoord(this.q - other.q, this.r - other.r);
  }

  // Axial to Pointy-Topped Pixel coordinates
  toPixel(size: number, originX: number = 0, originY: number = 0): Point {
    const x = size * (Math.sqrt(3) * this.q + (Math.sqrt(3) / 2) * this.r) + originX;
    const y = size * ((3 / 2) * this.r) + originY;
    return { x, y };
  }

  // Pixel to Axial with rounding
  static fromPixel(x: number, y: number, size: number, originX: number = 0, originY: number = 0): HexCoord {
    const px = x - originX;
    const py = y - originY;
    const q = ((Math.sqrt(3) / 3) * px - (1 / 3) * py) / size;
    const r = ((2 / 3) * py) / size;
    return HexCoord.roundCube(q, r, -q - r);
  }

  static roundCube(fracX: number, fracZ: number, fracY: number): HexCoord {
    // Note: in axial, q=x, r=z, y=-x-z
    let rx = Math.round(fracX);
    let ry = Math.round(fracY);
    let rz = Math.round(fracZ);

    const xDiff = Math.abs(rx - fracX);
    const yDiff = Math.abs(ry - fracY);
    const zDiff = Math.abs(rz - fracZ);

    if (xDiff > yDiff && xDiff > zDiff) {
      rx = -ry - rz;
    } else if (yDiff > zDiff) {
      ry = -rx - rz;
    } else {
      rz = -rx - ry;
    }

    return new HexCoord(rx, rz);
  }

  // Distance between two hexes in hex steps
  distanceTo(other: HexCoord): number {
    return (Math.abs(this.q - other.q) + Math.abs(this.q + this.r - other.q - other.r) + Math.abs(this.r - other.r)) / 2;
  }

  // 6 Directional Neighbors
  static readonly DIRECTIONS: HexCoord[] = [
    new HexCoord(1, 0),
    new HexCoord(1, -1),
    new HexCoord(0, -1),
    new HexCoord(-1, 0),
    new HexCoord(-1, 1),
    new HexCoord(0, 1)
  ];

  neighbors(): HexCoord[] {
    return HexCoord.DIRECTIONS.map(dir => this.add(dir));
  }

  // Returns all coordinates within range
  range(radius: number): HexCoord[] {
    const results: HexCoord[] = [];
    for (let q = -radius; q <= radius; q++) {
      for (let r = Math.max(-radius, -q - radius); r <= Math.min(radius, -q + radius); r++) {
        results.push(new HexCoord(this.q + q, this.r + r));
      }
    }
    return results;
  }

  // Ring around this hex at exact radius
  ring(radius: number): HexCoord[] {
    if (radius === 0) return [this];
    const results: HexCoord[] = [];
    let hex = this.add(HexCoord.DIRECTIONS[4].scale(radius));
    for (let i = 0; i < 6; i++) {
      for (let j = 0; j < radius; j++) {
        results.push(hex);
        hex = hex.add(HexCoord.DIRECTIONS[i]);
      }
    }
    return results;
  }

  scale(factor: number): HexCoord {
    return new HexCoord(this.q * factor, this.r * factor);
  }

  // 6 Corner points for rendering pointy-topped polygon
  static getCornerPoints(center: Point, size: number): Point[] {
    const corners: Point[] = [];
    for (let i = 0; i < 6; i++) {
      const angleDeg = 60 * i - 30;
      const angleRad = (Math.PI / 180) * angleDeg;
      corners.push({
        x: center.x + size * Math.cos(angleRad),
        y: center.y + size * Math.sin(angleRad)
      });
    }
    return corners;
  }
}
