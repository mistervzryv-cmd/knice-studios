// Hexagonal A* Pathfinding and Logistics Distance Calculation
import { HexCoord } from './HexCoord.ts';
import { HexTile } from '../entities/Types.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';

interface PathNode {
  hex: HexCoord;
  gScore: number;
  fScore: number;
  parent: PathNode | null;
}

export class Pathfinding {
  // A* calculation of effective logistical / travel cost between start and target
  static findPath(
    start: HexCoord,
    target: HexCoord,
    tiles: Map<string, HexTile>,
    ignoreUnits: boolean = true
  ): { path: HexCoord[]; totalCost: number } | null {
    if (start.equals(target)) {
      return { path: [start], totalCost: 0 };
    }

    const openSet = new Map<string, PathNode>();
    const closedSet = new Set<string>();

    const startNode: PathNode = {
      hex: start,
      gScore: 0,
      fScore: start.distanceTo(target),
      parent: null
    };

    openSet.set(start.key, startNode);

    while (openSet.size > 0) {
      // Find node with lowest fScore
      let current: PathNode | null = null;
      for (const node of openSet.values()) {
        if (!current || node.fScore < current.fScore) {
          current = node;
        }
      }

      if (!current) break;

      if (current.hex.equals(target)) {
        // Reconstruct path
        const path: HexCoord[] = [];
        let curr: PathNode | null = current;
        while (curr) {
          path.unshift(curr.hex);
          curr = curr.parent;
        }
        return { path, totalCost: current.gScore };
      }

      openSet.delete(current.hex.key);
      closedSet.add(current.hex.key);

      for (const neighborCoord of current.hex.neighbors()) {
        const neighborKey = neighborCoord.key;
        if (closedSet.has(neighborKey)) continue;

        const tile = tiles.get(neighborKey);
        if (!tile) continue; // Off-map

        // Impassable tiles
        if (tile.elevation > 0.85 || tile.elevation < 0.22) { // Mountains or Ocean
          continue;
        }

        if (!ignoreUnits && tile.unitId) {
          // Blocked by other unit
          continue;
        }

        // Cost modifier for terrain, rivers, roads
        let stepCost = tile.movementCost;
        if (tile.isRiver) {
          stepCost *= GAME_CONSTANTS.LOGISTICS.RIVER_COST_FACTOR;
        }
        if (tile.hasRoad) {
          stepCost *= GAME_CONSTANTS.LOGISTICS.ROAD_COST_FACTOR;
        }

        const tentativeGScore = current.gScore + stepCost;
        const neighborNode = openSet.get(neighborKey);

        if (!neighborNode || tentativeGScore < neighborNode.gScore) {
          const h = neighborCoord.distanceTo(target);
          const newNode: PathNode = {
            hex: neighborCoord,
            gScore: tentativeGScore,
            fScore: tentativeGScore + h,
            parent: current
          };
          openSet.set(neighborKey, newNode);
        }
      }
    }

    return null; // No path found
  }

  // Calculate logistics reach / distance from capital to settlement
  static calculateLogisticsCost(
    capitalCoord: HexCoord,
    targetCoord: HexCoord,
    tiles: Map<string, HexTile>
  ): number {
    const result = this.findPath(capitalCoord, targetCoord, tiles, true);
    if (!result) return 999; // Cut off by impassable barriers
    return result.totalCost;
  }
}
