// Core game types and interfaces for Ancient 4X Prototype

export enum BiomeType {
  OCEAN = 'OCEAN',
  RIVER_VALLEY = 'RIVER_VALLEY',
  FERTILE_PLAINS = 'FERTILE_PLAINS',
  STEPPE = 'STEPPE',
  FOREST = 'FOREST',
  HILLS = 'HILLS',
  MOUNTAINS = 'MOUNTAINS',
  DESERT = 'DESERT'
}

export enum ResourceType {
  NONE = 'NONE',
  FERTILE_SILT = 'FERTILE_SILT',
  COPPER = 'COPPER',                 // Медь (необходима для Бронзового Века)
  TIN = 'TIN',                       // Олово (необходимо для Бронзового Века)
  CATTLE = 'CATTLE',                 // Скот (пища, мобильность и обмен)
  INCENSE = 'INCENSE',               // Благовония (поднимают Cohesion и мнение ИИ)
  HORSES = 'HORSES',
  TIMBER = 'TIMBER',
  GOLD = 'GOLD',
  CLAY = 'CLAY'
}

export enum UnrestStage {
  INTEGRATED = 'INTEGRATED',         // 70 - 100 authority
  EROSION = 'EROSION',               // 40 - 69 authority (-30% taxes)
  AUTONOMY_DEMAND = 'AUTONOMY_DEMAND', // 15 - 39 authority (no levies, local militia)
  SECESSION_CRISIS = 'SECESSION_CRISIS'// < 15 authority (imminent or active rebellion)
}

export interface LanguageState {
  name: string;
  writingLevel: number;
  features: string[]; // e.g. ['WRITING', 'ALPHABET', 'GRAMMAR', 'LINGUA_FRANCA']
  divergence: number; // 0 to 100%
  lastLoggedMilestone?: number; // Last divergence milestone (25/50/75/100) already written to the Chronicles
}

export interface Culture {
  id: string;
  name: string;
  parentId: string | null;           // Null for primordial root cultures
  divergenceTurn: number;
  color: string;                     // Hex color for cultural overlay
  traits: string[];                  // Cultural traditions
  isSubCulture?: boolean;
  parentCultureId?: string | null;
  drift?: number;                    // 0 to 100% degree of isolation/separation
  isUniqueCulture?: boolean;
  language?: LanguageState;
}

export interface TribalCamp {
  name: string;
  warriors: number;
  cultureName: string;
  syncretismValue: number;          // How much drift is induced if absorbed
}

export interface Province {
  id: string;
  name: string;
  centerQ: number;
  centerR: number;
  hexKeys: string[];
  biome: BiomeType;
  baseColor: string;
  fertility: number;
  ownerFactionId: string | null;
  dominantCultureId: string | null;
  cityId: string | null;
  authority: number;                 // 0 to 100
  accumulatedDrift: number;          // 0 to 100
  unrestStage: UnrestStage;
  tribalCamp: TribalCamp | null;
  isOutpost?: boolean;
  isCutOffFromSupply?: boolean;
  supplyDistance?: number;
  isRefuge?: boolean;                // Статус "Убежище": провинция отрезана горами от столицы
  // Economy & Infrastructure
  population?: number;               // Население в тысячах (напр. 25 = 25,000)
  hasFarm?: boolean;                 // Ферма: +2 еды, ускоренный демографический рост
  hasMine?: boolean;                 // Шахта: +производство/ресурсы
  hasMarket?: boolean;               // Рынок: +золото каждый ход
  hasWonder?: boolean;               // Завершенное Чудо Света (+30% Cohesion в радиусе 5 гексов)
  wonderName?: string | null;
  wonderTurnsRemaining?: number;    // Оставшиеся ходы строительства (5 -> 0)
  isEpidemic?: boolean;              // Активная вспышка эпидемии
  epidemicTurnsRemaining?: number;   // Длительность эпидемии
}

export interface HexTile {
  q: number;
  r: number;
  col: number;
  row: number;
  provinceId: string | null;         // Null for ocean, otherwise points to Province
  biome: BiomeType;
  elevation: number;                 // 0 to 1
  moisture: number;                  // 0 to 1
  fertility: number;                 // 0 to 5 food base
  movementCost: number;              // 1 to 4 movement points
  resource: ResourceType;
  isRiver: boolean;
  hasRoad: boolean;
  ownerFactionId: string | null;
  cityId: string | null;
  unitId: string | null;
  tribalCamp: TribalCamp | null;
}

export interface City {
  id: string;
  name: string;
  q: number;
  r: number;
  provinceId: string;
  factionId: string;
  population: number;
  dominantCultureId: string;
  cultureWeights: Record<string, number>; // cultureId -> ratio (sum = 1)
  accumulatedDrift: number;               // 0 to 100; at 100 => cultural divergence event
  authority: number;                      // 0 to 100
  effectiveDistanceToCapital: number;
  unrestStage: UnrestStage;
  garrisonStrength: number;
  foodStock: number;
  productionStock: number;
}

export enum UnitType {
  SETTLER = 'SETTLER',
  SPEARMEN = 'SPEARMEN',
  ARCHERS = 'ARCHERS',
  CHARIOT = 'CHARIOT',
  HORDE = 'HORDE',                   // Мигрирующее племя / Орда (5-7 MP, колонизирует пустые земли)
  LEGION = 'LEGION',                 // Железный век: тяжелая дисциплинированная пехота
  HEAVY_CAVALRY = 'HEAVY_CAVALRY',   // Железный век: бронированные всадники
  MUSKETEER = 'MUSKETEER',           // Ренессанс: стрелки с порохом
  CANNON = 'CANNON',                 // Ренессанс: осадные орудия
  INFANTRY = 'INFANTRY',             // Индустриальная / Современность: моторизованная пехота
  TANK = 'TANK',                     // Современность: бронированная ударная бронетехника
  REBEL = 'REBEL'                    // Повстанцы / Партизаны поздних эпох
}

export type RulerTrait = 'CONQUEROR' | 'WEAK_RULER' | 'BUILDER';

export interface Ruler {
  name: string;
  title: string;
  age: number;
  maxAge: number;
  legitimacy: number;                     // 0 to 100%
  traits: string[];
  mainTrait: RulerTrait;                  // 'CONQUEROR' | 'WEAK_RULER' | 'BUILDER'
}

export interface Unit {
  id: string;
  name: string;
  type: UnitType;
  factionId: string;
  q: number;
  r: number;
  hp: number;
  maxHp: number;
  movesLeft: number;
  maxMoves: number;
  combatStrength: number;
  supply: number;                         // 0 to 100
  isGarrisoned: boolean;
  loyalty: number;                        // 0 to 100% loyalty of the army/general
  generalName: string | null;             // Name of the warlord commanding this army
  originCityName?: string;                // For migrating hordes: former home city
  originProvinceId?: string;              // For migrating hordes: province they left (never re-settled)
}

export type GameMode = 'START_MENU' | 'PLAYING' | 'DIPLOMACY_MENU' | 'TRADITIONS_MENU' | 'MIGRATION_MENU' | 'RESEARCH_MENU' | 'POLITICS_MENU';

export type StarterCultureChoice = 'RIVER_FARMERS' | 'STEPPE_NOMADS' | 'MOUNTAIN_TOTEMISTS';

export enum DiplomaticStatus {
  PEACE = 'PEACE',
  WAR = 'WAR',
  NON_AGGRESSION = 'NON_AGGRESSION',
  ALLIANCE = 'ALLIANCE'
}

export interface DiplomaticRelation {
  status: DiplomaticStatus;
  opinion: number;                       // -100 to 100
  pactTurnsLeft: number;
}

export enum HistoricalAge {
  STONE_TOOLS = 'STONE_TOOLS',           // Эпоха Орудий (Каменный век)
  COPPER_AGE = 'COPPER_AGE',             // Эпоха Меди
  BRONZE_AGE = 'BRONZE_AGE',             // Бронзовый Век
  IRON_AGE = 'IRON_AGE',                 // Железный век
  RENAISSANCE = 'RENAISSANCE',           // Ренессанс
  INDUSTRIAL = 'INDUSTRIAL',             // Индустриальная эпоха
  MODERN = 'MODERN'                      // Современность
}

export interface GlobalCrisis {
  id: string;
  name: string;
  description: string;
  turnsLeft: number;
  totalTurns: number;
  effect: string;
}

export enum DogmaId {
  ANCESTOR_CULT = 'ANCESTOR_CULT',         // Культ Предков (+20% к Cohesion на окраинах, -15% к сбору золота)
  RIVER_PRIESTHOOD = 'RIVER_PRIESTHOOD',   // Речное Священничество (удваивает очки культуры от рек, +1 еда)
  NOMADIC_LIFESTYLE = 'NOMADIC_LIFESTYLE'  // Кочевой Быт (+2 к дальности миграции, пустыни/степи без штрафа)
}

export enum PoliticalRegime {
  TRIBAL_COUNCIL = 'TRIBAL_COUNCIL',     // Племенной совет (+15% сплоченность кочевий, -10% золота)
  MONARCHY = 'MONARCHY',                 // Монархия (+15% легитимности, +1 радиус снабжения)
  REPUBLIC = 'REPUBLIC',                 // Республика (+25% наука и золото, -10% контроль армии)
  DICTATORSHIP = 'DICTATORSHIP'          // Диктатура (+30% сила армий, подавление смут, -15% наука)
}

export enum EdictId {
  MARTIAL_LAW = 'MARTIAL_LAW',           // Военное положение (+20% сила защиты, -20% золото)
  FREE_TRADE = 'FREE_TRADE',             // Свободная торговля (+25% золото, -10% Cohesion)
  IMPERIAL_CULT = 'IMPERIAL_CULT'        // Имперский культ (+15% легитимность правителя)
}

export interface ResourceStockpile {
  copper: number;
  tin: number;
  cattle: number;
  incense: number;
  iron?: number;
  oil?: number;
}

export enum FactionTier {
  TRIBE = 1,       // Тир 1: Дикое Племя (Старт). Высокая скорость миграции, штраф к Cohesion при >3 провинциях
  CHIEFDOM = 2,    // Тир 2: Вождество (Chiefdom). Открывается постройка Аванпостов, штраф за расстояние снижен
  EARLY_STATE = 3, // Тир 3: Раннее Государство / Цивилизация. Пассивное расширение границ, союзы и торговля металлами, Лаборатория
  EMPIRE = 4       // Тир 4: Великая Империя. Сплоченность +25%, постройка Чудес Света, ассимиляция
}

export interface Faction {
  id: string;
  name: string;
  color: string;
  capitalCityId: string | null;
  rootCultureId: string;
  isPlayer: boolean;
  isBreakaway: boolean;
  gold: number;
  grain: number;
  overextension: number;                  // 0 to 100+
  atWarWith: string[];                   // Faction IDs
  ruler: Ruler;                           // Current monarch/ruler
  isInterregnum: boolean;                 // Succession crisis active?
  interregnumTurnsLeft: number;           // Duration of crisis
  diplomacy: Record<string, DiplomaticRelation>; // Target Faction ID -> Relation
  culturePoints: number;                  // Очки Культуры
  unlockedDogmas: DogmaId[];              // Открытые догматы
  resources: ResourceStockpile;           // Стратегические ресурсы
  tier: FactionTier;                      // Культурный Тир (1-4)
  outposts: string[];                     // Список ID провинций с аванпостами
  // Modern Systems
  sciencePoints?: number;                // Накопленные Очки Исследований
  unlockedTechs?: string[];              // Список открытых технологий
  regime?: PoliticalRegime;              // Текущий политический режим
  activeEdicts?: EdictId[];              // Активные государственные указы
  taxRate?: 'LOW' | 'NORMAL' | 'HIGH';   // Ставка налогообложения
  parentFactionId?: string | null;       // ID родительской фракции (для суб-культур)
  isSubCultureFaction?: boolean;         // Является ли суб-культурой
  wonderProvinces?: string[];            // Провинции с Чудесами Света
  hasCapitalLuxury?: boolean;            // Доставлены ли столичные блага (Ладан / Скот соединены снабжением)
  capitalLuxuries?: string[];            // Список доставленных благ (напр. ["Ладан", "Скот"])
  lastTradeTurn?: Record<string, number>; // Faction ID -> последний ход торговой сделки (влияет на дрейф суб-культур)
  nationType?: NationType;               // Тип государства, рожденного Мировым Спавнером
}

export type NationType = 'KNIGHTS' | 'KHANATE' | 'EMPIRE' | 'MOUNTAIN_KINGDOM';

export enum MapOverlayMode {
  POLITICAL = 'POLITICAL',
  CULTURE = 'CULTURE',
  AUTHORITY = 'AUTHORITY',
  LOGISTICS = 'LOGISTICS'
}

export interface SecessionEvent {
  turn: number;
  originalFactionId: string;
  newFactionId: string;
  cityIds: string[];
  cultureId: string;
  leaderName: string;
}

export type VictoryType = 'MILITARY' | 'SCIENTIFIC' | 'CULTURAL' | 'NONE';

