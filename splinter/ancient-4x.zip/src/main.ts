import { GameState } from './core/GameState.ts';
import { CanvasRenderer } from './render/CanvasRenderer.ts';
import { UIManager } from './ui/UIManager.ts';
import { EventBus } from './core/EventBus.ts';
import { initLanguage } from './i18n/translations.ts';

window.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('game-canvas') as HTMLCanvasElement;
  if (!canvas) {
    console.error('Canvas element #game-canvas not found!');
    return;
  }

  // 0. Auto-detect system language and initialize localization
  initLanguage();

  // 1. Initialize Game State
  const gameState = new GameState();

  // 2. Initialize Canvas Renderer
  const renderer = new CanvasRenderer(canvas, gameState);

  // 3. Initialize UI Manager
  const uiManager = new UIManager(gameState, () => {
    renderer.render();
  });

  // Expose on window for game.js API and debugging
  (window as any).gameState = gameState;
  (window as any).renderer = renderer;
  (window as any).uiManager = uiManager;

  // Wire Province Hover & Floating Click-to-Annex Menu
  renderer.onProvinceHover = (prov, x, y, tile) => {
    uiManager.handleProvinceHover(prov, x, y, tile);
  };

  renderer.onProvinceClick = (prov, x, y) => {
    uiManager.showAnnexMenu(prov, x, y);
  };

  EventBus.on('GAME_MODE_CHANGED', ({ mode }: { mode: string }) => {
    if (mode === 'PLAYING') {
      renderer.centerOnPlayerCapital();
    }
  });

  // 4. Initial Render
  renderer.render();

  console.log('Ancient 4X Prototype initialized successfully with Localization, Touch gestures, and Autosaves!');
});
