// High-performance 2D Canvas Renderer for Earth Map with Polygonal Provinces
import { HexCoord, Point } from '../map/HexCoord.ts';
import { GameState } from '../core/GameState.ts';
import { BiomeType, HexTile, MapOverlayMode, ResourceType, UnitType, UnrestStage, Province } from '../entities/Types.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';

export class CanvasRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private state: GameState;

  // Camera transform
  cameraX: number = 0;
  cameraY: number = 0;
  scale: number = 1.0;
  hoveredProvinceId: string | null = null;
  onProvinceHover?: (province: Province | null, screenX: number, screenY: number, tile: HexTile | null) => void;
  onProvinceClick?: (province: Province, screenX: number, screenY: number) => void;
  private isDragging: boolean = false;
  private dragStartX: number = 0;
  private dragStartY: number = 0;

  constructor(canvas: HTMLCanvasElement, state: GameState) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.state = state;

    this.setupResize();
    this.setupInteractions();
    this.centerOnPlayerCapital();
    this.startAnimationLoop();
  }

  private setupResize(): void {
    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      this.canvas.width = window.innerWidth * dpr;
      this.canvas.height = window.innerHeight * dpr;
      this.canvas.style.width = `${window.innerWidth}px`;
      this.canvas.style.height = `${window.innerHeight}px`;
      this.ctx.scale(dpr, dpr);
      this.render();
    };
    window.addEventListener('resize', resize);
    resize();
  }

  private setupInteractions(): void {
    this.canvas.addEventListener('mousedown', (e) => {
      if (e.button === 0) { // Left click
        this.isDragging = true;
        this.dragStartX = e.clientX - this.cameraX;
        this.dragStartY = e.clientY - this.cameraY;
      }
    });

    window.addEventListener('mousemove', (e) => {
      if (this.isDragging) {
        this.cameraX = e.clientX - this.dragStartX;
        this.cameraY = e.clientY - this.dragStartY;
        this.render();
        return;
      }

      if (this.state.mode !== 'PLAYING') return;

      const hexSize = GAME_CONSTANTS.MAP.HEX_RADIUS * this.scale;
      const hex = HexCoord.fromPixel(e.clientX, e.clientY, hexSize, this.cameraX, this.cameraY);
      const tile = this.state.tiles.get(hex.key) || null;
      const prov = tile?.provinceId ? this.state.provinces.get(tile.provinceId) || null : null;

      const oldHovered = this.hoveredProvinceId;
      this.hoveredProvinceId = prov ? prov.id : null;

      if (this.onProvinceHover) {
        this.onProvinceHover(prov, e.clientX, e.clientY, tile);
      }

      if (oldHovered !== this.hoveredProvinceId) {
        this.render();
      }
    });

    this.canvas.addEventListener('mouseleave', () => {
      this.hoveredProvinceId = null;
      if (this.onProvinceHover) {
        this.onProvinceHover(null, 0, 0, null);
      }
      this.render();
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
      const newScale = Math.min(
        GAME_CONSTANTS.MAP.MAX_SCALE,
        Math.max(GAME_CONSTANTS.MAP.MIN_SCALE, this.scale * zoomFactor)
      );

      const mouseX = e.clientX;
      const mouseY = e.clientY;
      this.cameraX = mouseX - (mouseX - this.cameraX) * (newScale / this.scale);
      this.cameraY = mouseY - (mouseY - this.cameraY) * (newScale / this.scale);
      this.scale = newScale;

      this.render();
    }, { passive: false });

    // Click on hex
    this.canvas.addEventListener('click', (e) => {
      if (this.state.mode !== 'PLAYING') return; // Pause map clicks when in start menu or diplomacy
      const hexSize = GAME_CONSTANTS.MAP.HEX_RADIUS * this.scale;
      const hex = HexCoord.fromPixel(e.clientX, e.clientY, hexSize, this.cameraX, this.cameraY);

      if (this.state.tiles.has(hex.key)) {
        const tile = this.state.tiles.get(hex.key);
        const player = this.state.getPlayerFaction();
        if (tile && tile.provinceId && player) {
          const prov = this.state.provinces.get(tile.provinceId);
          if (prov && prov.ownerFactionId === null && this.state.isProvinceExpandable(prov.id, player.id)) {
            // Clicked on an expandable empty province!
            if (this.onProvinceClick) {
              this.onProvinceClick(prov, e.clientX, e.clientY);
            }
          }
        }
        this.handleHexClick(hex);
      }
    });

    // --- Touch Interaction Support (Mobile & Tablet) ---
    let touchStartDist = 0;
    let touchStartScale = this.scale;
    let touchStartTime = 0;
    let touchStartX = 0;
    let touchStartY = 0;
    let isPinching = false;
    let hasMovedSignificantly = false;

    this.canvas.addEventListener('touchstart', (e: TouchEvent) => {
      if (this.state.mode !== 'PLAYING') return;

      if (e.touches.length === 1) {
        const touch = e.touches[0];
        this.isDragging = true;
        isPinching = false;
        hasMovedSignificantly = false;
        touchStartTime = Date.now();
        touchStartX = touch.clientX;
        touchStartY = touch.clientY;
        this.dragStartX = touch.clientX - this.cameraX;
        this.dragStartY = touch.clientY - this.cameraY;
      } else if (e.touches.length === 2) {
        this.isDragging = false;
        isPinching = true;
        hasMovedSignificantly = true;
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        touchStartDist = Math.hypot(dx, dy);
        touchStartScale = this.scale;
      }
    }, { passive: false });

    this.canvas.addEventListener('touchmove', (e: TouchEvent) => {
      if (this.state.mode !== 'PLAYING') return;
      e.preventDefault();

      if (e.touches.length === 1 && this.isDragging && !isPinching) {
        const touch = e.touches[0];
        const distMoved = Math.hypot(touch.clientX - touchStartX, touch.clientY - touchStartY);
        if (distMoved > 8) {
          hasMovedSignificantly = true;
        }
        this.cameraX = touch.clientX - this.dragStartX;
        this.cameraY = touch.clientY - this.dragStartY;
        this.render();
      } else if (e.touches.length === 2 && isPinching) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const currentDist = Math.hypot(dx, dy);
        if (touchStartDist > 0) {
          const factor = currentDist / touchStartDist;
          const newScale = Math.min(
            GAME_CONSTANTS.MAP.MAX_SCALE,
            Math.max(GAME_CONSTANTS.MAP.MIN_SCALE, touchStartScale * factor)
          );
          const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
          const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
          this.cameraX = midX - (midX - this.cameraX) * (newScale / this.scale);
          this.cameraY = midY - (midY - this.cameraY) * (newScale / this.scale);
          this.scale = newScale;
          this.render();
        }
      }
    }, { passive: false });

    const handleTouchEnd = (e: TouchEvent) => {
      if (this.state.mode !== 'PLAYING') {
        this.isDragging = false;
        isPinching = false;
        return;
      }

      const touchDuration = Date.now() - touchStartTime;

      // Detect tap: single touch, short duration, minimal displacement
      if (!isPinching && !hasMovedSignificantly && touchDuration < 350) {
        const tapX = touchStartX;
        const tapY = touchStartY;
        const hexSize = GAME_CONSTANTS.MAP.HEX_RADIUS * this.scale;
        const hex = HexCoord.fromPixel(tapX, tapY, hexSize, this.cameraX, this.cameraY);

        if (this.state.tiles.has(hex.key)) {
          const tile = this.state.tiles.get(hex.key);
          const player = this.state.getPlayerFaction();
          if (tile && tile.provinceId && player) {
            const prov = this.state.provinces.get(tile.provinceId);
            if (prov && prov.ownerFactionId === null && this.state.isProvinceExpandable(prov.id, player.id)) {
              if (this.onProvinceClick) {
                this.onProvinceClick(prov, tapX, tapY);
              }
            }
          }
          this.handleHexClick(hex);
        }
      }

      if (e.touches.length === 0) {
        this.isDragging = false;
        isPinching = false;
      } else if (e.touches.length === 1) {
        isPinching = false;
        this.isDragging = true;
        const touch = e.touches[0];
        this.dragStartX = touch.clientX - this.cameraX;
        this.dragStartY = touch.clientY - this.cameraY;
      }
    };

    this.canvas.addEventListener('touchend', handleTouchEnd);
    this.canvas.addEventListener('touchcancel', () => {
      this.isDragging = false;
      isPinching = false;
    });
  }

  centerOnPlayerCapital(): void {
    const player = this.state.getPlayerFaction();
    if (player && player.capitalCityId) {
      const cap = this.state.cities.get(player.capitalCityId);
      if (cap) {
        const hex = new HexCoord(cap.q, cap.r);
        const pt = hex.toPixel(GAME_CONSTANTS.MAP.HEX_RADIUS * this.scale);
        this.cameraX = window.innerWidth / 2 - pt.x;
        this.cameraY = window.innerHeight / 2 - pt.y;
        this.render();
      }
    }
  }

  private handleHexClick(coord: HexCoord): void {
    const tile = this.state.tiles.get(coord.key);
    if (!tile) return;

    // Check if player has a selected unit that can move here
    if (this.state.selectedUnitId) {
      const unit = this.state.units.get(this.state.selectedUnitId);
      if (unit && unit.movesLeft > 0) {
        const fromCoord = new HexCoord(unit.q, unit.r);
        if (fromCoord.distanceTo(coord) === 1) {
          const moved = this.state.moveUnit(unit.id, coord);
          if (moved) {
            this.state.selectedHexKey = coord.key;
            this.render();
            return;
          }
        }
      }
    }

    // Select tile / unit / city
    this.state.selectedHexKey = coord.key;
    if (tile.unitId) {
      this.state.selectedUnitId = tile.unitId;
    } else {
      this.state.selectedUnitId = null;
    }

    if (tile.cityId) {
      this.state.selectedCityId = tile.cityId;
    } else {
      this.state.selectedCityId = null;
    }

    this.render();
  }

  render(): void {
    const ctx = this.ctx;
    const width = window.innerWidth;
    const height = window.innerHeight;

    // Deep Ocean Background
    ctx.fillStyle = '#0c141d';
    ctx.fillRect(0, 0, width, height);

    const hexRadius = GAME_CONSTANTS.MAP.HEX_RADIUS * this.scale;
    const visibleKeys = this.getVisibleHexKeys();

    // 1. Draw Hex Tiles & Province Base Tints
    for (const tile of this.state.tiles.values()) {
      const coord = new HexCoord(tile.q, tile.r);
      const center = coord.toPixel(hexRadius, this.cameraX, this.cameraY);

      // Culling
      if (center.x < -hexRadius * 2 || center.x > width + hexRadius * 2 ||
          center.y < -hexRadius * 2 || center.y > height + hexRadius * 2) {
        continue;
      }

      this.drawHexTile(ctx, coord, tile, center, hexRadius);
    }

    // 1.5. Draw Expandable Neighboring Provinces Highlight
    this.drawExpandableProvinces(ctx, hexRadius);

    // 1.8. Draw Cut-off from Supply Lines Red Hatching & Warning Badges
    this.drawCutOffSupplyProvinces(ctx, hexRadius);

    // 2. Draw Rivers & Roads
    this.drawRiversAndRoads(ctx, hexRadius);

    // 3. Draw Thin Province Borders & Thick Faction Borders
    this.drawBorders(ctx, hexRadius);

    // 3.5. Draw Low Cohesion Warning Pulsing Contour (<30% Authority / Secession Risk)
    this.drawLowCohesionPulsing(ctx, hexRadius);

    // 4. Draw Fog of War (Darkens tiles > 3 hexes away from player units, cities, provinces)
    this.drawFogOfWar(ctx, hexRadius, visibleKeys);

    // 5. Draw Province Names
    this.drawProvinceLabels(ctx, hexRadius);

    // 6. Draw Wonders of the World & Epidemic Outbreaks
    this.drawWondersAndEpidemics(ctx, hexRadius, visibleKeys);

    // 7. Draw Strategic Resources & Tribal Camps
    this.drawResourcesAndTribes(ctx, hexRadius, visibleKeys);

    // 8. Draw Cities & Ziggurats
    this.drawCities(ctx, hexRadius, visibleKeys);

    // 9. Draw Military Units & Supplies
    this.drawUnits(ctx, hexRadius, visibleKeys);

    // 10. Draw Selection & Range Highlight
    this.drawHighlights(ctx, hexRadius);
  }

  private getVisibleHexKeys(): Set<string> {
    const visible = new Set<string>();
    const player = this.state.getPlayerFaction();
    if (!player || this.state.mode === 'START_MENU') {
      for (const key of this.state.tiles.keys()) visible.add(key);
      return visible;
    }

    const origins: HexCoord[] = [];
    // 1. Player units (including moving horde)
    for (const unit of this.state.units.values()) {
      if (unit.factionId === player.id) {
        origins.push(new HexCoord(unit.q, unit.r));
      }
    }
    // 2. Player cities
    for (const city of this.state.cities.values()) {
      if (city.factionId === player.id) {
        origins.push(new HexCoord(city.q, city.r));
      }
    }
    // 3. Player owned tiles
    for (const tile of this.state.tiles.values()) {
      if (tile.ownerFactionId === player.id) {
        origins.push(new HexCoord(tile.q, tile.r));
      }
    }

    // Vision radius: 3 hexes
    for (const origin of origins) {
      const reachable = origin.range(3);
      for (const hex of reachable) {
        visible.add(hex.key);
      }
    }

    return visible;
  }

  private drawFogOfWar(ctx: CanvasRenderingContext2D, size: number, visibleKeys: Set<string>): void {
    if (this.state.mode === 'START_MENU') return;

    for (const tile of this.state.tiles.values()) {
      const key = `${tile.q},${tile.r}`;
      if (visibleKeys.has(key)) continue;

      const coord = new HexCoord(tile.q, tile.r);
      const center = coord.toPixel(size, this.cameraX, this.cameraY);

      // Culling
      if (
        center.x < -size * 2 || center.x > window.innerWidth + size * 2 ||
        center.y < -size * 2 || center.y > window.innerHeight + size * 2
      ) {
        continue;
      }

      const corners = HexCoord.getCornerPoints(center, size);
      ctx.beginPath();
      ctx.moveTo(corners[0].x, corners[0].y);
      for (let i = 1; i < 6; i++) {
        ctx.lineTo(corners[i].x, corners[i].y);
      }
      ctx.closePath();
      ctx.fillStyle = 'rgba(11, 16, 24, 0.82)';
      ctx.fill();
    }
  }

  private drawHexTile(ctx: CanvasRenderingContext2D, coord: HexCoord, tile: HexTile, center: Point, size: number): void {
    const corners = HexCoord.getCornerPoints(center, size - 0.5);

    ctx.beginPath();
    ctx.moveTo(corners[0].x, corners[0].y);
    for (let i = 1; i < 6; i++) {
      ctx.lineTo(corners[i].x, corners[i].y);
    }
    ctx.closePath();

    if (tile.biome === BiomeType.OCEAN) {
      ctx.fillStyle = '#101c27';
      ctx.fill();
      return;
    }

    // Province base land color (unified for all hexes in the same province)
    const province = tile.provinceId ? this.state.provinces.get(tile.provinceId) : null;
    const baseColor = province ? province.baseColor : this.getBiomeColor(tile.biome);

    ctx.fillStyle = baseColor;
    ctx.fill();

    // Map Overlays
    if (this.state.overlayMode === MapOverlayMode.POLITICAL) {
      if (tile.ownerFactionId) {
        const faction = this.state.factions.get(tile.ownerFactionId);
        if (faction) {
          ctx.fillStyle = faction.color;
          ctx.globalAlpha = 0.45;
          ctx.fill();
          ctx.globalAlpha = 1.0;
        }
      }
    } else if (this.state.overlayMode === MapOverlayMode.CULTURE) {
      const cultureId = province?.dominantCultureId;
      if (cultureId) {
        const c = this.state.cultures.get(cultureId);
        if (c) {
          ctx.fillStyle = c.color;
          ctx.globalAlpha = 0.52;
          ctx.fill();
          ctx.globalAlpha = 1.0;
        }
      }
    } else if (this.state.overlayMode === MapOverlayMode.AUTHORITY) {
      if (province && province.ownerFactionId) {
        ctx.fillStyle = this.getAuthorityColor(province.authority);
        ctx.globalAlpha = 0.5;
        ctx.fill();
        ctx.globalAlpha = 1.0;
      }
    }

    // Subtle internal hex cell grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 0.6;
    ctx.stroke();
  }

  private getBiomeColor(biome: BiomeType): string {
    switch (biome) {
      case BiomeType.OCEAN: return '#101c27';
      case BiomeType.RIVER_VALLEY: return '#2d5a3c';
      case BiomeType.FERTILE_PLAINS: return '#4a6b41';
      case BiomeType.STEPPE: return '#7a7048';
      case BiomeType.FOREST: return '#1e482d';
      case BiomeType.HILLS: return '#6b573e';
      case BiomeType.MOUNTAINS: return '#4a4d50';
      case BiomeType.DESERT: return '#99763e';
    }
  }

  private getAuthorityColor(authority: number): string {
    if (authority >= 70) return '#2ecc71'; // Green
    if (authority >= 40) return '#f1c40f'; // Yellow
    if (authority >= 15) return '#e67e22'; // Orange
    return '#e74c3c';                      // Red - Secession Crisis!
  }

  private drawRiversAndRoads(ctx: CanvasRenderingContext2D, size: number): void {
    for (const tile of this.state.tiles.values()) {
      if (!tile.isRiver) continue;
      const center = new HexCoord(tile.q, tile.r).toPixel(size, this.cameraX, this.cameraY);

      ctx.beginPath();
      ctx.arc(center.x, center.y, size * 0.28, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(52, 152, 219, 0.55)';
      ctx.fill();
    }
  }

  private drawBorders(ctx: CanvasRenderingContext2D, size: number): void {
    // 1. Draw Thin Province Borders (borders between different land provinces)
    for (const tile of this.state.tiles.values()) {
      if (!tile.provinceId) continue;

      const coord = new HexCoord(tile.q, tile.r);
      const center = coord.toPixel(size, this.cameraX, this.cameraY);
      const neighbors = coord.neighbors();
      const corners = HexCoord.getCornerPoints(center, size);

      for (let i = 0; i < 6; i++) {
        const nCoord = neighbors[i];
        const nTile = this.state.tiles.get(nCoord.key);

        if (nTile && nTile.provinceId && nTile.provinceId !== tile.provinceId) {
          const p1 = corners[i];
          const p2 = corners[(i + 1) % 6];

          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = 'rgba(212, 175, 55, 0.45)'; // Thin golden-brass province outline
          ctx.lineWidth = 1.0;
          ctx.stroke();
        }
      }
    }

    // 2. Draw Thick National / Faction Borders
    for (const tile of this.state.tiles.values()) {
      if (!tile.ownerFactionId) continue;
      const faction = this.state.factions.get(tile.ownerFactionId);
      if (!faction) continue;

      const coord = new HexCoord(tile.q, tile.r);
      const center = coord.toPixel(size, this.cameraX, this.cameraY);
      const neighbors = coord.neighbors();
      const corners = HexCoord.getCornerPoints(center, size);

      for (let i = 0; i < 6; i++) {
        const nCoord = neighbors[i];
        const nTile = this.state.tiles.get(nCoord.key);

        if (!nTile || nTile.ownerFactionId !== tile.ownerFactionId) {
          const p1 = corners[i];
          const p2 = corners[(i + 1) % 6];

          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = faction.color;
          ctx.lineWidth = 3.2 * this.scale;
          ctx.stroke();
        }
      }
    }
  }

  private drawProvinceLabels(ctx: CanvasRenderingContext2D, size: number): void {
    if (this.scale < 0.75) return; // Only show when zoomed in

    for (const prov of this.state.provinces.values()) {
      const coord = new HexCoord(prov.centerQ, prov.centerR);
      const center = coord.toPixel(size, this.cameraX, this.cameraY);

      ctx.font = `bold ${Math.max(9, Math.round(10 * this.scale))}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(240, 246, 252, 0.75)';
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.lineWidth = 2.5;
      const label = prov.isRefuge ? `🏔️ ${prov.name.toUpperCase()}` : prov.name.toUpperCase();
      ctx.strokeText(label, center.x, center.y);
      ctx.fillText(label, center.x, center.y);
    }
  }

  private drawWondersAndEpidemics(ctx: CanvasRenderingContext2D, size: number, visibleKeys: Set<string>): void {
    for (const prov of this.state.provinces.values()) {
      const centerKey = `${prov.centerQ},${prov.centerR}`;
      if (!visibleKeys.has(centerKey)) continue;

      const centerCoord = new HexCoord(prov.centerQ, prov.centerR);
      const center = centerCoord.toPixel(size, this.cameraX, this.cameraY);

      // Culling
      if (
        center.x < -size * 3 || center.x > window.innerWidth + size * 3 ||
        center.y < -size * 3 || center.y > window.innerHeight + size * 3
      ) {
        continue;
      }

      // 1. Great Wonder of the World
      if (prov.hasWonder) {
        // Radiant golden aura
        ctx.beginPath();
        ctx.arc(center.x, center.y, size * 1.6, 0, Math.PI * 2);
        const grad = ctx.createRadialGradient(center.x, center.y, size * 0.2, center.x, center.y, size * 1.6);
        grad.addColorStop(0, 'rgba(241, 196, 15, 0.45)');
        grad.addColorStop(1, 'rgba(241, 196, 15, 0)');
        ctx.fillStyle = grad;
        ctx.fill();

        // Wonder Badge
        const badgeY = center.y - size * 0.7;
        ctx.font = `${Math.max(12, 16 * this.scale)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🏛️✨', center.x, badgeY);

        ctx.font = `bold ${Math.max(8, 10 * this.scale)}px sans-serif`;
        ctx.fillStyle = '#f1c40f';
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2.5;
        const wTitle = prov.wonderName || 'Чудо Света';
        ctx.strokeText(wTitle, center.x, badgeY + 14 * this.scale);
        ctx.fillText(wTitle, center.x, badgeY + 14 * this.scale);
      } else if (prov.wonderTurnsRemaining && prov.wonderTurnsRemaining > 0) {
        // Scaffolding under construction
        const badgeY = center.y - size * 0.75;
        ctx.font = `${Math.max(14, 18 * this.scale)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🏗️', center.x, badgeY);

        const wTitle = prov.wonderName || 'Чудо Света';
        const progressTurns = 5 - prov.wonderTurnsRemaining;
        const txt = `${wTitle} (${progressTurns}/5 ходов)`;

        ctx.font = `bold ${Math.max(9, 10 * this.scale)}px sans-serif`;
        const textMetrics = ctx.measureText(txt);
        const pillW = textMetrics.width + 12;
        const pillH = 16 * this.scale + 2;

        ctx.fillStyle = 'rgba(18, 22, 28, 0.88)';
        ctx.strokeStyle = '#e67e22';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(center.x - pillW / 2, badgeY + 10 * this.scale - pillH / 2, pillW, pillH, 4);
        } else {
          ctx.rect(center.x - pillW / 2, badgeY + 10 * this.scale - pillH / 2, pillW, pillH);
        }
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#f39c12';
        ctx.fillText(txt, center.x, badgeY + 10 * this.scale);
      }

      // 2. Epidemic Outbreak
      if (prov.isEpidemic) {
        // Toxic reddish-purple wash
        ctx.beginPath();
        ctx.arc(center.x, center.y, size * 1.3, 0, Math.PI * 2);
        const toxicGrad = ctx.createRadialGradient(center.x, center.y, size * 0.1, center.x, center.y, size * 1.3);
        toxicGrad.addColorStop(0, 'rgba(155, 89, 182, 0.45)');
        toxicGrad.addColorStop(1, 'rgba(231, 76, 60, 0)');
        ctx.fillStyle = toxicGrad;
        ctx.fill();

        const epiY = center.y + size * 0.65;
        ctx.font = `${Math.max(12, 16 * this.scale)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('☣️💀', center.x, epiY);

        ctx.font = `bold ${Math.max(8, 10 * this.scale)}px sans-serif`;
        ctx.fillStyle = '#e74c3c';
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2.5;
        const epiText = `ЭПИДЕМИЯ (${prov.epidemicTurnsRemaining || 3} х.)`;
        ctx.strokeText(epiText, center.x, epiY + 13 * this.scale);
        ctx.fillText(epiText, center.x, epiY + 13 * this.scale);
      }
    }
  }

  private drawResourcesAndTribes(ctx: CanvasRenderingContext2D, size: number, visibleKeys: Set<string>): void {
    if (this.scale < 0.6) return;

    for (const tile of this.state.tiles.values()) {
      if (!visibleKeys.has(`${tile.q},${tile.r}`)) continue;

      const center = new HexCoord(tile.q, tile.r).toPixel(size, this.cameraX, this.cameraY);

      // Tribal Camps
      if (tile.tribalCamp) {
        ctx.font = `${Math.max(10, 14 * this.scale)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText('⛺', center.x, center.y - size * 0.2);

        ctx.font = `bold ${Math.max(8, 9 * this.scale)}px sans-serif`;
        ctx.fillStyle = '#f39c12';
        ctx.fillText(tile.tribalCamp.name, center.x, center.y + size * 0.25);
      }

      // Resources
      if (tile.resource !== ResourceType.NONE && !tile.cityId) {
        let icon = '';
        switch (tile.resource) {
          case ResourceType.COPPER: icon = '⛏️ Медь'; break;
          case ResourceType.TIN: icon = '⛏️ Олово'; break;
          case ResourceType.HORSES: icon = '🐴 Кони'; break;
          case ResourceType.GOLD: icon = '👑 Золото'; break;
          case ResourceType.TIMBER: icon = '🌲 Кедр'; break;
          case ResourceType.CLAY: icon = '🏺 Глина'; break;
          case ResourceType.FERTILE_SILT: icon = '🌾 Ил'; break;
        }

        ctx.font = `${Math.max(8, 9 * this.scale)}px sans-serif`;
        ctx.fillStyle = '#ecf0f1';
        ctx.textAlign = 'center';
        ctx.fillText(icon, center.x, center.y + size * 0.4);
      }
    }
  }

  private drawCities(ctx: CanvasRenderingContext2D, size: number, visibleKeys: Set<string>): void {
    const player = this.state.getPlayerFaction();
    for (const city of this.state.cities.values()) {
      const isPlayerCity = player && city.factionId === player.id;
      if (!isPlayerCity && !visibleKeys.has(`${city.q},${city.r}`)) {
        continue;
      }

      const faction = this.state.factions.get(city.factionId);
      const center = new HexCoord(city.q, city.r).toPixel(size, this.cameraX, this.cameraY);

      // City Ziggurat / Fortress Icon
      ctx.beginPath();
      ctx.arc(center.x, center.y, size * 0.45, 0, Math.PI * 2);
      ctx.fillStyle = faction ? faction.color : '#bdc3c7';
      ctx.fill();
      ctx.lineWidth = 2 * this.scale;
      ctx.strokeStyle = '#fff';
      ctx.stroke();

      // Ziggurat Glyph
      ctx.font = `${Math.max(11, 15 * this.scale)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fff';
      ctx.fillText('🏛️', center.x, center.y);

      // City Name Banner
      ctx.font = `bold ${Math.max(10, 12 * this.scale)}px sans-serif`;
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 3;
      ctx.strokeText(city.name, center.x, center.y - size * 0.6);
      ctx.fillText(city.name, center.x, center.y - size * 0.6);

      // Authority Gauge / Unrest Warning
      const barW = size * 0.8;
      const barH = 4 * this.scale;
      const barX = center.x - barW / 2;
      const barY = center.y + size * 0.54;

      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(barX, barY, barW, barH);
      ctx.fillStyle = this.getAuthorityColor(city.authority);
      ctx.fillRect(barX, barY, barW * (city.authority / 100), barH);

      // Unrest Indicator Badge
      if (city.unrestStage === UnrestStage.SECESSION_CRISIS) {
        ctx.font = `${Math.max(11, 14 * this.scale)}px sans-serif`;
        ctx.fillText('💥 МЯТЕЖ', center.x, barY + 14 * this.scale);
      } else if (city.unrestStage === UnrestStage.AUTONOMY_DEMAND) {
        ctx.font = `${Math.max(10, 11 * this.scale)}px sans-serif`;
        ctx.fillText('⚠️ Бунт', center.x, barY + 12 * this.scale);
      }
    }
  }

  private drawUnits(ctx: CanvasRenderingContext2D, size: number, visibleKeys: Set<string>): void {
    const player = this.state.getPlayerFaction();
    for (const unit of this.state.units.values()) {
      const isPlayerUnit = player && unit.factionId === player.id;
      if (!isPlayerUnit && !visibleKeys.has(`${unit.q},${unit.r}`)) {
        continue;
      }

      const faction = this.state.factions.get(unit.factionId);
      const center = new HexCoord(unit.q, unit.r).toPixel(size, this.cameraX, this.cameraY);

      const tile = this.state.tiles.get(`${unit.q},${unit.r}`);
      const offsetX = tile?.cityId ? size * 0.28 : 0;
      const offsetY = tile?.cityId ? size * 0.28 : 0;
      const ux = center.x + offsetX;
      const uy = center.y + offsetY;

      ctx.beginPath();
      ctx.arc(ux, uy, size * 0.32, 0, Math.PI * 2);
      ctx.fillStyle = faction ? faction.color : '#7f8c8d';
      ctx.fill();
      ctx.lineWidth = 1.5 * this.scale;
      ctx.strokeStyle = '#f1c40f';
      ctx.stroke();

      let icon = '🗡️';
      if (unit.type === UnitType.SETTLER) icon = '👨‍🌾';
      else if (unit.type === UnitType.ARCHERS) icon = '🏹';
      else if (unit.type === UnitType.SPEARMEN) icon = '🛡️';
      else if (unit.type === UnitType.CHARIOT) icon = '🐎';
      else if (unit.type === UnitType.HORDE) icon = '⛺';
      else if (unit.type === UnitType.LEGION) icon = '⚔️';
      else if (unit.type === UnitType.HEAVY_CAVALRY) icon = '🏇';
      else if (unit.type === UnitType.MUSKETEER) icon = '💂';
      else if (unit.type === UnitType.CANNON) icon = '💣';
      else if (unit.type === UnitType.INFANTRY) icon = '🪖';
      else if (unit.type === UnitType.TANK) icon = '🚜';
      else if (unit.type === UnitType.REBEL) icon = '🚩';

      ctx.font = `${Math.max(10, 13 * this.scale)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(icon, ux, uy);

      if (unit.supply < 50) {
        ctx.font = `${Math.max(8, 10 * this.scale)}px sans-serif`;
        ctx.fillText('💧!', ux + size * 0.25, uy - size * 0.2);
      }

      if (unit.loyalty !== undefined && unit.loyalty < 30) {
        ctx.font = `${Math.max(9, 11 * this.scale)}px sans-serif`;
        ctx.fillText('⚠️', ux - size * 0.25, uy - size * 0.2);
      }
    }
  }

  private drawHighlights(ctx: CanvasRenderingContext2D, size: number): void {
    if (this.state.selectedHexKey) {
      const coord = HexCoord.fromKey(this.state.selectedHexKey);
      const center = coord.toPixel(size, this.cameraX, this.cameraY);
      const corners = HexCoord.getCornerPoints(center, size);

      ctx.beginPath();
      ctx.moveTo(corners[0].x, corners[0].y);
      for (let i = 1; i < 6; i++) {
        ctx.lineTo(corners[i].x, corners[i].y);
      }
      ctx.closePath();
      ctx.strokeStyle = '#f39c12';
      ctx.lineWidth = 3.5 * this.scale;
      ctx.stroke();
    }

    if (this.state.selectedUnitId) {
      const unit = this.state.units.get(this.state.selectedUnitId);
      if (unit && unit.movesLeft > 0) {
        const uCoord = new HexCoord(unit.q, unit.r);
        for (const nCoord of uCoord.neighbors()) {
          const nTile = this.state.tiles.get(nCoord.key);
          if (!nTile || nTile.elevation <= 0.20 || nTile.elevation >= 0.88) continue;

          const nCenter = nCoord.toPixel(size, this.cameraX, this.cameraY);
          ctx.beginPath();
          ctx.arc(nCenter.x, nCenter.y, size * 0.18, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(46, 204, 113, 0.55)';
          ctx.fill();
        }
      }
    }
  }

  private drawExpandableProvinces(ctx: CanvasRenderingContext2D, size: number): void {
    const player = this.state.getPlayerFaction();
    if (!player) return;

    const expandableProvinces = this.state.getExpandableProvinces(player.id);
    if (expandableProvinces.length === 0) return;

    // 1. Soft glowing fill for expandable provinces
    for (const prov of expandableProvinces) {
      const isHovered = this.hoveredProvinceId === prov.id;
      const fillAlpha = isHovered ? 0.32 : 0.14;
      ctx.fillStyle = isHovered ? `rgba(241, 196, 15, ${fillAlpha})` : `rgba(46, 204, 113, ${fillAlpha})`;

      for (const hKey of prov.hexKeys) {
        const [q, r] = hKey.split(',').map(Number);
        const center = new HexCoord(q, r).toPixel(size, this.cameraX, this.cameraY);
        const corners = HexCoord.getCornerPoints(center, size - 0.5);

        ctx.beginPath();
        ctx.moveTo(corners[0].x, corners[0].y);
        for (let i = 1; i < 6; i++) {
          ctx.lineTo(corners[i].x, corners[i].y);
        }
        ctx.closePath();
        ctx.fill();
      }
    }

    // 2. Soft glowing contour around outer borders of expandable provinces
    for (const prov of expandableProvinces) {
      const isHovered = this.hoveredProvinceId === prov.id;
      ctx.strokeStyle = isHovered ? '#f1c40f' : 'rgba(46, 204, 113, 0.85)';
      ctx.lineWidth = (isHovered ? 2.8 : 2.0) * this.scale;

      for (const hKey of prov.hexKeys) {
        const [q, r] = hKey.split(',').map(Number);
        const coord = new HexCoord(q, r);
        const center = coord.toPixel(size, this.cameraX, this.cameraY);
        const neighbors = coord.neighbors();
        const corners = HexCoord.getCornerPoints(center, size);

        for (let i = 0; i < 6; i++) {
          const nCoord = neighbors[i];
          const nTile = this.state.tiles.get(nCoord.key);

          // Draw contour edge if neighbor tile is not part of this expandable province
          if (!nTile || nTile.provinceId !== prov.id) {
            const p1 = corners[i];
            const p2 = corners[(i + 1) % 6];

            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }
    }
  }

  /**
   * Visualizes supply line disconnection:
   * - Red diagonal hatching pattern over every hex of cut-off provinces
   * - Warning badge 🚫📦 at the province center
   */
  private drawCutOffSupplyProvinces(ctx: CanvasRenderingContext2D, size: number): void {
    for (const prov of this.state.provinces.values()) {
      if (!prov.ownerFactionId || !prov.isCutOffFromSupply) continue;

      // 1. Draw Red Diagonal Hatching across each hex of the cut-off province
      for (const hKey of prov.hexKeys) {
        const [q, r] = hKey.split(',').map(Number);
        const center = new HexCoord(q, r).toPixel(size, this.cameraX, this.cameraY);

        // Quick viewport culling
        if (
          center.x < -size ||
          center.x > this.canvas.width + size ||
          center.y < -size ||
          center.y > this.canvas.height + size
        ) {
          continue;
        }

        const corners = HexCoord.getCornerPoints(center, size - 0.5);

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(corners[0].x, corners[0].y);
        for (let i = 1; i < 6; i++) {
          ctx.lineTo(corners[i].x, corners[i].y);
        }
        ctx.closePath();
        ctx.clip();

        // Subtle red wash
        ctx.fillStyle = 'rgba(231, 76, 60, 0.20)';
        ctx.fill();

        // Diagonal hatch lines
        ctx.strokeStyle = 'rgba(231, 76, 60, 0.50)';
        ctx.lineWidth = 1.4 * this.scale;
        const spacing = Math.max(6, 9 * this.scale);
        const minX = center.x - size;
        const maxX = center.x + size;
        const minY = center.y - size;
        const maxY = center.y + size;
        const span = maxY - minY;

        ctx.beginPath();
        for (let x = minX - span; x < maxX; x += spacing) {
          ctx.moveTo(x, minY);
          ctx.lineTo(x + span, maxY);
        }
        ctx.stroke();
        ctx.restore();
      }

      // 2. Draw Warning Badge 🚫📦 at province center
      const centerCoord = new HexCoord(prov.centerQ, prov.centerR);
      const provCenter = centerCoord.toPixel(size, this.cameraX, this.cameraY);

      if (
        provCenter.x >= -size &&
        provCenter.x <= this.canvas.width + size &&
        provCenter.y >= -size &&
        provCenter.y <= this.canvas.height + size
      ) {
        const badgeR = Math.max(10, 14 * this.scale);
        const badgeY = provCenter.y - size * 0.28;

        ctx.beginPath();
        ctx.arc(provCenter.x, badgeY, badgeR, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(18, 22, 28, 0.88)';
        ctx.fill();
        ctx.strokeStyle = '#e74c3c';
        ctx.lineWidth = 1.8;
        ctx.stroke();

        ctx.font = `${Math.max(10, 14 * this.scale)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🚫📦', provCenter.x, badgeY);
      }
    }
  }

  private animFrameId: number | null = null;

  startAnimationLoop(): void {
    if (this.animFrameId !== null) return;
    const loop = () => {
      if (this.state.mode === 'PLAYING') {
        this.render();
      }
      this.animFrameId = requestAnimationFrame(loop);
    };
    this.animFrameId = requestAnimationFrame(loop);
  }

  private drawLowCohesionPulsing(ctx: CanvasRenderingContext2D, size: number): void {
    const player = this.state.getPlayerFaction();
    if (!player) return;

    // Smooth sinusoidal pulsation factor: 0.0 to 1.0 (period ~500ms)
    const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 250);

    for (const prov of this.state.provinces.values()) {
      // Check player-owned provinces with low stability (< 30% authority / Cohesion)
      if (prov.ownerFactionId !== player.id) continue;
      if (prov.authority >= 30) continue;

      const isCritical = prov.authority < 15;
      const alpha = 0.4 + 0.55 * pulse;
      const strokeColor = isCritical ? `rgba(231, 76, 60, ${alpha})` : `rgba(243, 156, 18, ${alpha})`;
      const lineWidth = Math.max(2.5, (3.0 + 2.0 * pulse) * this.scale);

      ctx.save();
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = lineWidth;
      ctx.lineCap = 'round';
      ctx.shadowColor = strokeColor;
      ctx.shadowBlur = 8 * pulse;

      // Draw the outer boundary of this province
      for (const hKey of prov.hexKeys) {
        const tile = this.state.tiles.get(hKey);
        if (!tile) continue;

        const coord = new HexCoord(tile.q, tile.r);
        const center = coord.toPixel(size, this.cameraX, this.cameraY);
        const neighbors = coord.neighbors();
        const corners = HexCoord.getCornerPoints(center, size);

        for (let i = 0; i < 6; i++) {
          const nCoord = neighbors[i];
          const nTile = this.state.tiles.get(nCoord.key);

          // If neighbor tile does not belong to this province, this edge is part of the outer province boundary!
          if (!nTile || nTile.provinceId !== prov.id) {
            const p1 = corners[i];
            const p2 = corners[(i + 1) % 6];

            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }

      ctx.restore();
    }
  }
}

