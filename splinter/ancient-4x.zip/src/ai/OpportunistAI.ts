// Opportunistic Geopolitics AI: Forced World Colonisation, Migration Hordes, Predatory Diplomacy
import type { GameState } from '../core/GameState.ts';
import {
  BiomeType,
  City,
  DiplomaticStatus,
  Faction,
  FactionTier,
  HexTile,
  Province,
  ResourceType,
  UnitType,
  UnrestStage
} from '../entities/Types.ts';
import { HexCoord } from '../map/HexCoord.ts';
import { GAME_CONSTANTS } from '../config/GameConstants.ts';

export class OpportunistAI {
  static executeTurn(faction: Faction, state: GameState): void {
    if (faction.isPlayer) return;

    // 0. A growing realm matures (otherwise the Tribe tier penalises every province past the 3rd)
    this.evolveTier(faction, state);

    // 1. Opportunistic Diplomacy: smell weakness in fractured neighbours
    this.evaluateOpportunisticDiplomacy(faction, state);

    // 2. Income (cut-off provinces yield nothing)
    this.manageEconomy(faction, state);

    // 3. FORCED COLONISATION: never sit on resources while neutral land is within reach
    const boxedIn = this.enforceExpansion(faction, state);

    // 4. Boxed in by water / mountains -> spend resources on a migrating Horde
    if (boxedIn) this.activateMigration(faction, state);

    // 5. Move existing Hordes toward vacant land (they may cross sea and mountains) and settle
    this.manageHordes(faction, state);

    // 6. Frontier patrols
    this.manageUnits(faction, state);
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  private static ownCities(faction: Faction, state: GameState): City[] {
    const result: City[] = [];
    for (const c of state.cities.values()) {
      if (c.factionId === faction.id) result.push(c);
    }
    return result;
  }

  private static evolveTier(faction: Faction, state: GameState): void {
    const n = this.ownCities(faction, state).length;
    const target =
      n >= 9 ? FactionTier.EMPIRE :
      n >= 5 ? FactionTier.EARLY_STATE :
      n >= 3 ? FactionTier.CHIEFDOM :
      FactionTier.TRIBE;
    if (!faction.tier || target > faction.tier) {
      faction.tier = target;
    }
  }

  /** Lineage (parent / child / sibling sub-cultures) or an active pact makes a faction off-limits for AI aggression. */
  private static isProtectedRelation(a: Faction, b: Faction): boolean {
    if (a.parentFactionId === b.id || b.parentFactionId === a.id) return true;
    if (a.parentFactionId && a.parentFactionId === b.parentFactionId) return true;
    const status = a.diplomacy?.[b.id]?.status;
    return status === DiplomaticStatus.ALLIANCE || status === DiplomaticStatus.NON_AGGRESSION;
  }

  /** IDs of factions that share a land border with the given faction. */
  private static getBorderingFactionIds(faction: Faction, state: GameState): Set<string> {
    const result = new Set<string>();
    for (const prov of state.provinces.values()) {
      if (prov.ownerFactionId !== faction.id) continue;
      for (const hKey of prov.hexKeys) {
        for (const n of HexCoord.fromKey(hKey).neighbors()) {
          const owner = state.tiles.get(n.key)?.ownerFactionId;
          if (owner && owner !== faction.id) result.add(owner);
        }
      }
    }
    return result;
  }

  // ---------------------------------------------------------------------------
  // Diplomacy
  // ---------------------------------------------------------------------------

  private static evaluateOpportunisticDiplomacy(aiFaction: Faction, state: GameState): void {
    for (const targetId of this.getBorderingFactionIds(aiFaction, state)) {
      const target = state.factions.get(targetId);
      if (!target || aiFaction.atWarWith.includes(target.id)) continue;
      if (this.isProtectedRelation(aiFaction, target)) continue;

      const collapsing = this.ownCities(target, state).filter(
        c => c.unrestStage === UnrestStage.SECESSION_CRISIS || c.unrestStage === UnrestStage.AUTONOMY_DEMAND
      );

      // Only a stabler neighbour dares to strike a fracturing / overextended one
      const targetIsWeak = collapsing.length >= 2 || target.overextension > 40;
      if (!targetIsWeak || aiFaction.overextension >= target.overextension) continue;
      if (Math.random() > 0.25) continue; // not every turn

      aiFaction.atWarWith.push(target.id);
      target.atWarWith.push(aiFaction.id);
      aiFaction.diplomacy[target.id] = { status: DiplomaticStatus.WAR, opinion: -80, pactTurnsLeft: 0 };
      target.diplomacy[aiFaction.id] = { status: DiplomaticStatus.WAR, opinion: -80, pactTurnsLeft: 0 };

      if (target.isPlayer) {
        state.addChronicle(
          `⚔️ ХИЩНИЧЕСКАЯ ВОЙНА: «${aiFaction.name}» почуяла слабость вашей державы и объявила войну!`,
          'critical'
        );
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Economy
  // ---------------------------------------------------------------------------

  private static manageEconomy(faction: Faction, state: GameState): void {
    for (const city of this.ownCities(faction, state)) {
      const prov = state.provinces.get(city.provinceId);
      // Supply lines: a cut-off province cannot send gold or grain to the capital
      if (prov?.isCutOffFromSupply && city.id !== faction.capitalCityId) continue;

      faction.gold += Math.round(city.population * 1.5 * (city.authority / 100));
      faction.grain += Math.round(city.population * 2.0);
    }
  }

  // ---------------------------------------------------------------------------
  // Forced colonisation
  // ---------------------------------------------------------------------------

  /** Higher = more desirable: fertile river glades and Copper/Tin hexes first. */
  private static scoreProvince(prov: Province, state: GameState): number {
    let score = prov.fertility;
    if (prov.biome === BiomeType.RIVER_VALLEY) score += 6;
    else if (prov.biome === BiomeType.FERTILE_PLAINS) score += 3;
    if (prov.biome === BiomeType.MOUNTAINS) score -= 4;
    if (prov.biome === BiomeType.DESERT) score -= 3;

    let riverHexes = 0;
    for (const hKey of prov.hexKeys) {
      const t = state.tiles.get(hKey);
      if (!t) continue;
      if (t.isRiver) riverHexes++;
      switch (t.resource) {
        case ResourceType.COPPER:
        case ResourceType.TIN:
          score += 5; break;
        case ResourceType.INCENSE:
        case ResourceType.CATTLE:
        case ResourceType.GOLD:
          score += 3; break;
        case ResourceType.FERTILE_SILT:
        case ResourceType.HORSES:
          score += 2; break;
        case ResourceType.TIMBER:
        case ResourceType.CLAY:
          score += 1; break;
        default: break;
      }
    }
    score += Math.min(3, riverHexes * 0.75);
    return score;
  }

  /**
   * Claims adjacent empty provinces. If the faction can pay (Culture Points OR Food) it MUST claim with 95% chance.
   * @returns true when the faction has NO adjacent empty province at all (boxed in by water / mountains).
   */
  private static enforceExpansion(faction: Faction, state: GameState): boolean {
    const cfg = GAME_CONSTANTS.AI;
    if (this.ownCities(faction, state).length === 0) return false;

    const maxClaims = (faction.tier || FactionTier.TRIBE) >= FactionTier.EARLY_STATE ? 2 : 1;
    for (let i = 0; i < maxClaims; i++) {
      if (faction.overextension >= cfg.MAX_OVEREXTENSION) return false;

      const candidates = state.getExpandableProvinces(faction.id);
      if (candidates.length === 0) return true;

      let best: Province | null = null;
      let bestScore = -Infinity;
      for (const prov of candidates) {
        if (!state.getAnnexationCost(prov.id, faction.id).canAffordEither) continue;
        const score = this.scoreProvince(prov, state);
        if (score > bestScore) {
          bestScore = score;
          best = prov;
        }
      }

      if (!best) return false; // cannot afford anything yet -> saves up, but does not hoard once it can pay
      if (Math.random() >= cfg.FORCED_EXPANSION_CHANCE) return false;
      if (!state.annexProvinceForFaction(faction.id, best.id)) return false;
    }
    return false;
  }

  // ---------------------------------------------------------------------------
  // Migration (Horde mode)
  // ---------------------------------------------------------------------------

  private static isSettleTarget(tile: HexTile, originProvinceId: string | undefined, state: GameState, selfUnitId?: string): boolean {
    if (tile.biome === BiomeType.OCEAN || !tile.provinceId || tile.cityId) return false;
    if (tile.unitId && tile.unitId !== selfUnitId) return false;
    if (tile.tribalCamp) return false;
    const prov = state.provinces.get(tile.provinceId);
    if (!prov || prov.ownerFactionId !== null || prov.tribalCamp) return false;
    if (originProvinceId && prov.id === originProvinceId) return false;
    return true;
  }

  /**
   * Breadth-first search over ALL tiles (water and mountains included: rafts, boats and mountain passes)
   * for the nearest vacant province; among equally distant targets the most desirable one wins.
   * @returns path of hexes from `start` (inclusive) to the settle target (inclusive), or null.
   */
  private static findMigrationPath(
    start: HexCoord,
    originProvinceId: string | undefined,
    state: GameState,
    selfUnitId?: string
  ): HexCoord[] | null {
    const maxDepth = GAME_CONSTANTS.AI.MIGRATION_SEARCH_DEPTH;
    const prev = new Map<string, string | null>();
    prev.set(start.key, null);
    let frontier: string[] = [start.key];

    for (let depth = 0; depth < maxDepth && frontier.length > 0; depth++) {
      const next: string[] = [];
      let bestKey: string | null = null;
      let bestScore = -Infinity;

      for (const key of frontier) {
        for (const n of HexCoord.fromKey(key).neighbors()) {
          if (prev.has(n.key)) continue;
          const tile = state.tiles.get(n.key);
          if (!tile) continue;
          prev.set(n.key, key);
          next.push(n.key);

          if (this.isSettleTarget(tile, originProvinceId, state, selfUnitId)) {
            const prov = tile.provinceId ? state.provinces.get(tile.provinceId) : undefined;
            const score = prov ? this.scoreProvince(prov, state) : 0;
            if (score > bestScore) {
              bestScore = score;
              bestKey = n.key;
            }
          }
        }
      }

      if (bestKey) {
        const path: HexCoord[] = [];
        let cursor: string | null = bestKey;
        while (cursor !== null) {
          path.push(HexCoord.fromKey(cursor));
          cursor = prev.get(cursor) ?? null;
        }
        return path.reverse();
      }
      frontier = next;
    }
    return null;
  }

  /** Boxed in: pay Food + Culture Points, send part of a city's people out as a Horde. */
  private static activateMigration(faction: Faction, state: GameState): void {
    const cfg = GAME_CONSTANTS.AI;
    const hasActiveHorde = Array.from(state.units.values()).some(u => u.factionId === faction.id && u.type === UnitType.HORDE);
    if (hasActiveHorde) return;
    if (faction.grain < cfg.MIGRATION_GRAIN_COST || (faction.culturePoints || 0) < cfg.MIGRATION_CULTURE_COST) return;

    // Prefer giving up people from a colony; the capital only if it is big enough
    const cities = this.ownCities(faction, state)
      .filter(c => c.population >= 5)
      .sort((a, b) => {
        const aCap = a.id === faction.capitalCityId ? 1 : 0;
        const bCap = b.id === faction.capitalCityId ? 1 : 0;
        return aCap - bCap || b.population - a.population;
      });
    const source = cities.find(c => c.id !== faction.capitalCityId || c.population >= 8);
    if (!source) return;

    // Make sure there is somewhere to go before paying
    if (!this.findMigrationPath(new HexCoord(source.q, source.r), source.provinceId, state)) return;

    const horde = state.launchMigrationHorde(faction.id, source.id);
    if (!horde) return;

    faction.grain -= cfg.MIGRATION_GRAIN_COST;
    faction.culturePoints = (faction.culturePoints || 0) - cfg.MIGRATION_CULTURE_COST;
    source.population = Math.max(3, source.population - 3);
  }

  private static manageHordes(faction: Faction, state: GameState): void {
    const hordes = Array.from(state.units.values()).filter(u => u.factionId === faction.id && u.type === UnitType.HORDE);

    for (const horde of hordes) {
      if (!state.units.has(horde.id)) continue;

      const hereKey = `${horde.q},${horde.r}`;
      const here = state.tiles.get(hereKey);
      if (here && this.isSettleTarget(here, horde.originProvinceId, state, horde.id) && state.settleHorde(horde.id)) {
        continue;
      }

      const path = this.findMigrationPath(new HexCoord(horde.q, horde.r), horde.originProvinceId, state, horde.id);
      if (!path || path.length < 2) continue; // no vacant land reachable: supply attrition will end the wanderers

      let steps = 0;
      let idx = 1;
      while (idx < path.length && steps < horde.maxMoves) {
        const next = path[idx];
        const nextTile = state.tiles.get(next.key);
        if (!nextTile || (nextTile.unitId && nextTile.unitId !== horde.id)) break; // blocked: wait a turn

        const cur = state.tiles.get(`${horde.q},${horde.r}`);
        if (cur && cur.unitId === horde.id) cur.unitId = null;
        horde.q = next.q;
        horde.r = next.r;
        nextTile.unitId = horde.id;
        idx++;
        steps++;
      }
      horde.movesLeft = Math.max(0, horde.maxMoves - steps);

      const landed = state.tiles.get(`${horde.q},${horde.r}`);
      if (landed && this.isSettleTarget(landed, horde.originProvinceId, state, horde.id)) {
        state.settleHorde(horde.id);
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Units
  // ---------------------------------------------------------------------------

  private static manageUnits(faction: Faction, state: GameState): void {
    for (const unit of Array.from(state.units.values())) {
      if (unit.factionId !== faction.id) continue;
      unit.movesLeft = unit.maxMoves;
      if (unit.type === UnitType.HORDE || unit.type === UnitType.SETTLER) continue; // handled elsewhere

      // Simple frontier patrol: stay inside own / neutral land
      const currentCoord = new HexCoord(unit.q, unit.r);
      const neighbors = currentCoord.neighbors()
        .map(c => ({ coord: c, tile: state.tiles.get(c.key) }))
        .filter(n =>
          n.tile &&
          n.tile.elevation > 0.22 &&
          n.tile.elevation < 0.85 &&
          (!n.tile.ownerFactionId || n.tile.ownerFactionId === faction.id)
        );

      if (neighbors.length > 0 && Math.random() < 0.6) {
        const target = neighbors[Math.floor(Math.random() * neighbors.length)];
        if (target.tile && !target.tile.unitId) {
          const oldTile = state.tiles.get(currentCoord.key);
          if (oldTile) oldTile.unitId = null;

          unit.q = target.coord.q;
          unit.r = target.coord.r;
          target.tile.unitId = unit.id;

          // Pacify / assimilate neutral tribal camps
          if (target.tile.tribalCamp) {
            target.tile.tribalCamp = null;
            target.tile.ownerFactionId = faction.id;
          }
        }
      }
    }
  }
}
